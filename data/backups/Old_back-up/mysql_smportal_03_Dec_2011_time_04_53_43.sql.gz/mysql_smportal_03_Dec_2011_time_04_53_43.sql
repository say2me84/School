# MySQL backup created by phpMySQLAutoBackup
#
# http://www.dwalker.co.uk/phpmysqlautobackup/
#
# Database: smportal
# Domain name: localhost
# (c)2011 localhost
#
# Backup START time: 04:53:43
# Backup END time: 04:53:43
# Backup Date: 03 Dec 2011

drop table if exists `additional_exam_groups`;
CREATE TABLE `additional_exam_groups` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `exam_type` varchar(255) collate utf8_unicode_ci default NULL,
  `is_published` tinyint(1) default '0',
  `result_published` tinyint(1) default '0',
  `students_list` varchar(255) collate utf8_unicode_ci default NULL,
  `exam_date` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

drop table if exists `additional_exam_scores`;
CREATE TABLE `additional_exam_scores` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `additional_exam_id` int(11) default NULL,
  `marks` decimal(7,2) default NULL,
  `grading_level_id` int(11) default NULL,
  `remarks` varchar(255) collate utf8_unicode_ci default NULL,
  `is_failed` tinyint(1) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

drop table if exists `additional_exams`;
CREATE TABLE `additional_exams` (
  `id` int(11) NOT NULL auto_increment,
  `additional_exam_group_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  `start_time` datetime default NULL,
  `end_time` datetime default NULL,
  `maximum_marks` int(11) default NULL,
  `minimum_marks` int(11) default NULL,
  `grading_level_id` int(11) default NULL,
  `weightage` int(11) default '0',
  `event_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

drop table if exists `attendances`;
CREATE TABLE `attendances` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `period_table_entry_id` int(11) default NULL,
  `forenoon` tinyint(1) default '0',
  `afternoon` tinyint(1) default '0',
  `reason` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `attendances` (`id`, `student_id`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('1', '13', '8', '1', '1', 'went outside');
insert into `attendances` (`id`, `student_id`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('2', '6', '11', '0', '1', 'not well');
insert into `attendances` (`id`, `student_id`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('3', '13', '2', '1', '0', 'taking rest');

drop table if exists `batch_events`;
CREATE TABLE `batch_events` (
  `id` int(11) NOT NULL auto_increment,
  `event_id` int(11) default NULL,
  `batch_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_batch_events_on_batch_id` (`batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `batch_events` (`id`, `event_id`, `batch_id`, `created_at`, `updated_at`) values ('1', '9', '5', '2011-11-29 12:37:00', NULL);

drop table if exists `batches`;
CREATE TABLE `batches` (
  `id` int(11) NOT NULL auto_increment,
  `schoolid` int(11) default NULL,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `grade_id` int(11) default NULL,
  `start_date` datetime default NULL,
  `end_date` datetime default NULL,
  `is_active` tinyint(1) default '1',
  `is_deleted` tinyint(1) default '0',
  `employee_id` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_batches_on_is_deleted_and_is_active` (`is_deleted`,`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('2', '1', '8A', '1', '2011-11-30 00:00:00', '2011-11-05 00:00:00', '1', '0', '1');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('4', '1', '11C', '2', '2011-11-09 00:00:00', '2012-11-09 00:00:00', '1', '0', '3');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('5', '1', '11A', '2', '2011-11-15 00:00:00', '2011-12-14 00:00:00', '1', '0', '0');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('6', '2', '9A', '3', '2011-11-15 00:00:00', '2012-10-30 00:00:00', '1', '0', '6');

drop table if exists `batches_template`;
CREATE TABLE `batches_template` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `class_id` int(11) default NULL,
  `start_date` datetime default NULL,
  `end_date` datetime default NULL,
  `is_active` tinyint(1) default '1',
  `is_deleted` tinyint(1) default '0',
  `employee_id` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_batches_on_is_deleted_and_is_active` (`is_deleted`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

drop table if exists `class_timings`;
CREATE TABLE `class_timings` (
  `id` int(11) NOT NULL auto_increment,
  `batch_id` int(11) default NULL,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `start_time` time default NULL,
  `end_time` time default NULL,
  `is_break` tinyint(1) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_class_timings_on_batch_id_and_start_time_and_end_time` (`batch_id`,`start_time`,`end_time`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `class_timings` (`id`, `batch_id`, `name`, `start_time`, `end_time`, `is_break`) values ('1', '2', 'First Period', '08:00:00', '09:00:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `name`, `start_time`, `end_time`, `is_break`) values ('2', '2', 'Second Period', '09:00:00', '10:00:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `name`, `start_time`, `end_time`, `is_break`) values ('3', '4', 'First', '10:00:00', '11:30:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `name`, `start_time`, `end_time`, `is_break`) values ('4', '4', 'Second', '11:35:00', '12:35:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `name`, `start_time`, `end_time`, `is_break`) values ('5', '4', 'Third', '12:40:00', '13:45:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `name`, `start_time`, `end_time`, `is_break`) values ('6', '6', 'First', '08:30:00', '09:30:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `name`, `start_time`, `end_time`, `is_break`) values ('7', '6', 'Second', '09:30:00', '10:30:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `name`, `start_time`, `end_time`, `is_break`) values ('8', '6', 'Third', '10:30:00', '11:00:00', NULL);

drop table if exists `countries`;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `countries` (`id`, `name`) values ('1', 'Afghanistan');
insert into `countries` (`id`, `name`) values ('2', 'Albania');
insert into `countries` (`id`, `name`) values ('3', 'Algeria');
insert into `countries` (`id`, `name`) values ('4', 'Andorra');
insert into `countries` (`id`, `name`) values ('5', 'Angola');
insert into `countries` (`id`, `name`) values ('6', 'Antigua & Deps');
insert into `countries` (`id`, `name`) values ('7', 'Argentina');
insert into `countries` (`id`, `name`) values ('8', 'Armenia');
insert into `countries` (`id`, `name`) values ('9', 'Australia');
insert into `countries` (`id`, `name`) values ('10', 'Austria');
insert into `countries` (`id`, `name`) values ('11', 'Azerbaijan');
insert into `countries` (`id`, `name`) values ('12', 'Bahamas');
insert into `countries` (`id`, `name`) values ('13', 'Bahrain');
insert into `countries` (`id`, `name`) values ('14', 'Bangladesh');
insert into `countries` (`id`, `name`) values ('15', 'Barbados');
insert into `countries` (`id`, `name`) values ('16', 'Belarus');
insert into `countries` (`id`, `name`) values ('17', 'Belgium');
insert into `countries` (`id`, `name`) values ('18', 'Belize');
insert into `countries` (`id`, `name`) values ('19', 'Benin');
insert into `countries` (`id`, `name`) values ('20', 'Bhutan');
insert into `countries` (`id`, `name`) values ('21', 'Bolivia');
insert into `countries` (`id`, `name`) values ('22', 'Bosnia Herzegovina');
insert into `countries` (`id`, `name`) values ('23', 'Botswana');
insert into `countries` (`id`, `name`) values ('24', 'Brazil');
insert into `countries` (`id`, `name`) values ('25', 'Brunei');
insert into `countries` (`id`, `name`) values ('26', 'Bulgaria');
insert into `countries` (`id`, `name`) values ('27', 'Burkina');
insert into `countries` (`id`, `name`) values ('28', 'Burundi');
insert into `countries` (`id`, `name`) values ('29', 'Cambodia');
insert into `countries` (`id`, `name`) values ('30', 'Cameroon');
insert into `countries` (`id`, `name`) values ('31', 'Canada');
insert into `countries` (`id`, `name`) values ('32', 'Cape Verde');
insert into `countries` (`id`, `name`) values ('33', 'Central African Rep');
insert into `countries` (`id`, `name`) values ('34', 'Chad');
insert into `countries` (`id`, `name`) values ('35', 'Chile');
insert into `countries` (`id`, `name`) values ('36', 'China');
insert into `countries` (`id`, `name`) values ('37', 'Colombia');
insert into `countries` (`id`, `name`) values ('38', 'Comoros');
insert into `countries` (`id`, `name`) values ('39', 'Congo');
insert into `countries` (`id`, `name`) values ('40', 'Congo {Democratic Rep}');
insert into `countries` (`id`, `name`) values ('41', 'Costa Rica');
insert into `countries` (`id`, `name`) values ('42', 'Croatia');
insert into `countries` (`id`, `name`) values ('43', 'Cuba');
insert into `countries` (`id`, `name`) values ('44', 'Cyprus');
insert into `countries` (`id`, `name`) values ('45', 'Czech Republic');
insert into `countries` (`id`, `name`) values ('46', 'Denmark');
insert into `countries` (`id`, `name`) values ('47', 'Djibouti');
insert into `countries` (`id`, `name`) values ('48', 'Dominica');
insert into `countries` (`id`, `name`) values ('49', 'Dominican Republic');
insert into `countries` (`id`, `name`) values ('50', 'East Timor');
insert into `countries` (`id`, `name`) values ('51', 'Ecuador');
insert into `countries` (`id`, `name`) values ('52', 'Egypt');
insert into `countries` (`id`, `name`) values ('53', 'El Salvador');
insert into `countries` (`id`, `name`) values ('54', 'Equatorial Guinea');
insert into `countries` (`id`, `name`) values ('55', 'Eritrea');
insert into `countries` (`id`, `name`) values ('56', 'Estonia');
insert into `countries` (`id`, `name`) values ('57', 'Ethiopia');
insert into `countries` (`id`, `name`) values ('58', 'Fiji');
insert into `countries` (`id`, `name`) values ('59', 'Finland');
insert into `countries` (`id`, `name`) values ('60', 'France');
insert into `countries` (`id`, `name`) values ('61', 'Gabon');
insert into `countries` (`id`, `name`) values ('62', 'Gambia');
insert into `countries` (`id`, `name`) values ('63', 'Georgia');
insert into `countries` (`id`, `name`) values ('64', 'Germany');
insert into `countries` (`id`, `name`) values ('65', 'Ghana');
insert into `countries` (`id`, `name`) values ('66', 'Greece');
insert into `countries` (`id`, `name`) values ('67', 'Grenada');
insert into `countries` (`id`, `name`) values ('68', 'Guatemala');
insert into `countries` (`id`, `name`) values ('69', 'Guinea');
insert into `countries` (`id`, `name`) values ('70', 'Guinea-Bissau');
insert into `countries` (`id`, `name`) values ('71', 'Guyana');
insert into `countries` (`id`, `name`) values ('72', 'Haiti');
insert into `countries` (`id`, `name`) values ('73', 'Honduras');
insert into `countries` (`id`, `name`) values ('74', 'Hungary');
insert into `countries` (`id`, `name`) values ('75', 'Iceland');
insert into `countries` (`id`, `name`) values ('76', 'India');
insert into `countries` (`id`, `name`) values ('77', 'Indonesia');
insert into `countries` (`id`, `name`) values ('78', 'Iran');
insert into `countries` (`id`, `name`) values ('79', 'Iraq');
insert into `countries` (`id`, `name`) values ('80', 'Ireland {Republic}');
insert into `countries` (`id`, `name`) values ('81', 'Israel');
insert into `countries` (`id`, `name`) values ('82', 'Italy');
insert into `countries` (`id`, `name`) values ('83', 'Ivory Coast');
insert into `countries` (`id`, `name`) values ('84', 'Jamaica');
insert into `countries` (`id`, `name`) values ('85', 'Japan');
insert into `countries` (`id`, `name`) values ('86', 'Jordan');
insert into `countries` (`id`, `name`) values ('87', 'Kazakhstan');
insert into `countries` (`id`, `name`) values ('88', 'Kenya');
insert into `countries` (`id`, `name`) values ('89', 'Kiribati');
insert into `countries` (`id`, `name`) values ('90', 'Korea North');
insert into `countries` (`id`, `name`) values ('91', 'Korea South');
insert into `countries` (`id`, `name`) values ('92', 'Kosovo');
insert into `countries` (`id`, `name`) values ('93', 'Kuwait');
insert into `countries` (`id`, `name`) values ('94', 'Kyrgyzstan');
insert into `countries` (`id`, `name`) values ('95', 'Laos');
insert into `countries` (`id`, `name`) values ('96', 'Latvia');
insert into `countries` (`id`, `name`) values ('97', 'Lebanon');
insert into `countries` (`id`, `name`) values ('98', 'Lesotho');
insert into `countries` (`id`, `name`) values ('99', 'Liberia');
insert into `countries` (`id`, `name`) values ('100', 'Libya');
insert into `countries` (`id`, `name`) values ('101', 'Liechtenstein');
insert into `countries` (`id`, `name`) values ('102', 'Lithuania');
insert into `countries` (`id`, `name`) values ('103', 'Luxembourg');
insert into `countries` (`id`, `name`) values ('104', 'Macedonia');
insert into `countries` (`id`, `name`) values ('105', 'Madagascar');
insert into `countries` (`id`, `name`) values ('106', 'Malawi');
insert into `countries` (`id`, `name`) values ('107', 'Malaysia');
insert into `countries` (`id`, `name`) values ('108', 'Maldives');
insert into `countries` (`id`, `name`) values ('109', 'Mali');
insert into `countries` (`id`, `name`) values ('110', 'Malta');
insert into `countries` (`id`, `name`) values ('111', 'Montenegro');
insert into `countries` (`id`, `name`) values ('112', 'Marshall Islands');
insert into `countries` (`id`, `name`) values ('113', 'Mauritania');
insert into `countries` (`id`, `name`) values ('114', 'Mauritius');
insert into `countries` (`id`, `name`) values ('115', 'Mexico');
insert into `countries` (`id`, `name`) values ('116', 'Micronesia');
insert into `countries` (`id`, `name`) values ('117', 'Moldova');
insert into `countries` (`id`, `name`) values ('118', 'Monaco');
insert into `countries` (`id`, `name`) values ('119', 'Mongolia');
insert into `countries` (`id`, `name`) values ('120', 'Morocco');
insert into `countries` (`id`, `name`) values ('121', 'Mozambique');
insert into `countries` (`id`, `name`) values ('122', 'Myanmar, {Burma}');
insert into `countries` (`id`, `name`) values ('123', 'Namibia');
insert into `countries` (`id`, `name`) values ('124', 'Nauru');
insert into `countries` (`id`, `name`) values ('125', 'Nepal');
insert into `countries` (`id`, `name`) values ('126', 'Netherlands');
insert into `countries` (`id`, `name`) values ('127', 'New Zealand');
insert into `countries` (`id`, `name`) values ('128', 'Nicaragua');
insert into `countries` (`id`, `name`) values ('129', 'Niger');
insert into `countries` (`id`, `name`) values ('130', 'Nigeria');
insert into `countries` (`id`, `name`) values ('131', 'Norway');
insert into `countries` (`id`, `name`) values ('132', 'Oman');
insert into `countries` (`id`, `name`) values ('133', 'Pakistan');
insert into `countries` (`id`, `name`) values ('134', 'Palau');
insert into `countries` (`id`, `name`) values ('135', 'Panama');
insert into `countries` (`id`, `name`) values ('136', 'Papua New Guinea');
insert into `countries` (`id`, `name`) values ('137', 'Paraguay');
insert into `countries` (`id`, `name`) values ('138', 'Peru');
insert into `countries` (`id`, `name`) values ('139', 'Philippines');
insert into `countries` (`id`, `name`) values ('140', 'Poland');
insert into `countries` (`id`, `name`) values ('141', 'Portugal');
insert into `countries` (`id`, `name`) values ('142', 'Qatar');
insert into `countries` (`id`, `name`) values ('143', 'Romania');
insert into `countries` (`id`, `name`) values ('144', 'Russian Federation');
insert into `countries` (`id`, `name`) values ('145', 'Rwanda');
insert into `countries` (`id`, `name`) values ('146', 'St Kitts & Nevis');
insert into `countries` (`id`, `name`) values ('147', 'St Lucia');
insert into `countries` (`id`, `name`) values ('148', 'Saint Vincent & the Grenadines');
insert into `countries` (`id`, `name`) values ('149', 'Samoa');
insert into `countries` (`id`, `name`) values ('150', 'San Marino');
insert into `countries` (`id`, `name`) values ('151', 'Sao Tome & Principe');
insert into `countries` (`id`, `name`) values ('152', 'Saudi Arabia');
insert into `countries` (`id`, `name`) values ('153', 'Senegal');
insert into `countries` (`id`, `name`) values ('154', 'Serbia');
insert into `countries` (`id`, `name`) values ('155', 'Seychelles');
insert into `countries` (`id`, `name`) values ('156', 'Sierra Leone');
insert into `countries` (`id`, `name`) values ('157', 'Singapore');
insert into `countries` (`id`, `name`) values ('158', 'Slovakia');
insert into `countries` (`id`, `name`) values ('159', 'Slovenia');
insert into `countries` (`id`, `name`) values ('160', 'Solomon Islands');
insert into `countries` (`id`, `name`) values ('161', 'Somalia');
insert into `countries` (`id`, `name`) values ('162', 'South Africa');
insert into `countries` (`id`, `name`) values ('163', 'Spain');
insert into `countries` (`id`, `name`) values ('164', 'Sri Lanka');
insert into `countries` (`id`, `name`) values ('165', 'Sudan');
insert into `countries` (`id`, `name`) values ('166', 'Suriname');
insert into `countries` (`id`, `name`) values ('167', 'Swaziland');
insert into `countries` (`id`, `name`) values ('168', 'Sweden');
insert into `countries` (`id`, `name`) values ('169', 'Switzerland');
insert into `countries` (`id`, `name`) values ('170', 'Syria');
insert into `countries` (`id`, `name`) values ('171', 'Taiwan');
insert into `countries` (`id`, `name`) values ('172', 'Tajikistan');
insert into `countries` (`id`, `name`) values ('173', 'Tanzania');
insert into `countries` (`id`, `name`) values ('174', 'Thailand');
insert into `countries` (`id`, `name`) values ('175', 'Togo');
insert into `countries` (`id`, `name`) values ('176', 'Tonga');
insert into `countries` (`id`, `name`) values ('177', 'Trinidad & Tobago');
insert into `countries` (`id`, `name`) values ('178', 'Tunisia');
insert into `countries` (`id`, `name`) values ('179', 'Turkey');
insert into `countries` (`id`, `name`) values ('180', 'Turkmenistan');
insert into `countries` (`id`, `name`) values ('181', 'Tuvalu');
insert into `countries` (`id`, `name`) values ('182', 'Uganda');
insert into `countries` (`id`, `name`) values ('183', 'Ukraine');
insert into `countries` (`id`, `name`) values ('184', 'United Arab Emirates');
insert into `countries` (`id`, `name`) values ('185', 'United Kingdom');
insert into `countries` (`id`, `name`) values ('186', 'United States');
insert into `countries` (`id`, `name`) values ('187', 'Uruguay');
insert into `countries` (`id`, `name`) values ('188', 'Uzbekistan');
insert into `countries` (`id`, `name`) values ('189', 'Vanuatu');
insert into `countries` (`id`, `name`) values ('190', 'Vatican City');
insert into `countries` (`id`, `name`) values ('191', 'Venezuea');
insert into `countries` (`id`, `name`) values ('192', 'Vietnam');
insert into `countries` (`id`, `name`) values ('193', 'Yemen');
insert into `countries` (`id`, `name`) values ('194', 'Zambia');
insert into `countries` (`id`, `name`) values ('195', 'Zimbabwe');

drop table if exists `employee_categories`;
CREATE TABLE `employee_categories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `prefix` varchar(255) collate utf8_unicode_ci default NULL,
  `schoolid` int(11) NOT NULL default '0',
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `employee_categories` (`id`, `name`, `prefix`, `schoolid`, `status`) values ('1', 'First Level', 'F', '1', '1');
insert into `employee_categories` (`id`, `name`, `prefix`, `schoolid`, `status`) values ('2', 'Second Level', 'S', '1', '1');
insert into `employee_categories` (`id`, `name`, `prefix`, `schoolid`, `status`) values ('3', 'Third Level', 'T', '1', '1');
insert into `employee_categories` (`id`, `name`, `prefix`, `schoolid`, `status`) values ('4', 'General', 'gen', '1', '0');
insert into `employee_categories` (`id`, `name`, `prefix`, `schoolid`, `status`) values ('5', 'Teaching', 'teach', '2', '1');

drop table if exists `employee_departments`;
CREATE TABLE `employee_departments` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(255) collate utf8_unicode_ci default NULL,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `schoolid` int(11) NOT NULL default '0',
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('1', 'D001', 'Science', '1', '1');
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('2', 'D04', 'Botany', '1', '0');
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('3', 'D002', 'Depatment of Mathematics', '1', '1');
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('4', 'D03', 'Computer Science', '1', '1');
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('5', '101', 'Department of Science', '2', '1');

drop table if exists `employee_positions`;
CREATE TABLE `employee_positions` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `employee_category_id` int(11) default NULL,
  `schoolid` int(11) NOT NULL default '0',
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `employee_positions` (`id`, `name`, `employee_category_id`, `schoolid`, `status`) values ('1', 'Lab Assistant', '3', '1', '1');
insert into `employee_positions` (`id`, `name`, `employee_category_id`, `schoolid`, `status`) values ('2', 'Accountant', '2', '1', '0');
insert into `employee_positions` (`id`, `name`, `employee_category_id`, `schoolid`, `status`) values ('3', 'First', '5', '2', '1');
insert into `employee_positions` (`id`, `name`, `employee_category_id`, `schoolid`, `status`) values ('4', 'Second', '5', '2', '1');

drop table if exists `employees`;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL auto_increment,
  `schoolid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `employee_category_id` int(11) default NULL,
  `employee_number` varchar(255) collate utf8_unicode_ci default NULL,
  `joining_date` date default NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `gender` tinyint(1) default NULL,
  `job_title` varchar(255) collate utf8_unicode_ci default NULL,
  `employee_position_id` int(11) default NULL,
  `employee_department_id` int(11) default NULL,
  `reporting_manager_id` int(11) default NULL,
  `employee_grade_id` int(11) default NULL,
  `qualification` varchar(255) collate utf8_unicode_ci default NULL,
  `experience_detail` text collate utf8_unicode_ci,
  `experience_year` int(11) default NULL,
  `experience_month` int(11) default NULL,
  `status` tinyint(1) default NULL,
  `status_description` varchar(255) collate utf8_unicode_ci default NULL,
  `date_of_birth` date default NULL,
  `marital_status` varchar(255) collate utf8_unicode_ci default NULL,
  `children_count` int(11) default NULL,
  `father_name` varchar(255) collate utf8_unicode_ci default NULL,
  `mother_name` varchar(255) collate utf8_unicode_ci default NULL,
  `husband_name` varchar(255) collate utf8_unicode_ci default NULL,
  `blood_group` varchar(255) collate utf8_unicode_ci default NULL,
  `nationality_id` int(11) default NULL,
  `home_address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `home_address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `home_city` varchar(255) collate utf8_unicode_ci default NULL,
  `home_state` varchar(255) collate utf8_unicode_ci default NULL,
  `home_country_id` int(11) default NULL,
  `home_pin_code` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `office_city` varchar(255) collate utf8_unicode_ci default NULL,
  `office_state` varchar(255) collate utf8_unicode_ci default NULL,
  `office_country_id` int(11) default NULL,
  `office_pin_code` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone2` varchar(255) collate utf8_unicode_ci default NULL,
  `mobile_phone` varchar(255) collate utf8_unicode_ci default NULL,
  `home_phone` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `fax` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_file_name` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_content_type` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_data` mediumblob,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `photo_file_size` int(11) default NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_employees_on_employee_number` (`employee_number`(10))
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `employees` (`id`, `schoolid`, `userid`, `employee_category_id`, `employee_number`, `joining_date`, `first_name`, `last_name`, `gender`, `job_title`, `employee_position_id`, `employee_department_id`, `reporting_manager_id`, `employee_grade_id`, `qualification`, `experience_detail`, `experience_year`, `experience_month`, `status`, `status_description`, `date_of_birth`, `marital_status`, `children_count`, `father_name`, `mother_name`, `husband_name`, `blood_group`, `nationality_id`, `home_address_line1`, `home_address_line2`, `home_city`, `home_state`, `home_country_id`, `home_pin_code`, `office_address_line1`, `office_address_line2`, `office_city`, `office_state`, `office_country_id`, `office_pin_code`, `office_phone1`, `office_phone2`, `mobile_phone`, `home_phone`, `email`, `fax`, `photo_file_name`, `photo_content_type`, `photo_data`, `created_at`, `updated_at`, `photo_file_size`, `user_id`) values ('2', '1', '6', '1', '10041', '2011-11-09', 'Ashfaq', 'Khan', '0', NULL, '1', '4', NULL, NULL, '', '', '0', '0', '1', NULL, '1984-06-14', 'Single', '0', '', '', '', '1', '1', '', '', '', '', '1', '', '', '', '', '', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
insert into `employees` (`id`, `schoolid`, `userid`, `employee_category_id`, `employee_number`, `joining_date`, `first_name`, `last_name`, `gender`, `job_title`, `employee_position_id`, `employee_department_id`, `reporting_manager_id`, `employee_grade_id`, `qualification`, `experience_detail`, `experience_year`, `experience_month`, `status`, `status_description`, `date_of_birth`, `marital_status`, `children_count`, `father_name`, `mother_name`, `husband_name`, `blood_group`, `nationality_id`, `home_address_line1`, `home_address_line2`, `home_city`, `home_state`, `home_country_id`, `home_pin_code`, `office_address_line1`, `office_address_line2`, `office_city`, `office_state`, `office_country_id`, `office_pin_code`, `office_phone1`, `office_phone2`, `mobile_phone`, `home_phone`, `email`, `fax`, `photo_file_name`, `photo_content_type`, `photo_data`, `created_at`, `updated_at`, `photo_file_size`, `user_id`) values ('3', '1', '8', '2', '1102', '2011-11-15', 'Shailendra', 'Purohit', '0', NULL, '1', '1', NULL, NULL, '', '', '0', '0', '1', NULL, '1985-07-16', 'Married', '0', '', '', '', '1', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3400.jpg', NULL, NULL, NULL, NULL, NULL, NULL);
insert into `employees` (`id`, `schoolid`, `userid`, `employee_category_id`, `employee_number`, `joining_date`, `first_name`, `last_name`, `gender`, `job_title`, `employee_position_id`, `employee_department_id`, `reporting_manager_id`, `employee_grade_id`, `qualification`, `experience_detail`, `experience_year`, `experience_month`, `status`, `status_description`, `date_of_birth`, `marital_status`, `children_count`, `father_name`, `mother_name`, `husband_name`, `blood_group`, `nationality_id`, `home_address_line1`, `home_address_line2`, `home_city`, `home_state`, `home_country_id`, `home_pin_code`, `office_address_line1`, `office_address_line2`, `office_city`, `office_state`, `office_country_id`, `office_pin_code`, `office_phone1`, `office_phone2`, `mobile_phone`, `home_phone`, `email`, `fax`, `photo_file_name`, `photo_content_type`, `photo_data`, `created_at`, `updated_at`, `photo_file_size`, `user_id`) values ('6', '2', '16', '5', '1105', '2011-11-17', 'Ajay', 'Sharma', '0', NULL, '3', '5', NULL, NULL, '', '', '0', '0', '1', NULL, '1987-00-24', 'Single', '0', '', '', '', '1', '1', '', '', '', '', '1', '', '', '', '', '', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

drop table if exists `employees_subjects`;
CREATE TABLE `employees_subjects` (
  `id` int(11) NOT NULL auto_increment,
  `employee_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_employees_subjects_on_subject_id` (`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`) values ('1', '1', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`) values ('3', '2', '4');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`) values ('4', '2', '5');

drop table if exists `events`;
CREATE TABLE `events` (
  `id` int(11) NOT NULL auto_increment,
  `schoolid` int(11) NOT NULL,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  `start_date` datetime default NULL,
  `end_date` datetime default NULL,
  `is_common` tinyint(1) default '0',
  `is_holiday` tinyint(1) default '0',
  `is_exam` tinyint(1) default '0',
  `is_due` tinyint(1) default '0',
  `is_active` int(1) NOT NULL default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_events_on_is_common_and_is_holiday_and_is_exam` (`is_common`,`is_holiday`,`is_exam`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `events` (`id`, `schoolid`, `title`, `description`, `start_date`, `end_date`, `is_common`, `is_holiday`, `is_exam`, `is_due`, `is_active`, `created_at`, `updated_at`) values ('6', '1', 'dfgdf', 'dfgdfg', '2011-11-15 12:00:00', '2011-11-15 12:00:00', '0', '1', '0', '0', '0', '2011-11-22 10:09:35', NULL);
insert into `events` (`id`, `schoolid`, `title`, `description`, `start_date`, `end_date`, `is_common`, `is_holiday`, `is_exam`, `is_due`, `is_active`, `created_at`, `updated_at`) values ('7', '1', 'Last Working Day', 'last working day is a holiday', '2011-11-30 12:00:00', '2011-11-30 12:00:00', '1', '1', '0', '0', '1', '2011-11-17 12:47:57', NULL);
insert into `events` (`id`, `schoolid`, `title`, `description`, `start_date`, `end_date`, `is_common`, `is_holiday`, `is_exam`, `is_due`, `is_active`, `created_at`, `updated_at`) values ('8', '1', 'Occassion', 'Occassion Special wedding garments are often worn, and the ceremony is 
sometimes followed by a wedding reception. Music, poetry, prayers or readings from 
Scripturs or literature is also optionally incorporated into the ceremony.', '2011-11-18 12:00:00', '2011-11-18 12:00:00', '1', '1', '0', '0', '1', '2011-11-28 01:09:52', NULL);
insert into `events` (`id`, `schoolid`, `title`, `description`, `start_date`, `end_date`, `is_common`, `is_holiday`, `is_exam`, `is_due`, `is_active`, `created_at`, `updated_at`) values ('9', '2', 'event', 'Full MIME Support
supports MIME email messages, allowing users to receive attached pictures, multimedia content and
data contained in email messages. Users can compose email messages and attach files to outgoing
messages.
IMAP / IMAPs support
utilize', '2011-11-19 12:00:00', '2011-11-19 23:55:00', '0', '0', '0', '0', '1', '2011-11-29 12:36:51', NULL);

drop table if exists `exam_groups`;
CREATE TABLE `exam_groups` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `schoolid` int(11) NOT NULL,
  `batch_id` int(11) default NULL,
  `exam_type` varchar(255) collate utf8_unicode_ci default NULL,
  `is_published` tinyint(1) default '0',
  `result_published` tinyint(1) default '0',
  `exam_date` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('1', 'Terminal second', '1', '2', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('3', 'General', '1', '5', 'Marks', '0', '0', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('4', 'Fifth Terminal', '1', '5', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('5', 'Fifth Terminal', '1', '4', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('7', 'Half Yearly', '2', '6', 'Marks', '1', '1', NULL);

drop table if exists `exam_scores`;
CREATE TABLE `exam_scores` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `exam_id` int(11) default NULL,
  `marks` decimal(7,2) default NULL,
  `grading_level_id` int(11) default NULL,
  `remarks` varchar(255) collate utf8_unicode_ci default NULL,
  `is_failed` tinyint(1) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_exam_scores_on_student_id_and_exam_id` (`student_id`,`exam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('1', '1', '1', '50.00', '0', '', '0', '2011-11-14 11:48:25', '2011-11-25 12:00:38');
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('2', '2', '1', '55.00', '0', '', '0', '2011-11-14 11:48:25', '2011-11-25 12:00:38');
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('3', '4', '1', '75.00', '0', '', '0', '2011-11-14 11:48:26', '2011-11-25 12:00:38');
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('4', '1', '2', '60.00', '0', '', '0', '2011-11-14 11:48:58', '2011-11-25 12:01:39');
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('5', '2', '2', '65.00', '0', '', '0', '2011-11-14 11:48:58', '2011-11-25 12:01:39');
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('6', '4', '2', '73.00', '0', '', '0', '2011-11-14 11:48:58', '2011-11-25 12:01:39');
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('7', '3', '9', '65.00', '0', '', '0', '2011-11-16 02:35:51', NULL);
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('8', '5', '9', '91.00', '0', '', '0', '2011-11-16 02:35:51', NULL);
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('9', '3', '10', '0.00', '0', 'Due to Illness', '0', '2011-11-16 03:19:12', NULL);
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('10', '5', '10', '54.00', '0', '', '0', '2011-11-16 03:19:12', NULL);
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('11', '10', '11', '42.00', '0', '', '0', '2011-11-18 12:03:44', NULL);
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('12', '6', '8', '22.00', '0', '', '1', '2011-11-23 01:34:21', NULL);
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('13', '12', '8', '48.00', '0', '', '0', '2011-11-23 01:34:21', NULL);
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('14', '13', '8', '65.00', '0', '', '0', '2011-11-23 01:34:21', NULL);
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('15', '6', '7', '61.00', '0', '', '0', '2011-11-23 01:34:56', NULL);
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('16', '12', '7', '49.00', '0', '', '0', '2011-11-23 01:34:56', NULL);
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('17', '13', '7', '92.00', '0', '', '0', '2011-11-23 01:34:56', NULL);
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('18', '7', '1', '0.00', '0', 'Absent', '1', '2011-11-25 12:00:15', '2011-11-25 12:00:38');
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('19', '9', '1', '0.00', '0', 'Absent', '1', '2011-11-25 12:00:16', '2011-11-25 12:00:38');
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('20', '14', '1', '29.00', '0', '', '1', '2011-11-25 12:00:16', '2011-11-25 12:00:38');
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('21', '7', '2', '33.00', '0', '', '0', '2011-11-25 12:01:39', NULL);
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('22', '9', '2', '54.00', '0', '', '0', '2011-11-25 12:01:39', NULL);
insert into `exam_scores` (`id`, `student_id`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('23', '14', '2', '65.00', '0', '', '0', '2011-11-25 12:01:39', NULL);

drop table if exists `exams`;
CREATE TABLE `exams` (
  `id` int(11) NOT NULL auto_increment,
  `exam_group_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  `start_time` datetime default NULL,
  `end_time` datetime default NULL,
  `maximum_marks` decimal(10,2) default NULL,
  `minimum_marks` decimal(10,2) default NULL,
  `grading_level_id` int(11) default NULL,
  `weightage` int(11) default '0',
  `event_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_exams_on_exam_group_id_and_subject_id` (`exam_group_id`,`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('1', '1', '1', '2011-11-05 08:00:00', '2011-11-05 11:00:00', '100.00', '30.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('2', '1', '2', '2011-11-05 13:00:00', '2011-11-05 16:00:00', '100.00', '30.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('5', '3', '4', '2011-11-15 10:00:00', '2011-11-15 11:30:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('6', '3', '6', '2011-11-15 17:15:00', '2011-11-15 18:30:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('7', '4', '4', '2011-11-16 10:00:00', '2011-11-16 12:30:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('8', '4', '6', '2011-11-16 14:15:00', '2011-11-16 18:15:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('9', '5', '4', '2011-11-16 10:00:00', '2011-11-16 12:30:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('10', '5', '6', '2011-11-16 14:15:00', '2011-11-16 18:15:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('11', '7', '7', '2011-11-17 10:00:00', '2011-11-17 13:00:00', '100.00', '33.00', NULL, '0', NULL, NULL, NULL);

drop table if exists `grades`;
CREATE TABLE `grades` (
  `id` int(11) NOT NULL auto_increment,
  `schoolid` int(11) NOT NULL,
  `grade_name` varchar(255) collate utf8_unicode_ci default NULL,
  `code` varchar(255) collate utf8_unicode_ci default NULL,
  `section_name` varchar(255) collate utf8_unicode_ci default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `grades` (`id`, `schoolid`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('1', '1', '8', 'G01', NULL, '0', NULL, NULL);
insert into `grades` (`id`, `schoolid`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('2', '1', '11', 'f02', NULL, '0', NULL, NULL);
insert into `grades` (`id`, `schoolid`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('3', '2', '9', 'H01', NULL, '0', NULL, NULL);

drop table if exists `grades_template`;
CREATE TABLE `grades_template` (
  `id` int(11) NOT NULL auto_increment,
  `grade_name` varchar(255) collate utf8_unicode_ci default NULL,
  `code` varchar(255) collate utf8_unicode_ci default NULL,
  `section_name` varchar(255) collate utf8_unicode_ci default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `grades_template` (`id`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('1', '11', NULL, NULL, '0', NULL, NULL);
insert into `grades_template` (`id`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('2', '10', NULL, NULL, '0', NULL, NULL);

drop table if exists `grading_levels`;
CREATE TABLE `grading_levels` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `min_score` int(11) default NULL,
  `order` int(11) default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_grading_levels_on_batch_id_and_is_deleted` (`batch_id`,`is_deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `grading_levels` (`id`, `name`, `batch_id`, `min_score`, `order`, `is_deleted`, `created_at`, `updated_at`) values ('1', 'A+', '4', '95', NULL, '0', '2011-11-11 11:58:30', NULL);
insert into `grading_levels` (`id`, `name`, `batch_id`, `min_score`, `order`, `is_deleted`, `created_at`, `updated_at`) values ('2', 'A', '4', '85', NULL, '0', '2011-11-11 11:58:40', NULL);
insert into `grading_levels` (`id`, `name`, `batch_id`, `min_score`, `order`, `is_deleted`, `created_at`, `updated_at`) values ('3', 'B+', '4', '75', NULL, '0', '2011-11-11 11:59:06', NULL);
insert into `grading_levels` (`id`, `name`, `batch_id`, `min_score`, `order`, `is_deleted`, `created_at`, `updated_at`) values ('4', 'A', '6', '90', NULL, '0', '2011-11-17 12:49:38', NULL);
insert into `grading_levels` (`id`, `name`, `batch_id`, `min_score`, `order`, `is_deleted`, `created_at`, `updated_at`) values ('5', 'B', '6', '75', NULL, '0', '2011-11-17 12:49:49', NULL);
insert into `grading_levels` (`id`, `name`, `batch_id`, `min_score`, `order`, `is_deleted`, `created_at`, `updated_at`) values ('6', 'C', '6', '60', NULL, '0', '2011-11-17 12:50:01', NULL);

drop table if exists `grouped_exams`;
CREATE TABLE `grouped_exams` (
  `id` int(11) NOT NULL auto_increment,
  `exam_group_id` int(11) default NULL,
  `batch_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_grouped_exams_on_batch_id` (`batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `grouped_exams` (`id`, `exam_group_id`, `batch_id`) values ('1', '2', '4');
insert into `grouped_exams` (`id`, `exam_group_id`, `batch_id`) values ('2', '7', '6');

drop table if exists `guardians`;
CREATE TABLE `guardians` (
  `id` int(11) NOT NULL auto_increment,
  `ward_id` int(11) default NULL,
  `userid` int(11) NOT NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `relation` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `parent_id_card` varchar(255) collate utf8_unicode_ci NOT NULL,
  `office_phone1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone2` varchar(255) collate utf8_unicode_ci default NULL,
  `mobile_phone` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `city` varchar(255) collate utf8_unicode_ci default NULL,
  `state` varchar(255) collate utf8_unicode_ci default NULL,
  `country_id` int(11) default NULL,
  `dob` date default NULL,
  `occupation` varchar(255) collate utf8_unicode_ci default NULL,
  `income` varchar(255) collate utf8_unicode_ci default NULL,
  `education` varchar(255) collate utf8_unicode_ci default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `guardians` (`id`, `ward_id`, `userid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('1', '3', '7', 'Ravindra', 'Singh', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('3', '7', '12', 'kk', 'kumar', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('4', '8', '13', 'Ramesh', 'Singh', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('5', '9', '14', 'm', 'qwergt', 'ddwe', NULL, '5251.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('6', '10', '17', 'Rajesh', 'Sen', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('7', '11', '18', 'Ram', 'Singh', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('8', '12', '19', 'Yashpal', 'Singh', 'Father', NULL, '8601.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('9', '13', '21', 'Swaroop', 'Gupta', 'Father', NULL, '9833.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('10', '1', '22', 'Jai', 'Prakash', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('11', '14', '23', 'Abdul', 'Khan', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('12', '18', '24', 'Aarti', 'Singh', 'Mother', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

drop table if exists `label_values`;
CREATE TABLE `label_values` (
  `id` int(11) NOT NULL auto_increment,
  `lb` varchar(200) NOT NULL,
  `en_value` varchar(1000) character set utf8 collate utf8_bin default NULL,
  `ar_value` varchar(1000) character set utf8 collate utf8_bin default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1404 DEFAULT CHARSET=latin1; 
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1', 'LNG_SAVE_AND_PROCEED', 'Save & Proceed', '????? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('2', 'LNG_CHANGE_LANG', 'Change Language', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('3', 'LNG_NEW', 'New', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('4', 'LNG_HOME', 'Home', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('5', 'LNG_ADD', 'Add', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('6', 'LNG_EDIT', 'Edit', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('7', 'LNG_DELETE', 'Delete', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('8', 'LNG_ENABLE', 'Enable', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('9', 'LNG_DISABLE', 'Disable', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('10', 'LNG_SAVE', 'Save', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('11', 'LNG_SUBMIT', 'Submit', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('12', 'LNG_REPLY', 'Reply', '??');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('13', 'LNG_SUBMIT', 'Finish', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('14', 'LNG_GO', 'Go', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('15', 'LNG_VIEW', 'View', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('16', 'LNG_CREATE', 'Create', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('17', 'LNG_UPDATE', 'Update', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('18', 'LNG_SHOW', 'Show', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('19', 'LNG_NAME', 'Name', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('20', 'LNG_START_DATE', 'Start date', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('21', 'LNG_END_DATE', 'End date', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('22', 'LNG_CONFIGURATION', 'Configuration', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('23', 'LNG_CONFIGURATION_HOME', 'Configuration Home', '??????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('24', 'LNG_BATCHES', 'Classes', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('25', 'LNG_MANAGE_BATCHES', 'Manage Classes', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('26', 'LNG_BATCH', 'Class', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('27', 'LNG_BATCH_NAME', 'Class Name', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('28', 'LNG_NEW_BATCH', 'New Class', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('29', 'LNG_SELECT_A_BATCH', 'Select a class', '??? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('30', 'LNG_ACTIVE_BATCHES', 'Active Classes', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('31', 'LNG_EDIT_BATCHES', 'Edit Class', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('32', 'LNG_NO_BATCHES_AVAILABLE', 'No Class Available.', '?? ??? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('33', 'LNG_CODE', 'Code', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('34', 'LNG_GRADES', 'Grades', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('35', 'LNG_NEWGRADES', 'New Grades', '?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('36', 'LNG_GRADE_NAME', 'Grade Name', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('37', 'LNG_MANAGE_GRADE', 'Manage Grade', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('38', 'LNG_SELECT_A_GRADE', 'Select a grade', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('39', 'LNG_MANAGE_GRADES', 'Manage Grades', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('40', 'LNG_SELECT_GRADE', 'Select a grade:', '??? ???? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('41', 'LNG_MANAGE_GRADES_BATCHES', 'Manage Grades / Classes', '????? ?????? / ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('42', 'LNG_ADDNEW_COURSE_OR_BATCH', 'Add a new Grades or Classes for this academic year.', '????? ?????? ????? ?? ???? ???? ????? ???????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('43', 'LNG_MANAGE_CREATE_GRADES', 'Manage Grades and create grades', '????? ?????? ???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('44', 'LNG_MANAGE_BATCHES', 'Manage Classes', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('45', 'LNG_MANAGE_ACTIVE_BATCHES', 'Manage Active Classes', '????? ?????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('46', 'LNG_GRADES_S', 'grades', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('47', 'LNG_GRADE', 'Grade', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('48', 'LNG_SUBJECT', 'Course', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('49', 'LNG_SELECT_A_SUBJECT', 'Select a Course', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('50', 'LNG_SUBJECTS', 'Courses', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('51', 'LNG_ADD_SUBJECT', 'Add Course', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('52', 'LNG_ADD_SUBJECTS', 'Add Courses', '????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('53', 'LNG_SELECT_SUBJECTS', 'Select Courses', '??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('54', 'LNG_ADD_NEW_SUBJECT', 'Add New Course', '????? ???? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('55', 'LNG_MANAGE_SUBJECTS', 'Manage Courses', '????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('56', 'LNG_MANAGE_SUBJECTS_CORRESPONDING_TO_GRADES', 'Manage courses corresponding to different grades.', '????? ???????? ???????? ?????? ???????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('57', 'LNG_SLNO', 'Sl.no', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('58', 'LNG_ADMISSION_NO', 'Admission Number', '???? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('59', 'LNG_STUDENT_ADMISSION_NO', 'Student Admission Number', '???? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('60', 'LNG_ADM_NO', 'Adm No.', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('61', 'LNG_VIEW_PROFILE', 'View Profile', '??? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('62', 'LNG_STUDENT_DETAILS', 'Student Details', '???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('63', 'LNG_VIEW_DETAILS', 'View Details', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('64', 'LNG_INITIAL_BATCH_DETAIL', 'Initial batch details', '?????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('65', 'LNG_STUDENTS', 'Students', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('66', 'LNG_REPORTS_CENTER', 'Reports center', '?????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('67', 'LNG_ACADEMICS', 'Academics', '???????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('68', 'LNG_RECENT_EXAMS', 'Recent exams', '???????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('69', 'LNG_SUBJECTWISE_RESULTS', 'Coursewise results', '????? ???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('70', 'LNG_DETAILED_REPORTS', 'Detailed reports', '?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('71', 'LNG_CURRENT_YEAR_REPORTS', 'Current year reports', '?????? ????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('72', 'LNG_STUDENT_INFO', 'Student Info', '???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('73', 'LNG_STUDENT_PROFILE', 'Student Profile', '?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('74', 'LNG_GUARDIANS', 'Guardians', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('75', 'LNG_ADMISSION_DATE', 'Admission Date', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('76', 'LNG_DOB', 'Date of birth', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('77', 'LNG_NATIONALITY', 'Nationality', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('78', 'LNG_RELIGION', 'Religion', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('79', 'LNG_ADDRESS', 'Address', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('80', 'LNG_PHONE', 'Phone', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('81', 'LNG_PHONENO', 'Phone No.', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('82', 'LNG_PARENTS_INFO', 'Parent Information', '??????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('83', 'LNG_EDIT_DETAILS', 'Edit details', '????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('84', 'LNG_STUDENT_DETAILS', 'Student details', '???? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('85', 'LNG_STEP_1_STUDENT_DETAILS', 'Step 1 - Student details', '?????? 1 -- ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('86', 'LNG_STEP_2_PARENT_DETAILS', 'Step 2 - Parent/guardian details', '?????? 2 -- ???? / ????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('87', 'LNG_ADMISSION', 'Admission', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('88', 'LNG_EDIT_PARENT_DETAIL', 'Edit Parent/guardian details', '????? ???????? / ????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('89', 'LNG_PARENTS_GUARDIANS', 'Parents/Guardian', '?????? / ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('90', 'LNG_RELATION', 'Relation', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('91', 'LNG_USERNAME', 'Username', '??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('92', 'LNG_PASSWORD', 'Password', '???? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('93', 'LNG_PARENT_PERSONAL_DETAIL', 'Parent - Personal Details', '????? -- ?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('94', 'LNG_FIRST_NAME', 'First Name', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('95', 'LNG_MIDDLE_NAME', 'Middle Name', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('96', 'LNG_LAST_NAME', 'Last Name', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('97', 'LNG_RELATIONSHIP', 'Relationship', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('98', 'LNG_UPLOAD_PARENT_ID_CARD', 'Upload Parent ID Card photo', '??? ???? ????? ?????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('99', 'LNG_PARENT_USERNAME', 'Parent Username', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('100', 'LNG_PARENT_PASSWORD', 'Parent Password', '???? ???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('101', 'LNG_FIELDS_MARKED_WITH', 'Fields marked with', '?????? ???? ???? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('102', 'LNG_MUST_BE_FILLED', 'must be filled.', '??? ?? ???? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('103', 'LNG_PERSONAL_DETAIL', 'Personal Details', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('104', 'LNG_PASSPORT_OR_ID', 'Passport / ID Card', '???? ????? / ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('105', 'LNG_ID', 'ID', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('106', 'LNG_PASSPORT', 'Passport', '???? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('107', 'LNG_TITLE', 'Title', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('108', 'LNG_SENT_ON', 'Sent on', '????? ??');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('109', 'LNG_GRADE_AND_BATCH', 'Grade & Class', '???? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('110', 'LNG_CONTACT_DETAILS', 'Contact Details', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('111', 'LNG_UPLOAD_USER_PHOTO', 'Upload User Photo', '????? ????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('112', 'LNG_UPLOAD_PHOTO', 'Upload photo (250KB max)', '??? ???? (250 ???????? ??? ????)');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('113', 'LNG_UPLOAD_BIRTH_CERTIFICATE', 'Upload Birth Certificate photo', '????? ???? ????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('114', 'LNG_MESSAGE_STUDENT_RECORD_SAVED', 'Student Record Saved Successfully. Please fill the Parent Details.', '???????? ??? ?????? ?????. ?????? ??? ?????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('115', 'LNG_ATTENDANCE', 'Attendance', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('116', 'LNG_ATTENDANCE_HOME', 'Attendance Home', '?????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('117', 'LNG_ATTENDANCE_REGISTER', 'Attendance Register', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('118', 'LNG_ATTENDANCE_REGISTER_FOR_STUDENTS', 'Attendance register for students', '????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('119', 'LNG_MANAGE_ATTENDANCE_REGISTER', 'Manage Attendance Register', '????? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('120', 'LNG_CREATE_UPDATE_ATTENDANCE_REGISTER', 'Create and update attendance register', '????? ?????? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('121', 'LNG_ATTENDANCE_REPORT', 'Attendance Report', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('122', 'LNG_ATTENDANCE_REPORT_OF_STUDENTS', 'Attendance report of students', '????? ?????? ?? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('123', 'LNG_REASON_FOR_ABSENCE', 'Reason for absence', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('124', 'LNG_ATTENDANCE_FOR', 'Attendance for', '?????? ??');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('125', 'LNG_FROM', 'From :', '?? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('126', 'LNG_TO', 'To :', '??? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('127', 'LNG_PUBLISH_REGISTER', 'Publish Register', '??? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('128', 'LNG_EVENTS', 'Events', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('129', 'LNG_EXAMINATIONS', 'Examinations', '??????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('130', 'LNG_HOLIDAYS', 'Holidays', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('131', 'LNG_SUNDAY', 'Sunday', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('132', 'LNG_MONDAY', 'Monday', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('133', 'LNG_TUESDAY', 'Tuesday', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('134', 'LNG_WEDNESDAY', 'Wednesday', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('135', 'LNG_THURSDAY', 'Thursday', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('136', 'LNG_FRIDAY', 'Friday', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('137', 'LNG_SATURDAY', 'Saturday', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('138', 'LNG_IS_HOLIDAY', 'Is Holiday?', '?? ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('139', 'LNG_COMMON', 'Common', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('140', 'LNG_EVENT_COMMON_TO_ALL', 'Event common to all', '???????? ????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('141', 'LNG_CREATE_EVENT', 'Create Event', '????? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('142', 'LNG_UPDATE_EVENT', 'Update Event', '??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('143', 'LNG_STEP1_EVENT_CREATE', 'Step 1 - Event creation', '?????? 1 -- ????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('144', 'LNG_STEP2_CONFIRMATION', 'Step 2 - Confirmation', '?????? 2 -- ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('145', 'LNG_SEPERATOR_1', ':', ':');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('146', 'LNG_SEPERATOR_2', '-', '--');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('147', 'LNG_DESCRIPTION', 'Description', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('148', 'LNG_OTHER_EVENTS', 'Other Events', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('149', 'LNG_THIS_EVENT_IS_COMMON_ACROSS_ALL_CLASSES', 'This event is common across all classes', '??? ????? ?? ????? ??? ???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('150', 'LNG_COURSES_ASSOCIATED', 'Courses Associated', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('151', 'LNG_NO_CLASS_SELECTED_FOR_THIS_EVENT', 'No class selected for this event yet', '?? ??? ?????? ???? ????? ??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('152', 'LNG_SELECT_MORE_COURSES', 'Select more Courses', '????? ???? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('153', 'LNG_REMOVE', 'Remove', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('154', 'LNG_CANCEL', 'Cancel', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('155', 'LNG_WELCOME_MESSAGE1', 'Welcome', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('156', 'LNG_WELCOME_MESSAGE2', 'to My School dashboard', '???? ??????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('157', 'LNG_ADD_SCHOOL', 'Add School', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('158', 'LNG_STEP1_SCHOOL_DETAILS', 'Step 1 - School details', '?????? 1 -- ?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('159', 'LNG_SCHOOL_NAME', 'School/College Name', '??????? / ?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('160', 'LNG_SCHOOL_ADDRESS', 'School/College Address', '??????? / ?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('161', 'LNG_SCHOOL_PHONE', 'School/College Phone', '??????? / ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('162', 'LNG_SCHOOL_FAX_NO', 'School/College Fax No.', '??????? / ?????? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('163', 'LNG_UPLOAD_LOGO', 'Upload Logo', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('164', 'LNG_SCHOOL_DETAILS', 'School Details', '??????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('165', 'LNG_VIEW_SCHOOLS', 'View Schools', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('166', 'LNG_ADD_SECRETARY', 'Add Secretary', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('167', 'LNG_MANAGE_SECRETARY', 'Manage Secretary', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('168', 'LNG_MY_PROFILE', 'My Profile', '???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('169', 'LNG_TIMETABLE', 'Timetable', '?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('170', 'LNG_SETTINGS', 'Settings', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('171', 'LNG_MANAGE_EMPLOYEE', 'Manage Employee', '????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('172', 'LNG_CREATE_EDIT_TIMETABLE', 'Create/Edit Timetable', '????? / ????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('173', 'LNG_TIMETABLE_TEXT2', 'Select a class and edit the timetable for that class.', '????? ?????? ?????? ?????? ?????? ???? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('174', 'LNG_SET_CLASS_TIMINGS', 'Set class timings', '??? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('175', 'LNG_TIMETABLE_TEXT3', 'Select a class and edit the timetable for that class.', '????? ?????? ?????? ?????? ?????? ???? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('176', 'LNG_VIEW_TIMETABLE', 'View Timetables', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('177', 'LNG_TIMETABLE_TEXT4', 'View the timetable for a class.', '??? ???? ???? ????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('178', 'LNG_CREATE_WEEKDAYS', 'Create weekdays', '????? ???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('179', 'LNG_SELECT_CLASS_TO_EDIT', 'Select class to edit', '??? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('180', 'LNG_EDIT_BATCH', 'Edit Class', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('181', 'LNG_ADD_SUBJECTS_EMPLOYEE', 'Add Subjects/Employee', '????? ?????? / ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('182', 'LNG_SET_IN_COMMON', 'Set in common', '?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('183', 'LNG_START_TIME', 'Start time', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('184', 'LNG_END_TIME', 'End time', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('185', 'LNG_OPERATIONS', 'Operations', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('186', 'LNG_IS_A_BREAK', 'Is a break', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('187', 'LNG_EDIT_CLASSTIMINGS_FOR', 'Edit class timing for', '????? ????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('188', 'LNG_ADD_NEW_CLASSTIMINGS_FOR', 'Add new class timing for', '????? ????? ??????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('189', 'LNG_SELECT_BATCH_TO_VIEW', 'Select class to view', '??? ??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('190', 'LNG_WEEKDAYS', 'Weekdays', '???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('191', 'LNG_TEACHER', 'Teacher', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('192', 'LNG_EMPLOYEE_SETTINGS', 'Employee settings.', '??? ????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('193', 'LNG_EMPLOYEE_MANAGEMENT', 'Employee Management', '???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('194', 'LNG_MANAGE_ALL_EMPLOYEE', 'Manage all employees', '????? ???? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('195', 'LNG_EMPLOYEE_LIST', 'Employee List', '????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('196', 'LNG_SEARCH_FOR_EMPLOYEES', 'Search for employees', '????? ?? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('197', 'LNG_ADD_EMP_CATEGORY', 'Add employee category', '????? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('198', 'LNG_EMP_TEXT2', 'Add and edit employee category.', '????? ?????? ??? ??????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('199', 'LNG_ADD_EMP_POSITION', 'Add employee position', '????? ???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('200', 'LNG_EMP_TEXT3', 'Add and edit employee position.', '????? ?????? ???? ????????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('201', 'LNG_ADD_EMP_DEPT', 'Add employee department', '????? ??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('202', 'LNG_EMP_TEXT4', 'Add and edit employee department.', '????? ?????? ??? ??????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('203', 'LNG_PREFIX', 'Prefix', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('204', 'LNG_STATUS', 'Status', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('205', 'LNG_ACTIVE_CATEGORIES', 'Active Categories', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('206', 'LNG_INACTIVE_CATEGORIES', 'Inactive Categories', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('207', 'LNG_EMP_CATEGORY', 'Employee category', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('208', 'LNG_ACTIVE_POSITIONS', 'Active Positions', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('209', 'LNG_INACTIVE_POSITIONS', 'Inactive Positions', '????? ??? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('210', 'LNG_DEPT_CODE', 'Dept. code', '??? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('211', 'LNG_ACTIVE_DEPARTMENTS', 'Active Departments', '???????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('212', 'LNG_INACTIVE_DEPARTMENTS', 'Inactive Departments', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('213', 'LNG_EMP_ADMISSION', 'Employee admission', '???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('214', 'LNG_EMP_ADMISSION_FORM', 'Employee admission form', '?????? ???? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('215', 'LNG_EMP_SUBJECT_ASSOCIATION', 'Employee Subject Association', '????? ?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('216', 'LNG_EMP_TEXT5', 'Assign an employee with one or more subjects', '????? ???? ???? ?? ???? ?? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('217', 'LNG_EMP_CLASS_ASSOCIATION', 'Employee Class Association', '???? ??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('218', 'LNG_EMP_TEXT6', 'Assign an employee with one or more class', '????? ???? ???? ?? ???? ?? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('219', 'LNG_STEP1', 'Step-1', '???? 1');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('220', 'LNG_GENERAL_DETAILS', 'General Details', '?????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('221', 'LNG_EMP_NO', 'Employee no.', '?? ????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('222', 'LNG_JOINING_DATE', 'Joining date.', '????? ????????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('223', 'LNG_GENDER', 'Gender', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('224', 'LNG_DEPT', 'Department', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('225', 'LNG_CATEGORY', 'Category', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('226', 'LNG_POSITION', 'Position', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('227', 'LNG_QUALIFICATION', 'Qualification', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('228', 'LNG_EXP_INFO', 'Experience Info', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('229', 'LNG_TOTAL_EXP', 'Total Experience', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('230', 'LNG_MARTIAL_STATUS', 'Marital status', '?????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('231', 'LNG_NO_OF_CHILD', 'No. of children', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('232', 'LNG_FATHER_NAME', 'Father name', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('233', 'LNG_MOTHER_NAME', 'Mother name', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('234', 'LNG_SPOUSE_NAME', 'Spouse name', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('235', 'LNG_BLOOD_GROUP', 'Blood group', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('236', 'LNG_STEP2', 'Step-2', '???? 2');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('237', 'LNG_HOME_ADDRESS', 'Home Address', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('238', 'LNG_LINE1', 'Line 1', '????? 1');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('239', 'LNG_LINE2', 'Line 2', '????? 2');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('240', 'LNG_CITY', 'City', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('241', 'LNG_STATE', 'State', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('242', 'LNG_COUNTRY', 'Country', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('243', 'LNG_PIN', 'PIN', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('244', 'LNG_OFFICE_ADDRESS', 'Office Address', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('245', 'LNG_SKIP_THIS_STEP', 'Skip This Step', '???? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('246', 'LNG_EMP_RECORD_SAVED', 'Employee record saved', '??? ?????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('247', 'LNG_EMP_PROFILE', 'Employee Profile', '?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('248', 'LNG_DETAILS', 'Details', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('249', 'LNG_PROFILE', 'Profile', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('250', 'LNG_GENERAL', 'General', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('251', 'LNG_PERSONAL', 'Personal', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('252', 'LNG_ADDRESS', 'Address', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('253', 'LNG_YEARS', 'Years', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('254', 'LNG_MONTHS', 'Months', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('255', 'LNG_EDIT_EMP_INFO', 'Edit employee information', '????? ??????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('256', 'LNG_EMPLOYEE_SUBJECT', 'Employee Subject', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('257', 'LNG_ASSOCIATE', 'Associate', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('258', 'LNG_EMPLOYEE_CLASS', 'Employee Class', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('259', 'LNG_EMPLOYEES', 'Employees', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('260', 'LNG_CURRENTLY_ASSIGNED', 'Currently assigned:', '??????? ????? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('261', 'LNG_NO_EMPLYEES_ASSIGNED', 'No employee assigned yet.', '????? ?? ???? ??? ????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('262', 'LNG_SELECT_DEPARTMENT', 'Select department', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('263', 'LNG_NO_EMPLOYEES_IN_DEPARTMENT', 'No employee in this department.', '?? ???? ?? ??? ???????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('264', 'LNG_ASSIGN_NEW', 'Assign new:', '????? ???? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('265', 'LNG_ASSIGN', 'Assign', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('266', 'LNG_VIEW_ALL', 'View all', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('267', 'LNG_VIEW_ALL_S', 'view all', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('268', 'LNG_SELECT_A_DEPARTMENT', 'Select a Department :', '??? ????? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('269', 'LNG_SELECT_EMPLOYEE', 'Select Employee', '?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('270', 'LNG_EXAMS', 'Exams', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('271', 'LNG_EXAM', 'Exam', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('272', 'LNG_SET_GRADING_LEVELS', 'Set grading levels', '????? ??????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('273', 'LNG_EXAM_TXT2', 'Set the Grading Levels', '????? ??????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('274', 'LNG_EXAM_MANAGEMENT', 'Exam Management', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('275', 'LNG_EXAM_TXT3', 'Create new exams, enter results.', '????? ???????? ????? ? ?????? ???????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('276', 'LNG_EXAM_WISE_REPORT', 'Exam Wise report', '????? ???????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('277', 'LNG_EXAM_TXT4', 'Generates reports Exam wise', '???? ?????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('278', 'LNG_SUBJECT_WISE_REPORT', 'Subject Wise report', '????? ??????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('279', 'LNG_EXAM_TXT5', 'Generates reports Subject wise', '???? ?????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('280', 'LNG_GROUPED_EXAM_REPORT', 'Grouped Exam report', '????? ?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('281', 'LNG_EXAM_TXT6', 'Group up exams for specific reports', '??? ?????? ???????? ???????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('282', 'LNG_GRADING_LEVELS', 'Grading levels', '????? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('283', 'LNG_ADD_GRADES', 'Add Grades', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('284', 'LNG_MIN_SCORE', 'Min score', '???? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('285', 'LNG_ADD_NEW_GRADING_LEVEL', 'Add new grading level', '????? ????? ??? ????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('286', 'LNG_MIN_SCORE_FOR_THIS_GRADE', 'Min score for this grade', '???? ????? ???? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('287', 'LNG_EDIT_GRADING_LEVEL', 'Edit grading level', '????? ????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('288', 'LNG_CREATE_EXAM', 'Create Exam', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('289', 'LNG_EXAM_GROUPS', 'Exam groups', '?????? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('290', 'LNG_CONNECT_EXAMS', 'Connect exams', '??????? ??????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('291', 'LNG_EXAM_NAME', 'Exam name', '??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('292', 'LNG_ACTION', 'Action', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('293', 'LNG_EXAM_RESULT_PUBLISHED', 'Exam result published.', '????? ?????? ????????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('294', 'LNG_SCHEDULED_PUBLISHED', 'Schedule published.', '???? ????????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('295', 'LNG_PUBLISH_EXAM_RESULT', 'Publish Exam Result', '??? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('296', 'LNG_PUBLISH_EXAM_SCHEDULE', 'Publish Exam Schedule', '??? ???? ??????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('297', 'LNG_SHOWING_EXAM_GROUPS', 'Showing Exam groups', '??? ????????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('298', 'LNG_MAX_MARKS', 'Max marks', '???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('299', 'LNG_MIN_MARKS', 'Min marks', '?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('300', 'LNG_MANAGE', 'Manage', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('301', 'LNG_EDIT_EXAM', 'Edit Exam', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('302', 'LNG_FOR_EXAM_GROUP', 'For exam group', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('303', 'LNG_MAXIMUM_MARKS', 'Maximum Marks', '???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('304', 'LNG_MINIMUM_MARKS', 'Minimum Marks', '???? ?????? ?? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('305', 'LNG_RESULT_ENTRY', 'Result Entry', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('306', 'LNG_MARKS', 'Marks', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('307', 'LNG_REMARKS_ETC', 'Remarks(absent/disqualified etc)', '??????? (??? ???? / ????)');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('308', 'LNG_NEW_EXAM', 'New Exam', '?????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('309', 'LNG_EXAM_TYPE', 'Exam Type', '??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('310', 'LNG_MARKS_AND_GRADES', 'MarksAndGrades', '???????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('311', 'LNG_SELECT_EXAM_GROUP', 'Select exam group', '??? ???????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('312', 'LNG_GENERATED_REPORT', 'Generated Report', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('313', 'LNG_CONSOLIDATED_REPORT', 'Consolidated Report', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('314', 'LNG_OBTAINED_MARKS', 'Obtained Marks', '?????? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('315', 'LNG_PERCENTAGE', 'Percentage(%)', '?????? ??????? (?)');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('316', 'LNG_TOTAL_MARKS', 'Total Marks:', '????? ???????? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('317', 'LNG_BATCH_AVERAGE_MARKS', 'Class Average Marks', '????? ?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('318', 'LNG_BATCH_AVERAGE_PERCENT', 'Class Average %', '??? ????? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('319', 'LNG_SUBJECT_WISE_REPORT', 'Subject wise Reports', '?????? ?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('320', 'LNG_GROUPING', 'Grouping', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('321', 'LNG_GROUPED_EXAM_REPORT', 'Grouped exam Reports', '?????? ????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('322', 'LNG_NO_RECORD_AVAILABLE', 'No Record Available.', '?? ??? ????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('323', 'LNG_TOTAL', 'Total', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('324', 'LNG_AGGREGATE_PERCENT', 'Aggregate %', '????????? ?');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('325', 'LNG_ENTER_EXAM_RELATED_DETAIL', 'Enter exam related details here:', '????? ???????? ???????? ???????? ??? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('326', 'LNG_SUBJECT_NAME', 'Course name', '?????? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('327', 'LNG_DO_NOT_CREATE', 'Do not create', '?? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('328', 'LNG_SAVE_CHANGES', 'Save Changes', '??? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('329', 'LNG_PUBLISH_RESULT', 'Publish Result', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('330', 'LNG_QUESTIONAIRE', 'Questionnaire', '?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('331', 'LNG_GENERAL_LIST', 'General List', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('332', 'LNG_ARCHIVE_LIST', 'Archive List', '????? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('333', 'LNG_ACTIVE_LIST', 'Active List', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('334', 'LNG_SUMMARY', 'Summary', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('335', 'LNG_FULL_DESCRIPTION', 'Full Description :', '???? ????? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('336', 'LNG_DATE', 'Date', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('337', 'LNG_FINAL_REPORT_EXAM_GROUPED', 'Final Report(Exams Grouped)', '??????? ??????? (?????????? ?????)');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('338', 'LNG_COMPARE_WITH_PAST_YEARS', 'Compare with past years (Exams Grouped)', '?????? ?? ??????? ??????? (?????????? ?????)');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('339', 'LNG_TEACHER_TIMETABLE', 'Teacher Time-table', '?????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('340', 'LNG_CREATE_SECRETARY', 'Create Secretary', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('341', 'LNG_ADD_NEW_SECRETARY', 'Add new Secretary', '????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('342', 'LNG_EMAIL', 'Email', '?????? ??????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('343', 'LNG_SCHOOL', 'School', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('344', 'LNG_DETAILS_ABOUT_SECRETARY', 'Details about Secretaries', '?????? ??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('345', 'LNG_ADD_NEW', 'Add new', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('346', 'LNG_SEARCH_SECRETARY', 'Search Secretaries', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('347', 'LNG_ALL_USERS', 'All Users', '???? ??????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('348', 'LNG_SECRETARY_PROFILE', 'Secretary Profile', '???????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('349', 'LNG_SECRETARY_INFORMATION', 'Secretary Information', '???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('350', 'LNG_CHANGE_PASSWORD', 'Change Password', '????? ???? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('352', 'LNG_EDIT_PROFILE', 'Edit Profile', '????? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('353', 'LNG_DETAILS_ABOUT_USERS', 'Details about users', '?????? ??? ??????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('354', 'LNG_SELECT_A_SCHOOL', 'Select a School', '?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('355', 'LNG_REMOVE_STUDENT', 'Remove student', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('356', 'LNG_STUDENT_LEAVING_INSTITUTE', 'Student leaving Institution', '???? ??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('357', 'LNG_REMOVE_STUDENT_TEXT1', 'For students leaving the Institution, use this option to remove them from the list of active students and place them in the former students list.', '?????? ??? ???????? ???????? ??? ?????? ???????? ?? ????? ?????? ????? ?????? ?? ????? ?????? ????????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('358', 'LNG_REMOVE_STUDENT_RECORDS', 'Remove student records', '????? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('359', 'LNG_ID', 'Completely delete student\'s records from the Institution\'s databases. Use this option only if you created the student record by accident and want to remove it completely.', '??? ????? ????? ?????? ?? ????? ?????? ???????. ??????? ??? ?????? ??? ??? ??? ?????? ??? ?????? ?? ???? ?????? ????? ?????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('360', 'LNG_REMOVE_STUDENT_TEXT2', 'Completely delete student\'s records from the Institution\'s databases. Use this option only if you created the student record by accident and want to remove it completely.', '??? ????? ????? ?????? ?? ????? ?????? ???????. ??????? ??? ?????? ??? ??? ??? ?????? ??? ?????? ?? ???? ?????? ????? ?????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('361', 'LNG_LEAVING_SCHOOL', 'Leaving school', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('362', 'LNG_REASON_FOR_LEAVING', 'Reason for leaving', '??? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('363', 'LNG_BATCH_TEACHER', 'Class Teacher', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('364', 'LNG_COMMENTS', 'Comments', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('365', 'LNG_UPDATE_SECRETARY', 'Update Secretary', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('366', 'LNG_EDIT_SECRETARY', 'Edit Secretary', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('367', 'LNG_EDIT_USER', 'Edit User', '????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('368', 'LNG_UPDATE_USER_INFO', 'Update user information', '????? ??????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('369', 'LNG_NEW_PASSWORD', 'New password', '???? ???? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('370', 'LNG_CONFIRM_PASSWORD', 'Confirm password', '????? ???? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('371', 'LNG_UPDATE_SCHOOL', 'Update School', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('372', 'LNG_UPDATE_SCHOOL_DETAILS', 'Update School Details', '?????? ??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('373', 'LNG_ADMINISTRATOR', 'Administrator', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('374', 'LNG_INFORMATION', 'Information', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('375', 'LNG_UPDATE_DETAILS', 'Update Details', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('376', 'LNG_PRESENT_STUDENTS', 'Present Students', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('377', 'LNG_FORMER_STUDENTS', 'Former Students', '?????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('378', 'LNG_CALENDER', 'Calender', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('379', 'LNG_EMPLOYEE_SEARCH', 'Employee search', '???? ?? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('380', 'LNG_EMPLOYEE_DETAILS', 'Employee Details', '?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('381', 'LNG_SEARCH', 'Search', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('382', 'LNG_SELECT_CATEGORY', 'Select category', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('383', 'LNG_SELECT_POSITION', 'Select position', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('384', 'LNG_POST_A_COMMENT', 'Post a Comment', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('385', 'LNG_MESSAGES', 'Messages', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('386', 'LNG_MESSAGE', 'Message', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('387', 'LNG_LOGOUT', 'Log out', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('388', 'LNG_DASHBOARD', 'Dashboard', '???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('389', 'LNG_MANAGE_SCHOOLS', 'Manage Schools', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('390', 'LNG_POWERED_BY', 'Powered by', '????? ??');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('391', 'LNG_STUDENTS', 'Students', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('392', 'LNG_SUBJECTS_TEMPLATE', 'Courses Template', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('393', 'LNG_MANAGE_TEMPLATE', 'Manage template', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('394', 'LNG_MANAGE_SUBJECTS_TEMPLATE', 'Manage Courses Template', '????? ???????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('395', 'LNG_ACTIVE_SUBJECTS', 'Active Courses', '??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('396', 'LNG_ADD_SUBJECTS_TEMP', 'Add Courses Template', '????? ???? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('397', 'LNG_SESSION_START_YEAR', 'Session Start Year', '???? ???? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('398', 'LNG_SELECT_A_RELIGION', 'Select a Religion', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('399', 'LNG_ADVANCE_SEARCH', 'Advanced Search', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('400', 'LNG_TOTAL_NO_OF_WORK_DAYS', 'Total no. of working days =', '???? ??. ?? ???? ????? =');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('401', 'LNG_SELECT_MONTH_AND_YEAR', 'Select month & year :', '??? ????? ?????? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('402', 'LNG_SELECT_A_MONTH', 'Select a month', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('403', 'LNG_SELECT_A_MODE', 'Select a mode:', '??? ????? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('404', 'LNG_MONTHLY', 'Monthly', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('405', 'LNG_OVERALL', 'Overall', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('406', 'LNG_BIRTH_DATE', 'Birth date', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('407', 'LNG_STUDENT', 'Student', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('408', 'LNG_DEPARTMENT', 'Department', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('409', 'LNG_KEYWORD', 'Keyword', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('410', 'LNG_FILTER', 'Filter', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('411', 'LNG_TO_S', 'to', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('412', 'LNG_ADVANCE_SEARCH_DETAILS', 'Advance Search Details', '?????? ????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('413', 'LNG_SIMPLE_SEARCH', 'Simple Search', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('414', 'LNG_CREATE_NEW', 'Create New', '??? ??? ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('415', 'LNG_CREATE_REMINDER_TO_STAFF', 'Create reminder to a staff', '????? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('416', 'LNG_SELECT_MANAGEMENT', 'Select Management', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('417', 'LNG_SUPER_ADMIN', 'Super Administrator', '???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('418', 'LNG_SELECT_STAFF_NAME', 'Select Staff Name', '?????? ??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('419', 'LNG_CREATE_REMINDER_TO_GUARDIAN', 'Create reminder to a student\'s guardians', '????? ????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('420', 'LNG_SENT', 'Sent', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('421', 'LNG_INBOX', 'Inbox', '?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('422', 'LNG_CREATE_TICKET_TO_STAFF', 'Create Ticket to Staff', '????? ????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('423', 'LNG_CREATE_TICKET_TO_GUARDIAN', 'Create ticket to a student', '????? ????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('427', 'LNG_BATCH_SAVED', 'Class has been saved.', '?? ??? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('428', 'LNG_BATCH_UPDATED', 'Class updated successfully.', '??? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('429', 'LNG_BATCH_DELETED', 'Class deleted successfully.', '??? ??? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('430', 'LNG_STUDENT_CATEGORY_SAVED', 'Student category has been saved.', '?? ??? ??? ??????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('431', 'LNG_EVENT_UPDATED', 'Event Updated Successfully', '????? ??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('432', 'LNG_EXAM_CREATED', 'Exam created successfully.', '????? ???????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('433', 'LNG_EXAM_GROUPED', 'Exam grouped successfully.', '?????? ????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('434', 'LNG_EXAM_UPDATED', 'Exam updated successfully.', '????? ???????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('435', 'LNG_EXAM_SCORES_UPDATED', 'Exam scores updated.', '????? ???????? ???????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('436', 'LNG_GRADE_UPDATED', 'Grade updated successfully.', '???? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('437', 'LNG_GRADE_CREATED', 'Grade Created successfully.', '????? ???? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('438', 'LNG_GRADE_DELETED', 'Grade has been deleted successfully', '??? ?? ??? ???? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('439', 'LNG_INVALID_EMAILID_PASSWORD', 'Invalid email id or password.', '??? ???? ???? ?????? ?????????? ?? ???? ??????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('440', 'LNG_YOU_ARE_LOGGED_OUT', 'You are logged out successfully.', '??? ????? ????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('441', 'LNG_SCHOOL_ADDED', 'School added successfully.', '????? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('442', 'LNG_SCHOOL_UPDATED', 'School information updated successfully.', '????? ??????? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('443', 'LNG_STUDENT_ADDED', 'Student admission successful', '???? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('444', 'LNG_STUDENT_UPDATED', 'Student details updated successfully.', '?????? ?????? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('445', 'LNG_STUDENT_NOT_ADDED', 'Student admission not successful.', '???? ?????? ??? ???????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('446', 'LNG_STUDENT_GUARDIAN_DETAIL_UPDATED', 'Student guardian detail updated successfully.', '???? ??? ????? ???????? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('447', 'LNG_STUDENT_CATEGORY_DELETED', 'Student category has been deleted.', '?? ??? ??? ??????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('448', 'LNG_STUDENT_CATEGORY_UPDATED', 'Student category has been updated.', '?? ????? ??? ??????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('449', 'LNG_STUDENT_CATEGORY_SAVED', 'Student category has been saved.', '?? ??? ??? ??????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('450', 'LNG_SECRETARY_ADDED', 'Secretary added successfully.', '????? ?????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('451', 'LNG_SECRETARY_UPDATED', 'Secretary updated successfully.', '?????? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('452', 'LNG_WEEKDAY_UPDATED', 'Weekday updated successfully.', '???? ??????? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('453', 'LNG_EMPLOYEE_CATEGORY_ADDED', 'Employee category added successfully', '????? ??? ?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('454', 'LNG_EMPLOYEE_CATEGORY_UPDATED', 'Employee category updated successfully', '??? ?????? ??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('455', 'LNG_EMPLOYEE_CATEGORY_DELETED', 'Employee category deleted successfully', '??? ?????? ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('456', 'LNG_EMPLOYEE_DEPARTMENT_ADDED', 'Employee department added successfully', '????? ?????? ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('457', 'LNG_EMPLOYEE_DEPARTMENT_UPDATED', 'Employee department updated successfully', '???? ??? ??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('458', 'LNG_EMPLOYEE_DEPARTMENT_DELETED', 'Employee department deleted successfully', '???? ????? ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('459', 'LNG_EMPLOYEE_POSITION_ADDED', 'Employee position added successfully', '????? ?????? ?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('460', 'LNG_EMPLOYEE_POSITION_UPDATED', 'Employee position updated successfully', '???? ?????? ??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('461', 'LNG_EMPLOYEE_POSITION_DELETED', 'Employee position deleted successfully', '???? ?????? ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('462', 'LNG_EMPLOYEE_ADDED', 'Employee added successfully', '????? ?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('463', 'LNG_EMPLOYEE_PRIVILEGES_UPDATED', 'Employee privileges updated successfully', '???????? ?????? ??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('464', 'LNG_NO_EMPLOYEE_IN_THIS_DEPARTMENT', 'No Employee in the selected department', '?? ???? ?? ??????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('465', 'LNG_NO_STUDENTS_IN_SELECTED_BATCH', 'No Students in selected class', '?? ???? ?? ???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1395', 'LNG_ALL', 'All', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1396', 'LNG_SELECTED', 'Selected', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1397', 'LNG_SELECTED_MANAGEMENT_STAFF', 'Selected Management Staff', '?????? ????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1398', 'LNG_COMMENT', 'Post Comment', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1399', 'LNG_COMMENT_SUCCESSFULLY_POSTED', 'Comment Successfully Posted', '????? ????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1400', 'LNG_SET_WEEKDAY_BEFORE_ATTENDANCE_PROCESS', 'Set weekday before attendance process. To set weekday ', '????? ??? ?? ???? ??????? ??? ????? ??????. ?????? ???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1401', 'LNG_CLICK_HERE', 'Click Here', '???? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1402', 'LNG_REPORT', 'Report', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1403', 'LNG_ADD_SUBJECT_TEMPLATE', 'Add Subject Template', NULL);

drop table if exists `period_entries`;
CREATE TABLE `period_entries` (
  `id` int(11) NOT NULL auto_increment,
  `month_date` date default NULL,
  `batch_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  `class_timing_id` int(11) default NULL,
  `employee_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_period_entries_on_month_date_and_batch_id` (`month_date`,`batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=330 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('2', '2011-11-21', '5', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('4', '2011-11-28', '5', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('6', '2011-12-05', '5', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('8', '2011-12-12', '5', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('10', '2011-11-16', '5', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('11', '2011-11-23', '5', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('12', '2011-11-30', '5', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('13', '2011-12-07', '5', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('14', '2011-12-14', '5', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('15', '2011-11-09', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('16', '2011-11-10', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('17', '2011-11-11', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('18', '2011-11-12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('19', '2011-11-14', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('20', '2011-11-15', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('21', '2011-11-16', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('22', '2011-11-17', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('23', '2011-11-18', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('24', '2011-11-19', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('25', '2011-11-21', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('26', '2011-11-22', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('27', '2011-11-23', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('28', '2011-11-24', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('29', '2011-11-25', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('30', '2011-11-26', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('31', '2011-11-28', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('32', '2011-11-29', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('33', '2011-11-30', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('34', '2011-12-01', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('35', '2011-12-02', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('36', '2011-12-03', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('37', '2011-12-05', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('38', '2011-12-06', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('39', '2011-12-07', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('40', '2011-12-08', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('41', '2011-12-09', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('42', '2011-12-10', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('43', '2011-12-12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('44', '2011-12-13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('45', '2011-12-14', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('46', '2011-12-15', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('47', '2011-12-16', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('48', '2011-12-17', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('49', '2011-12-19', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('50', '2011-12-20', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('51', '2011-12-21', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('52', '2011-12-22', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('53', '2011-12-23', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('54', '2011-12-24', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('55', '2011-12-26', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('56', '2011-12-27', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('57', '2011-12-28', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('58', '2011-12-29', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('59', '2011-12-30', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('60', '2011-12-31', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('61', '2012-01-02', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('62', '2012-01-03', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('63', '2012-01-04', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('64', '2012-01-05', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('65', '2012-01-06', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('66', '2012-01-07', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('67', '2012-01-09', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('68', '2012-01-10', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('69', '2012-01-11', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('70', '2012-01-12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('71', '2012-01-13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('72', '2012-01-14', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('73', '2012-01-16', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('74', '2012-01-17', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('75', '2012-01-18', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('76', '2012-01-19', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('77', '2012-01-20', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('78', '2012-01-21', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('79', '2012-01-23', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('80', '2012-01-24', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('81', '2012-01-25', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('82', '2012-01-26', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('83', '2012-01-27', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('84', '2012-01-28', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('85', '2012-01-30', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('86', '2012-01-31', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('87', '2012-02-01', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('88', '2012-02-02', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('89', '2012-02-03', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('90', '2012-02-04', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('91', '2012-02-06', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('92', '2012-02-07', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('93', '2012-02-08', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('94', '2012-02-09', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('95', '2012-02-10', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('96', '2012-02-11', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('97', '2012-02-13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('98', '2012-02-14', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('99', '2012-02-15', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('100', '2012-02-16', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('101', '2012-02-17', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('102', '2012-02-18', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('103', '2012-02-20', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('104', '2012-02-21', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('105', '2012-02-22', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('106', '2012-02-23', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('107', '2012-02-24', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('108', '2012-02-25', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('109', '2012-02-27', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('110', '2012-02-28', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('111', '2012-02-29', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('112', '2012-03-01', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('113', '2012-03-02', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('114', '2012-03-03', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('115', '2012-03-05', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('116', '2012-03-06', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('117', '2012-03-07', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('118', '2012-03-08', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('119', '2012-03-09', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('120', '2012-03-10', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('121', '2012-03-12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('122', '2012-03-13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('123', '2012-03-14', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('124', '2012-03-15', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('125', '2012-03-16', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('126', '2012-03-17', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('127', '2012-03-19', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('128', '2012-03-20', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('129', '2012-03-21', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('130', '2012-03-22', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('131', '2012-03-23', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('132', '2012-03-24', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('133', '2012-03-26', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('134', '2012-03-27', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('135', '2012-03-28', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('136', '2012-03-29', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('137', '2012-03-30', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('138', '2012-03-31', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('139', '2012-04-02', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('140', '2012-04-03', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('141', '2012-04-04', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('142', '2012-04-05', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('143', '2012-04-06', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('144', '2012-04-07', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('145', '2012-04-09', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('146', '2012-04-10', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('147', '2012-04-11', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('148', '2012-04-12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('149', '2012-04-13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('150', '2012-04-14', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('151', '2012-04-16', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('152', '2012-04-17', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('153', '2012-04-18', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('154', '2012-04-19', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('155', '2012-04-20', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('156', '2012-04-21', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('157', '2012-04-23', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('158', '2012-04-24', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('159', '2012-04-25', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('160', '2012-04-26', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('161', '2012-04-27', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('162', '2012-04-28', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('163', '2012-04-30', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('164', '2012-05-01', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('165', '2012-05-02', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('166', '2012-05-03', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('167', '2012-05-04', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('168', '2012-05-05', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('169', '2012-05-07', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('170', '2012-05-08', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('171', '2012-05-09', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('172', '2012-05-10', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('173', '2012-05-11', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('174', '2012-05-12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('175', '2012-05-14', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('176', '2012-05-15', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('177', '2012-05-16', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('178', '2012-05-17', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('179', '2012-05-18', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('180', '2012-05-19', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('181', '2012-05-21', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('182', '2012-05-22', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('183', '2012-05-23', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('184', '2012-05-24', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('185', '2012-05-25', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('186', '2012-05-26', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('187', '2012-05-28', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('188', '2012-05-29', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('189', '2012-05-30', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('190', '2012-05-31', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('191', '2012-06-01', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('192', '2012-06-02', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('193', '2012-06-04', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('194', '2012-06-05', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('195', '2012-06-06', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('196', '2012-06-07', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('197', '2012-06-08', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('198', '2012-06-09', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('199', '2012-06-11', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('200', '2012-06-12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('201', '2012-06-13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('202', '2012-06-14', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('203', '2012-06-15', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('204', '2012-06-16', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('205', '2012-06-18', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('206', '2012-06-19', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('207', '2012-06-20', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('208', '2012-06-21', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('209', '2012-06-22', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('210', '2012-06-23', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('211', '2012-06-25', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('212', '2012-06-26', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('213', '2012-06-27', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('214', '2012-06-28', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('215', '2012-06-29', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('216', '2012-06-30', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('217', '2012-07-02', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('218', '2012-07-03', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('219', '2012-07-04', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('220', '2012-07-05', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('221', '2012-07-06', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('222', '2012-07-07', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('223', '2012-07-09', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('224', '2012-07-10', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('225', '2012-07-11', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('226', '2012-07-12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('227', '2012-07-13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('228', '2012-07-14', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('229', '2012-07-16', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('230', '2012-07-17', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('231', '2012-07-18', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('232', '2012-07-19', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('233', '2012-07-20', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('234', '2012-07-21', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('235', '2012-07-23', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('236', '2012-07-24', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('237', '2012-07-25', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('238', '2012-07-26', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('239', '2012-07-27', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('240', '2012-07-28', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('241', '2012-07-30', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('242', '2012-07-31', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('243', '2012-08-01', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('244', '2012-08-02', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('245', '2012-08-03', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('246', '2012-08-04', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('247', '2012-08-06', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('248', '2012-08-07', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('249', '2012-08-08', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('250', '2012-08-09', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('251', '2012-08-10', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('252', '2012-08-11', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('253', '2012-08-13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('254', '2012-08-14', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('255', '2012-08-15', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('256', '2012-08-16', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('257', '2012-08-17', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('258', '2012-08-18', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('259', '2012-08-20', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('260', '2012-08-21', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('261', '2012-08-22', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('262', '2012-08-23', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('263', '2012-08-24', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('264', '2012-08-25', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('265', '2012-08-27', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('266', '2012-08-28', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('267', '2012-08-29', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('268', '2012-08-30', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('269', '2012-08-31', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('270', '2012-09-01', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('271', '2012-09-03', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('272', '2012-09-04', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('273', '2012-09-05', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('274', '2012-09-06', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('275', '2012-09-07', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('276', '2012-09-08', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('277', '2012-09-10', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('278', '2012-09-11', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('279', '2012-09-12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('280', '2012-09-13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('281', '2012-09-14', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('282', '2012-09-15', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('283', '2012-09-17', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('284', '2012-09-18', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('285', '2012-09-19', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('286', '2012-09-20', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('287', '2012-09-21', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('288', '2012-09-22', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('289', '2012-09-24', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('290', '2012-09-25', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('291', '2012-09-26', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('292', '2012-09-27', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('293', '2012-09-28', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('294', '2012-09-29', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('295', '2012-10-01', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('296', '2012-10-02', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('297', '2012-10-03', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('298', '2012-10-04', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('299', '2012-10-05', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('300', '2012-10-06', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('301', '2012-10-08', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('302', '2012-10-09', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('303', '2012-10-10', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('304', '2012-10-11', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('305', '2012-10-12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('306', '2012-10-13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('307', '2012-10-15', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('308', '2012-10-16', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('309', '2012-10-17', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('310', '2012-10-18', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('311', '2012-10-19', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('312', '2012-10-20', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('313', '2012-10-22', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('314', '2012-10-23', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('315', '2012-10-24', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('316', '2012-10-25', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('317', '2012-10-26', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('318', '2012-10-27', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('319', '2012-10-29', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('320', '2012-10-30', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('321', '2012-10-31', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('322', '2012-11-01', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('323', '2012-11-02', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('324', '2012-11-03', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('325', '2012-11-05', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('326', '2012-11-06', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('327', '2012-11-07', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('328', '2012-11-08', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `subject_id`, `class_timing_id`, `employee_id`) values ('329', '2012-11-09', '4', NULL, NULL, NULL);

drop table if exists `phpmysqlautobackup`;
CREATE TABLE `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) default NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1; 
insert into `phpmysqlautobackup` (`id`, `version`, `time_last_run`) values ('1', '1.5.2', '1322880823');

drop table if exists `reminders`;
CREATE TABLE `reminders` (
  `id` int(11) NOT NULL auto_increment,
  `sender` int(11) default NULL,
  `recipient` int(11) default NULL,
  `subject` varchar(255) collate utf8_unicode_ci default NULL,
  `body` text collate utf8_unicode_ci,
  `is_read` tinyint(1) default '0',
  `is_deleted_by_sender` tinyint(1) default '0',
  `is_deleted_by_recipient` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_reminders_on_recipient` (`recipient`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `reminders` (`id`, `sender`, `recipient`, `subject`, `body`, `is_read`, `is_deleted_by_sender`, `is_deleted_by_recipient`, `created_at`, `updated_at`) values ('1', '1', '2', 'aaa aa aa', 'bb bb bb bbb bbb bb', '0', '0', '0', '2011-11-11 15:46:04', '2011-11-11 15:46:08');
insert into `reminders` (`id`, `sender`, `recipient`, `subject`, `body`, `is_read`, `is_deleted_by_sender`, `is_deleted_by_recipient`, `created_at`, `updated_at`) values ('2', '1', '2', 'rtr rrt rrw wwe', 'dfg ff gdd ss sddf sss', '0', '0', '0', '2011-11-11 15:28:02', '2011-11-11 15:28:06');
insert into `reminders` (`id`, `sender`, `recipient`, `subject`, `body`, `is_read`, `is_deleted_by_sender`, `is_deleted_by_recipient`, `created_at`, `updated_at`) values ('3', '2', '5', ' test sdf we r f', 'sd sdf sdff ssdf sdfsdf sdff', '0', '0', '0', '2011-11-11 15:29:02', '2011-11-11 15:29:07');

drop table if exists `school`;
CREATE TABLE `school` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(500) NOT NULL,
  `address` text NOT NULL,
  `phno` varchar(40) NOT NULL,
  `mhno` varchar(40) NOT NULL,
  `logo` varchar(200) NOT NULL,
  `status` int(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1; 
insert into `school` (`id`, `name`, `address`, `phno`, `mhno`, `logo`, `status`) values ('1', 'LBS School', 'Paota Jodhpur', '0219425786', '0291236547', '1673.png', '1');
insert into `school` (`id`, `name`, `address`, `phno`, `mhno`, `logo`, `status`) values ('2', 'St. Xavier Public School', 'Ratanada, Jodhpur', '02912646856', '255649532', '', '1');
insert into `school` (`id`, `name`, `address`, `phno`, `mhno`, `logo`, `status`) values ('3', 'LBS School', 'Paota Jodhpur Raj', '0219425786', '0291236547', '', '1');
insert into `school` (`id`, `name`, `address`, `phno`, `mhno`, `logo`, `status`) values ('4', 'Vidhya Bhawan', 'Pal link main, Jodhppur', '0291-2646859', '', '4229.jpg', '1');

drop table if exists `student_previous_datas`;
CREATE TABLE `student_previous_datas` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `institution` varchar(255) collate utf8_unicode_ci default NULL,
  `year` varchar(255) collate utf8_unicode_ci default NULL,
  `course` varchar(255) collate utf8_unicode_ci default NULL,
  `total_mark` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

drop table if exists `students`;
CREATE TABLE `students` (
  `id` int(11) NOT NULL auto_increment,
  `schoolid` int(11) NOT NULL,
  `admission_no` varchar(255) collate utf8_unicode_ci default NULL,
  `passport_or_id` int(11) NOT NULL,
  `student_passport_no` varchar(200) collate utf8_unicode_ci NOT NULL,
  `class_roll_no` varchar(255) collate utf8_unicode_ci default NULL,
  `admission_date` date default NULL,
  `title` varchar(20) collate utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `middle_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `date_of_birth` date default NULL,
  `gender` varchar(255) collate utf8_unicode_ci default NULL,
  `blood_group` varchar(255) collate utf8_unicode_ci default NULL,
  `birth_place` varchar(255) collate utf8_unicode_ci default NULL,
  `nationality_id` int(11) default NULL,
  `language` varchar(255) collate utf8_unicode_ci default NULL,
  `religion` varchar(255) collate utf8_unicode_ci default NULL,
  `student_category_id` int(11) default NULL,
  `address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `city` varchar(255) collate utf8_unicode_ci default NULL,
  `state` varchar(255) collate utf8_unicode_ci default NULL,
  `pin_code` varchar(255) collate utf8_unicode_ci default NULL,
  `country_id` int(11) default NULL,
  `phone1` varchar(255) collate utf8_unicode_ci default NULL,
  `phone2` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `immediate_contact_id` int(11) default NULL,
  `is_sms_enabled` tinyint(1) default '1',
  `photo_file_name` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_content_type` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_data` mediumblob,
  `birth_certificate` varchar(300) collate utf8_unicode_ci NOT NULL,
  `status_description` varchar(255) collate utf8_unicode_ci default NULL,
  `is_active` tinyint(1) default '1',
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `has_paid_fees` tinyint(1) default '0',
  `photo_file_size` int(11) default NULL,
  `user_id` int(11) default NULL,
  `student_illness` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id`),
  KEY `index_students_on_admission_no` (`admission_no`(10)),
  KEY `index_students_on_first_name_and_middle_name_and_last_name` (`first_name`(10),`middle_name`(10),`last_name`(10))
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('1', '1', '1001', '1', '2548', '', '2011-11-04', 'Mr', '4100', '', '124', '2', '2011-11-04', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '1304.gif', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('2', '1', '1212', '1', '0', '', '2011-11-04', 'Mr', '.pk', ';', 'kk', '2', '2011-11-04', NULL, NULL, NULL, '1', NULL, '1', NULL, 'chouhano ki dhani', NULL, NULL, NULL, NULL, NULL, 'ger', NULL, NULL, NULL, '1', '2250.jpg', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('3', '1', '11041', '2', '0', '', '2011-11-10', 'Mr', 'Amit', '', 'Singh', '4', '1994-08-12', NULL, NULL, NULL, '1', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '3306.JPG', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('4', '1', '565', '1', '55', '', '2011-11-10', 'Mr', 'gfh', 'f', 'fgh', '2', '2011-11-10', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, 'g', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('5', '1', '11042', '2', '0', '', '2011-11-11', 'Mr', 'Suresh', '', 'Kumar', '4', '1996-11-30', NULL, NULL, NULL, '1', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('6', '1', '11043', '1', '0', '', '2011-11-16', 'Mr', 'Shyam', '', 'Arora', '5', '1996-07-09', NULL, NULL, NULL, '1', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '6422.png', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('7', '1', '65', '1', '4', '', '2011-11-16', 'Mr', 'dfgdf fg', '', 'fg', '2', '2011-11-16', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '7547.jpg', NULL, NULL, '7232.jpg', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('8', '1', '1035', '1', '0', '', '2011-11-16', 'Mr', 'Rahul', '', 'Singh', '4', '2011-12-20', NULL, NULL, NULL, '1', NULL, '1', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '8583.jpg', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('9', '1', '1033', '1', '0', '', '2011-11-16', 'Mr', 'asg', '', 'stydsda', '2', '1994-11-04', NULL, NULL, NULL, '1', NULL, '1', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '9826.png', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('10', '2', '1038', '1', '0', '', '2011-11-17', 'Mr', 'Mayank', '', 'Sen', '6', '1998-11-04', NULL, NULL, NULL, '1', NULL, '1', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '10330.png', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('11', '2', '11046', '1', '0', '', '2011-11-19', 'Mr', 'Jay', '', 'Singh', '6', '1998-07-14', NULL, NULL, NULL, '1', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '11202.jpg', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('12', '1', '114101', '2', '0', '', '2011-11-19', 'Mr', 'Vikram', '', 'Parekh', '5', '1995-06-23', NULL, NULL, NULL, '1', NULL, '1', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '12191.png', NULL, NULL, '12675.png', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('13', '1', '114103', '1', '0', '', '2011-11-23', 'Mr', 'Pradeep', '', 'Gupta', '5', '1994-12-27', NULL, NULL, NULL, '1', NULL, 'Hindu', NULL, 'abc', NULL, NULL, NULL, NULL, NULL, '3121232', NULL, NULL, NULL, '1', '13537.jpg', NULL, NULL, '13116.png', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('14', '1', '114105', '1', '0', '', '2011-11-25', 'Mr', 'Parvez', '', 'Khan', '2', '1999-08-24', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '14806.png', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('15', '1', '114106', '1', '0', '', '2011-11-28', 'Mr', 'Kamlesh', '', 'Singh', '5', '1995-12-11', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, 'sfdaf', NULL, NULL, NULL, NULL, NULL, '2351222', NULL, NULL, NULL, '1', NULL, NULL, NULL, '15633.jpg', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);

drop table if exists `subjects`;
CREATE TABLE `subjects` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `code` varchar(255) collate utf8_unicode_ci default NULL,
  `grade_id` int(11) NOT NULL default '0',
  `no_exams` tinyint(1) default '0',
  `max_weekly_classes` int(11) default NULL,
  `elective_group_id` int(11) default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_subjects_on_batch_id_and_elective_group_id_and_is_deleted` (`elective_group_id`,`is_deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('1', 'English', '001', '1', '0', NULL, NULL, '0', '2011-11-03 05:04:52', '2011-11-03 05:04:52');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('2', 'Arabic', '002', '1', '0', NULL, NULL, '0', '2011-11-03 05:08:15', '2011-11-03 05:24:16');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('4', 'hr dfg', '569', '2', '0', NULL, NULL, '0', '2011-11-09 03:55:34', '2011-11-24 10:52:02');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('5', 'Mathematics', '013', '1', '0', NULL, NULL, '0', '2011-11-11 11:11:19', '2011-11-11 11:11:19');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('6', 'General Science', '046', '2', '0', NULL, NULL, '0', '2011-11-11 11:11:49', '2011-11-11 11:11:49');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('7', 'Maths', '801', '3', '0', NULL, NULL, '0', '2011-11-17 12:52:56', '2011-11-17 12:52:56');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('8', 'General Science', '802', '3', '0', NULL, NULL, '0', '2011-11-18 12:08:06', '2011-11-18 12:08:06');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('9', 'Social Science', '803', '3', '0', NULL, NULL, '0', '2011-11-18 12:08:17', '2011-11-18 12:08:17');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('10', 'English', '804', '3', '0', NULL, NULL, '0', '2011-11-18 12:08:27', '2011-11-18 12:08:33');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('11', 'Grammer', '805', '3', '0', NULL, NULL, '0', '2011-11-18 12:08:46', '2011-11-18 12:08:46');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('13', 'Hindi', '104', '1', '0', NULL, NULL, '0', '2011-11-23 03:57:58', '2011-11-23 03:57:58');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('14', 'Computer', '1005', '2', '0', NULL, NULL, '0', '2011-11-23 04:00:54', '2011-11-23 04:00:54');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('15', 'abc', '111', '2', '0', NULL, NULL, '0', '2011-11-23 04:03:27', '2011-11-23 04:03:27');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('21', 'English', NULL, '2', '0', NULL, NULL, '0', '2011-12-02 02:56:36', '2011-12-02 02:56:36');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('22', 'economics', NULL, '2', '0', NULL, NULL, '0', '2011-12-02 03:00:35', '2011-12-02 03:00:35');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('23', 'hr dfg', '', '2', '0', NULL, NULL, '0', '2011-12-02 03:01:45', '2011-12-02 03:01:45');

drop table if exists `subjects_template`;
CREATE TABLE `subjects_template` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `code` varchar(100) collate utf8_unicode_ci NOT NULL,
  `grade_id` int(11) default NULL,
  `no_exams` tinyint(1) default '0',
  `max_weekly_classes` int(11) default NULL,
  `elective_group_id` int(11) default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_subjects_on_batch_id_and_elective_group_id_and_is_deleted` (`grade_id`,`elective_group_id`,`is_deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `subjects_template` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('1', 'asgf', '', '2', '0', NULL, NULL, '0', '2011-11-23 04:06:59', '2011-11-23 04:06:59');
insert into `subjects_template` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('2', 'English', '', '1', '0', NULL, NULL, '0', '2011-11-23 07:24:31', '2011-11-23 07:24:31');
insert into `subjects_template` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('4', 'hr dfg', '', '1', '0', NULL, NULL, '0', '2011-11-23 07:30:27', '2011-11-23 07:30:27');
insert into `subjects_template` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('5', 'economics', '', '2', '0', NULL, NULL, '0', '2011-12-02 01:51:46', '2011-12-02 01:51:46');

drop table if exists `teacher_to_grade`;
CREATE TABLE `teacher_to_grade` (
  `id` int(11) NOT NULL auto_increment,
  `schoolid` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `empid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1; 
insert into `teacher_to_grade` (`id`, `schoolid`, `batch_id`, `empid`, `status`) values ('1', '1', '2', '1', '1');

drop table if exists `ticket`;
CREATE TABLE `ticket` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `created_by` int(11) NOT NULL,
  `createon` datetime NOT NULL,
  `notifydate` date NOT NULL,
  `status` varchar(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1; 
insert into `ticket` (`id`, `title`, `description`, `created_by`, `createon`, `notifydate`, `status`) values ('1', 'annual meet', 'we are organizing annual meet 2011 ', '0', '2011-11-12 14:29:42', '2011-11-14', '1');
insert into `ticket` (`id`, `title`, `description`, `created_by`, `createon`, `notifydate`, `status`) values ('2', 'as', 'afadf', '1', '2011-11-23 10:20:32', '0000-00-00', '1');
insert into `ticket` (`id`, `title`, `description`, `created_by`, `createon`, `notifydate`, `status`) values ('3', 'cvcvb', 'cvbcvb', '2', '2011-11-23 15:12:54', '0000-00-00', '1');

drop table if exists `ticket_assigned`;
CREATE TABLE `ticket_assigned` (
  `id` int(11) NOT NULL auto_increment,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `status` varchar(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1; 
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('1', '1', '3', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('2', '3', '3', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('3', '3', '8', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('4', '3', '5', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('5', '3', '2', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('6', '3', '1', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('7', '3', '9', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('8', '3', '7', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('9', '3', '4', '1');

drop table if exists `ticket_commented`;
CREATE TABLE `ticket_commented` (
  `id` int(11) NOT NULL auto_increment,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `usercomment` varchar(250) NOT NULL,
  `date` datetime NOT NULL,
  `status` varchar(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1; 
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('1', '3', '12', 'Distribution of substantively modified versions of this document is prohibited without the explicit permission of the copyright holder', '2011-11-24 14:40:18', '1');
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('2', '3', '16', 'In case you are interested in redistribution or republishing of this document in whole or in part, either modified or unmodified, and you have questions, please contact the copyright holders at � doc-license@lists.php.net.', '2011-11-23 00:00:00', '1');
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('3', '0', '0', 'afa', '2011-12-01 12:48:10', '1');
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('4', '0', '0', 'afaf', '2011-12-01 12:48:30', '1');
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('5', '3', '2', 'afafa', '2011-12-01 12:50:44', '1');
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('6', '3', '2', 'rrrADFa', '2011-12-01 12:51:56', '1');
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('7', '3', '1', 'hello..........', '2011-12-01 12:53:33', '1');

drop table if exists `timetable_entries`;
CREATE TABLE `timetable_entries` (
  `id` int(11) NOT NULL auto_increment,
  `batch_id` int(11) default NULL,
  `weekday_id` int(11) default NULL,
  `class_timing_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  `employee_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `by_timetable` (`weekday_id`,`batch_id`,`class_timing_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('1', '2', '12', '1', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('2', '2', '12', '2', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('3', '2', '13', '1', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('4', '2', '13', '2', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('5', '2', '14', '1', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('6', '2', '14', '2', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('7', '2', '15', '1', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('8', '2', '15', '2', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('9', '2', '16', '1', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('10', '2', '16', '2', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('11', '4', '17', '3', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('12', '4', '17', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('13', '4', '17', '5', '4', '2');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('14', '4', '18', '3', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('15', '4', '18', '4', '4', '2');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('16', '4', '18', '5', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('17', '4', '19', '3', '4', '2');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('18', '4', '19', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('19', '4', '19', '5', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('20', '4', '20', '3', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('21', '4', '20', '4', '4', '2');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('22', '4', '20', '5', '4', '2');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('23', '4', '21', '3', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('24', '4', '21', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('25', '4', '21', '5', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('26', '4', '22', '3', '4', '2');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('27', '4', '22', '4', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `subject_id`, `employee_id`) values ('28', '4', '22', '5', NULL, NULL);

drop table if exists `timezone`;
CREATE TABLE `timezone` (
  `id` int(100) NOT NULL auto_increment,
  `name` varchar(250) NOT NULL,
  `code` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=546 DEFAULT CHARSET=latin1; 
insert into `timezone` (`id`, `name`, `code`) values ('1', 'Africa/Abidjan', 'Africa/Abidjan');
insert into `timezone` (`id`, `name`, `code`) values ('2', 'Africa/Accra', 'Africa/Accra');
insert into `timezone` (`id`, `name`, `code`) values ('3', 'Africa/Addis_Ababa', 'Africa/Addis_Ababa');
insert into `timezone` (`id`, `name`, `code`) values ('4', 'Africa/Algiers', 'Africa/Algiers');
insert into `timezone` (`id`, `name`, `code`) values ('5', 'Africa/Asmara', 'Africa/Asmara');
insert into `timezone` (`id`, `name`, `code`) values ('6', 'Africa/Asmera', 'Africa/Asmera');
insert into `timezone` (`id`, `name`, `code`) values ('7', 'Africa/Bamako', 'Africa/Bamako');
insert into `timezone` (`id`, `name`, `code`) values ('8', 'Africa/Bangui', 'Africa/Bangui');
insert into `timezone` (`id`, `name`, `code`) values ('9', 'Africa/Banjul', 'Africa/Banjul');
insert into `timezone` (`id`, `name`, `code`) values ('10', 'Africa/Bissau', 'Africa/Bissau');
insert into `timezone` (`id`, `name`, `code`) values ('11', 'Africa/Blantyre', 'Africa/Blantyre');
insert into `timezone` (`id`, `name`, `code`) values ('12', 'Africa/Brazzaville', 'Africa/Brazzaville');
insert into `timezone` (`id`, `name`, `code`) values ('13', 'Africa/Bujumbura', 'Africa/Bujumbura');
insert into `timezone` (`id`, `name`, `code`) values ('14', 'Africa/Cairo', 'Africa/Cairo');
insert into `timezone` (`id`, `name`, `code`) values ('15', 'Africa/Casablanca', 'Africa/Casablanca');
insert into `timezone` (`id`, `name`, `code`) values ('16', 'Africa/Ceuta', 'Africa/Ceuta');
insert into `timezone` (`id`, `name`, `code`) values ('17', 'Africa/Conakry', 'Africa/Conakry');
insert into `timezone` (`id`, `name`, `code`) values ('18', 'Africa/Dakar', 'Africa/Dakar');
insert into `timezone` (`id`, `name`, `code`) values ('19', 'Africa/Dar_es_Salaam', 'Africa/Dar_es_Salaam');
insert into `timezone` (`id`, `name`, `code`) values ('20', 'Africa/Djibouti', 'Africa/Djibouti');
insert into `timezone` (`id`, `name`, `code`) values ('21', 'Africa/Douala', 'Africa/Douala');
insert into `timezone` (`id`, `name`, `code`) values ('22', 'Africa/El_Aaiun', 'Africa/El_Aaiun');
insert into `timezone` (`id`, `name`, `code`) values ('23', 'Africa/Freetown', 'Africa/Freetown');
insert into `timezone` (`id`, `name`, `code`) values ('24', 'Africa/Gaborone', 'Africa/Gaborone');
insert into `timezone` (`id`, `name`, `code`) values ('25', 'Africa/Harare', 'Africa/Harare');
insert into `timezone` (`id`, `name`, `code`) values ('26', 'Africa/Johannesburg', 'Africa/Johannesburg');
insert into `timezone` (`id`, `name`, `code`) values ('27', 'Africa/Kampala', 'Africa/Kampala');
insert into `timezone` (`id`, `name`, `code`) values ('28', 'Africa/Khartoum', 'Africa/Khartoum');
insert into `timezone` (`id`, `name`, `code`) values ('29', 'Africa/Kigali', 'Africa/Kigali');
insert into `timezone` (`id`, `name`, `code`) values ('30', 'Africa/Kinshasa', 'Africa/Kinshasa');
insert into `timezone` (`id`, `name`, `code`) values ('31', 'Africa/Lagos', 'Africa/Lagos');
insert into `timezone` (`id`, `name`, `code`) values ('32', 'Africa/Libreville', 'Africa/Libreville');
insert into `timezone` (`id`, `name`, `code`) values ('33', 'Africa/Lome', 'Africa/Lome');
insert into `timezone` (`id`, `name`, `code`) values ('34', 'Africa/Luanda', 'Africa/Luanda');
insert into `timezone` (`id`, `name`, `code`) values ('35', 'Africa/Lubumbashi', 'Africa/Lubumbashi');
insert into `timezone` (`id`, `name`, `code`) values ('36', 'Africa/Lusaka', 'Africa/Lusaka');
insert into `timezone` (`id`, `name`, `code`) values ('37', 'Africa/Malabo', 'Africa/Malabo');
insert into `timezone` (`id`, `name`, `code`) values ('38', 'Africa/Maputo', 'Africa/Maputo');
insert into `timezone` (`id`, `name`, `code`) values ('39', 'Africa/Maseru', 'Africa/Maseru');
insert into `timezone` (`id`, `name`, `code`) values ('40', 'Africa/Mbabane', 'Africa/Mbabane');
insert into `timezone` (`id`, `name`, `code`) values ('41', 'Africa/Mogadishu', 'Africa/Mogadishu');
insert into `timezone` (`id`, `name`, `code`) values ('42', 'Africa/Monrovia', 'Africa/Monrovia');
insert into `timezone` (`id`, `name`, `code`) values ('43', 'Africa/Nairobi', 'Africa/Nairobi');
insert into `timezone` (`id`, `name`, `code`) values ('44', 'Africa/Ndjamena', 'Africa/Ndjamena');
insert into `timezone` (`id`, `name`, `code`) values ('45', 'Africa/Niamey', 'Africa/Niamey');
insert into `timezone` (`id`, `name`, `code`) values ('46', 'Africa/Nouakchott', 'Africa/Nouakchott');
insert into `timezone` (`id`, `name`, `code`) values ('47', 'Africa/Ouagadougou', 'Africa/Ouagadougou');
insert into `timezone` (`id`, `name`, `code`) values ('48', 'Africa/Porto-Novo', 'Africa/Porto-Novo');
insert into `timezone` (`id`, `name`, `code`) values ('49', 'Africa/Sao_Tome', 'Africa/Sao_Tome');
insert into `timezone` (`id`, `name`, `code`) values ('50', 'Africa/Timbuktu', 'Africa/Timbuktu');
insert into `timezone` (`id`, `name`, `code`) values ('51', 'Africa/Tripoli', 'Africa/Tripoli');
insert into `timezone` (`id`, `name`, `code`) values ('52', 'Africa/Tunis', 'Africa/Tunis');
insert into `timezone` (`id`, `name`, `code`) values ('53', 'Africa/Windhoek', 'Africa/Windhoek');
insert into `timezone` (`id`, `name`, `code`) values ('54', 'America/Adak', 'America/Adak');
insert into `timezone` (`id`, `name`, `code`) values ('55', 'America/Anchorage', 'America/Anchorage');
insert into `timezone` (`id`, `name`, `code`) values ('56', 'America/Anguilla', 'America/Anguilla');
insert into `timezone` (`id`, `name`, `code`) values ('57', 'America/Antigua', 'America/Antigua');
insert into `timezone` (`id`, `name`, `code`) values ('58', 'America/Araguaina', 'America/Araguaina');
insert into `timezone` (`id`, `name`, `code`) values ('59', 'America/Argentina', 'America/Argentina');
insert into `timezone` (`id`, `name`, `code`) values ('60', 'America/Aruba', 'America/Aruba');
insert into `timezone` (`id`, `name`, `code`) values ('61', 'America/Asuncion', 'America/Asuncion');
insert into `timezone` (`id`, `name`, `code`) values ('62', 'America/Atikokan', 'America/Atikokan');
insert into `timezone` (`id`, `name`, `code`) values ('63', 'America/Atka', 'America/Atka');
insert into `timezone` (`id`, `name`, `code`) values ('64', 'America/Bahia', 'America/Bahia');
insert into `timezone` (`id`, `name`, `code`) values ('65', 'America/Bahia_Banderas', 'America/Bahia_Banderas');
insert into `timezone` (`id`, `name`, `code`) values ('66', 'America/Barbados', 'America/Barbados');
insert into `timezone` (`id`, `name`, `code`) values ('67', 'America/Belem', 'America/Belem');
insert into `timezone` (`id`, `name`, `code`) values ('68', 'America/Belize', 'America/Belize');
insert into `timezone` (`id`, `name`, `code`) values ('69', 'America/Blanc-Sablon', 'America/Blanc-Sablon');
insert into `timezone` (`id`, `name`, `code`) values ('70', 'America/Boa_Vista', 'America/Boa_Vista');
insert into `timezone` (`id`, `name`, `code`) values ('71', 'America/Bogota', 'America/Bogota');
insert into `timezone` (`id`, `name`, `code`) values ('72', 'America/Boise', 'America/Boise');
insert into `timezone` (`id`, `name`, `code`) values ('73', 'America/Buenos_Aires', 'America/Buenos_Aires');
insert into `timezone` (`id`, `name`, `code`) values ('74', 'America/Cambridge_Bay', 'America/Cambridge_Bay');
insert into `timezone` (`id`, `name`, `code`) values ('75', 'America/Campo_Grande', 'America/Campo_Grande');
insert into `timezone` (`id`, `name`, `code`) values ('76', 'America/Cancun', 'America/Cancun');
insert into `timezone` (`id`, `name`, `code`) values ('77', 'America/Caracas', 'America/Caracas');
insert into `timezone` (`id`, `name`, `code`) values ('78', 'America/Catamarca', 'America/Catamarca');
insert into `timezone` (`id`, `name`, `code`) values ('79', 'America/Cayenne', 'America/Cayenne');
insert into `timezone` (`id`, `name`, `code`) values ('80', 'America/Cayman', 'America/Cayman');
insert into `timezone` (`id`, `name`, `code`) values ('81', 'America/Chicago', 'America/Chicago');
insert into `timezone` (`id`, `name`, `code`) values ('82', 'America/Chihuahua', 'America/Chihuahua');
insert into `timezone` (`id`, `name`, `code`) values ('83', 'America/Coral_Harbour', 'America/Coral_Harbour');
insert into `timezone` (`id`, `name`, `code`) values ('84', 'America/Cordoba', 'America/Cordoba');
insert into `timezone` (`id`, `name`, `code`) values ('85', 'America/Costa_Rica', 'America/Costa_Rica');
insert into `timezone` (`id`, `name`, `code`) values ('86', 'America/Cuiaba', 'America/Cuiaba');
insert into `timezone` (`id`, `name`, `code`) values ('87', 'America/Curacao', 'America/Curacao');
insert into `timezone` (`id`, `name`, `code`) values ('88', 'America/Danmarkshavn', 'America/Danmarkshavn');
insert into `timezone` (`id`, `name`, `code`) values ('89', 'America/Dawson', 'America/Dawson');
insert into `timezone` (`id`, `name`, `code`) values ('90', 'America/Dawson_Creek', 'America/Dawson_Creek');
insert into `timezone` (`id`, `name`, `code`) values ('91', 'America/Denver', 'America/Denver');
insert into `timezone` (`id`, `name`, `code`) values ('92', 'America/Detroit', 'America/Detroit');
insert into `timezone` (`id`, `name`, `code`) values ('93', 'America/Dominica', 'America/Dominica');
insert into `timezone` (`id`, `name`, `code`) values ('94', 'America/Edmonton', 'America/Edmonton');
insert into `timezone` (`id`, `name`, `code`) values ('95', 'America/Eirunepe', 'America/Eirunepe');
insert into `timezone` (`id`, `name`, `code`) values ('96', 'America/El_Salvador', 'America/El_Salvador');
insert into `timezone` (`id`, `name`, `code`) values ('97', 'America/Ensenada', 'America/Ensenada');
insert into `timezone` (`id`, `name`, `code`) values ('98', 'America/Fort_Wayne', 'America/Fort_Wayne');
insert into `timezone` (`id`, `name`, `code`) values ('99', 'America/Fortaleza', 'America/Fortaleza');
insert into `timezone` (`id`, `name`, `code`) values ('100', 'America/Glace_Bay', 'America/Glace_Bay');
insert into `timezone` (`id`, `name`, `code`) values ('101', 'America/Godthab', 'America/Godthab');
insert into `timezone` (`id`, `name`, `code`) values ('102', 'America/Goose_Bay', 'America/Goose_Bay');
insert into `timezone` (`id`, `name`, `code`) values ('103', 'America/Grand_Turk', 'America/Grand_Turk');
insert into `timezone` (`id`, `name`, `code`) values ('104', 'America/Grenada', 'America/Grenada');
insert into `timezone` (`id`, `name`, `code`) values ('105', 'America/Guadeloupe', 'America/Guadeloupe');
insert into `timezone` (`id`, `name`, `code`) values ('106', 'America/Guatemala', 'America/Guatemala');
insert into `timezone` (`id`, `name`, `code`) values ('107', 'America/Guayaquil', 'America/Guayaquil');
insert into `timezone` (`id`, `name`, `code`) values ('108', 'America/Guyana', 'America/Guyana');
insert into `timezone` (`id`, `name`, `code`) values ('109', 'America/Halifax', 'America/Halifax');
insert into `timezone` (`id`, `name`, `code`) values ('110', 'America/Havana', 'America/Havana');
insert into `timezone` (`id`, `name`, `code`) values ('111', 'America/Hermosillo', 'America/Hermosillo');
insert into `timezone` (`id`, `name`, `code`) values ('112', 'America/Indiana', 'America/Indiana');
insert into `timezone` (`id`, `name`, `code`) values ('113', 'America/Indianapolis', 'America/Indianapolis');
insert into `timezone` (`id`, `name`, `code`) values ('114', 'America/Inuvik', 'America/Inuvik');
insert into `timezone` (`id`, `name`, `code`) values ('115', 'America/Iqaluit', 'America/Iqaluit');
insert into `timezone` (`id`, `name`, `code`) values ('116', 'America/Jamaica', 'America/Jamaica');
insert into `timezone` (`id`, `name`, `code`) values ('117', 'America/Jujuy', 'America/Jujuy');
insert into `timezone` (`id`, `name`, `code`) values ('118', 'America/Juneau', 'America/Juneau');
insert into `timezone` (`id`, `name`, `code`) values ('119', 'America/Kentucky', 'America/Kentucky');
insert into `timezone` (`id`, `name`, `code`) values ('120', 'America/Knox_IN', 'America/Knox_IN');
insert into `timezone` (`id`, `name`, `code`) values ('121', 'America/La_Paz', 'America/La_Paz');
insert into `timezone` (`id`, `name`, `code`) values ('122', 'America/Lima', 'America/Lima');
insert into `timezone` (`id`, `name`, `code`) values ('123', 'America/Los_Angeles', 'America/Los_Angeles');
insert into `timezone` (`id`, `name`, `code`) values ('124', 'America/Louisville', 'America/Louisville');
insert into `timezone` (`id`, `name`, `code`) values ('125', 'America/Maceio', 'America/Maceio');
insert into `timezone` (`id`, `name`, `code`) values ('126', 'America/Managua', 'America/Managua');
insert into `timezone` (`id`, `name`, `code`) values ('127', 'America/Manaus', 'America/Manaus');
insert into `timezone` (`id`, `name`, `code`) values ('128', 'America/Marigot', 'America/Marigot');
insert into `timezone` (`id`, `name`, `code`) values ('129', 'America/Martinique', 'America/Martinique');
insert into `timezone` (`id`, `name`, `code`) values ('130', 'America/Matamoros', 'America/Matamoros');
insert into `timezone` (`id`, `name`, `code`) values ('131', 'America/Mazatlan', 'America/Mazatlan');
insert into `timezone` (`id`, `name`, `code`) values ('132', 'America/Mendoza', 'America/Mendoza');
insert into `timezone` (`id`, `name`, `code`) values ('133', 'America/Menominee', 'America/Menominee');
insert into `timezone` (`id`, `name`, `code`) values ('134', 'America/Merida', 'America/Merida');
insert into `timezone` (`id`, `name`, `code`) values ('135', 'America/Mexico_City', 'America/Mexico_City');
insert into `timezone` (`id`, `name`, `code`) values ('136', 'America/Miquelon', 'America/Miquelon');
insert into `timezone` (`id`, `name`, `code`) values ('137', 'America/Moncton', 'America/Moncton');
insert into `timezone` (`id`, `name`, `code`) values ('138', 'America/Monterrey', 'America/Monterrey');
insert into `timezone` (`id`, `name`, `code`) values ('139', 'America/Montevideo', 'America/Montevideo');
insert into `timezone` (`id`, `name`, `code`) values ('140', 'America/Montreal', 'America/Montreal');
insert into `timezone` (`id`, `name`, `code`) values ('141', 'America/Montserrat', 'America/Montserrat');
insert into `timezone` (`id`, `name`, `code`) values ('142', 'America/Nassau', 'America/Nassau');
insert into `timezone` (`id`, `name`, `code`) values ('143', 'America/New_York', 'America/New_York');
insert into `timezone` (`id`, `name`, `code`) values ('144', 'America/Nipigon', 'America/Nipigon');
insert into `timezone` (`id`, `name`, `code`) values ('145', 'America/Nome', 'America/Nome');
insert into `timezone` (`id`, `name`, `code`) values ('146', 'America/Noronha', 'America/Noronha');
insert into `timezone` (`id`, `name`, `code`) values ('147', 'America/North_Dakota', 'America/North_Dakota');
insert into `timezone` (`id`, `name`, `code`) values ('148', 'America/Ojinaga', 'America/Ojinaga');
insert into `timezone` (`id`, `name`, `code`) values ('149', 'America/Panama', 'America/Panama');
insert into `timezone` (`id`, `name`, `code`) values ('150', 'America/Pangnirtung', 'America/Pangnirtung');
insert into `timezone` (`id`, `name`, `code`) values ('151', 'America/Paramaribo', 'America/Paramaribo');
insert into `timezone` (`id`, `name`, `code`) values ('152', 'America/Phoenix', 'America/Phoenix');
insert into `timezone` (`id`, `name`, `code`) values ('153', 'America/Port-au-Prince', 'America/Port-au-Prince');
insert into `timezone` (`id`, `name`, `code`) values ('154', 'America/Port_of_Spain', 'America/Port_of_Spain');
insert into `timezone` (`id`, `name`, `code`) values ('155', 'America/Porto_Acre', 'America/Porto_Acre');
insert into `timezone` (`id`, `name`, `code`) values ('156', 'America/Porto_Velho', 'America/Porto_Velho');
insert into `timezone` (`id`, `name`, `code`) values ('157', 'America/Puerto_Rico', 'America/Puerto_Rico');
insert into `timezone` (`id`, `name`, `code`) values ('158', 'America/Rainy_River', 'America/Rainy_River');
insert into `timezone` (`id`, `name`, `code`) values ('159', 'America/Rankin_Inlet', 'America/Rankin_Inlet');
insert into `timezone` (`id`, `name`, `code`) values ('160', 'America/Recife', 'America/Recife');
insert into `timezone` (`id`, `name`, `code`) values ('161', 'America/Regina', 'America/Regina');
insert into `timezone` (`id`, `name`, `code`) values ('162', 'America/Resolute', 'America/Resolute');
insert into `timezone` (`id`, `name`, `code`) values ('163', 'America/Rio_Branco', 'America/Rio_Branco');
insert into `timezone` (`id`, `name`, `code`) values ('164', 'America/Rosario', 'America/Rosario');
insert into `timezone` (`id`, `name`, `code`) values ('165', 'America/Santa_Isabel', 'America/Santa_Isabel');
insert into `timezone` (`id`, `name`, `code`) values ('166', 'America/Santarem', 'America/Santarem');
insert into `timezone` (`id`, `name`, `code`) values ('167', 'America/Santiago', 'America/Santiago');
insert into `timezone` (`id`, `name`, `code`) values ('168', 'America/Santo_Domingo', 'America/Santo_Domingo');
insert into `timezone` (`id`, `name`, `code`) values ('169', 'America/Sao_Paulo', 'America/Sao_Paulo');
insert into `timezone` (`id`, `name`, `code`) values ('170', 'America/Scoresbysund', 'America/Scoresbysund');
insert into `timezone` (`id`, `name`, `code`) values ('171', 'America/Shiprock', 'America/Shiprock');
insert into `timezone` (`id`, `name`, `code`) values ('172', 'America/St_Barthelemy', 'America/St_Barthelemy');
insert into `timezone` (`id`, `name`, `code`) values ('173', 'America/St_Johns', 'America/St_Johns');
insert into `timezone` (`id`, `name`, `code`) values ('174', 'America/St_Kitts', 'America/St_Kitts');
insert into `timezone` (`id`, `name`, `code`) values ('175', 'America/St_Lucia', 'America/St_Lucia');
insert into `timezone` (`id`, `name`, `code`) values ('176', 'America/St_Thomas', 'America/St_Thomas');
insert into `timezone` (`id`, `name`, `code`) values ('177', 'America/St_Vincent', 'America/St_Vincent');
insert into `timezone` (`id`, `name`, `code`) values ('178', 'America/Swift_Current', 'America/Swift_Current');
insert into `timezone` (`id`, `name`, `code`) values ('179', 'America/Tegucigalpa', 'America/Tegucigalpa');
insert into `timezone` (`id`, `name`, `code`) values ('180', 'America/Thule', 'America/Thule');
insert into `timezone` (`id`, `name`, `code`) values ('181', 'America/Thunder_Bay', 'America/Thunder_Bay');
insert into `timezone` (`id`, `name`, `code`) values ('182', 'America/Tijuana', 'America/Tijuana');
insert into `timezone` (`id`, `name`, `code`) values ('183', 'America/Toronto', 'America/Toronto');
insert into `timezone` (`id`, `name`, `code`) values ('184', 'America/Tortola', 'America/Tortola');
insert into `timezone` (`id`, `name`, `code`) values ('185', 'America/Vancouver', 'America/Vancouver');
insert into `timezone` (`id`, `name`, `code`) values ('186', 'America/Virgin', 'America/Virgin');
insert into `timezone` (`id`, `name`, `code`) values ('187', 'America/Whitehorse', 'America/Whitehorse');
insert into `timezone` (`id`, `name`, `code`) values ('188', 'America/Winnipeg', 'America/Winnipeg');
insert into `timezone` (`id`, `name`, `code`) values ('189', 'America/Yakutat', 'America/Yakutat');
insert into `timezone` (`id`, `name`, `code`) values ('190', 'America/Yellowknife', 'America/Yellowknife');
insert into `timezone` (`id`, `name`, `code`) values ('191', 'Antarctica/Casey', 'Antarctica/Casey');
insert into `timezone` (`id`, `name`, `code`) values ('192', 'Antarctica/Davis', 'Antarctica/Davis');
insert into `timezone` (`id`, `name`, `code`) values ('193', 'Antarctica/DumontDUrville', 'Antarctica/DumontDUrville');
insert into `timezone` (`id`, `name`, `code`) values ('194', 'Antarctica/Macquarie', 'Antarctica/Macquarie');
insert into `timezone` (`id`, `name`, `code`) values ('195', 'Antarctica/Mawson', 'Antarctica/Mawson');
insert into `timezone` (`id`, `name`, `code`) values ('196', 'Antarctica/McMurdo', 'Antarctica/McMurdo');
insert into `timezone` (`id`, `name`, `code`) values ('197', 'Antarctica/Palmer', 'Antarctica/Palmer');
insert into `timezone` (`id`, `name`, `code`) values ('198', 'Antarctica/Rothera', 'Antarctica/Rothera');
insert into `timezone` (`id`, `name`, `code`) values ('199', 'Antarctica/South_Pole', 'Antarctica/South_Pole');
insert into `timezone` (`id`, `name`, `code`) values ('200', 'Antarctica/Syowa', 'Antarctica/Syowa');
insert into `timezone` (`id`, `name`, `code`) values ('201', 'Antarctica/Vostok', 'Antarctica/Vostok');
insert into `timezone` (`id`, `name`, `code`) values ('202', 'Arctic/Longyearbyen', 'Arctic/Longyearbyen');
insert into `timezone` (`id`, `name`, `code`) values ('203', 'Asia/Aden', 'Asia/Aden');
insert into `timezone` (`id`, `name`, `code`) values ('204', 'Asia/Almaty', 'Asia/Almaty');
insert into `timezone` (`id`, `name`, `code`) values ('205', 'Asia/Amman', 'Asia/Amman');
insert into `timezone` (`id`, `name`, `code`) values ('206', 'Asia/Anadyr', 'Asia/Anadyr');
insert into `timezone` (`id`, `name`, `code`) values ('207', 'Asia/Aqtau', 'Asia/Aqtau');
insert into `timezone` (`id`, `name`, `code`) values ('208', 'Asia/Aqtobe', 'Asia/Aqtobe');
insert into `timezone` (`id`, `name`, `code`) values ('209', 'Asia/Ashgabat', 'Asia/Ashgabat');
insert into `timezone` (`id`, `name`, `code`) values ('210', 'Asia/Ashkhabad', 'Asia/Ashkhabad');
insert into `timezone` (`id`, `name`, `code`) values ('211', 'Asia/Baghdad', 'Asia/Baghdad');
insert into `timezone` (`id`, `name`, `code`) values ('212', 'Asia/Bahrain', 'Asia/Bahrain');
insert into `timezone` (`id`, `name`, `code`) values ('213', 'Asia/Baku', 'Asia/Baku');
insert into `timezone` (`id`, `name`, `code`) values ('214', 'Asia/Bangkok', 'Asia/Bangkok');
insert into `timezone` (`id`, `name`, `code`) values ('215', 'Asia/Beirut', 'Asia/Beirut');
insert into `timezone` (`id`, `name`, `code`) values ('216', 'Asia/Bishkek', 'Asia/Bishkek');
insert into `timezone` (`id`, `name`, `code`) values ('217', 'Asia/Brunei', 'Asia/Brunei');
insert into `timezone` (`id`, `name`, `code`) values ('218', 'Asia/Calcutta', 'Asia/Calcutta');
insert into `timezone` (`id`, `name`, `code`) values ('219', 'Asia/Choibalsan', 'Asia/Choibalsan');
insert into `timezone` (`id`, `name`, `code`) values ('220', 'Asia/Chongqing', 'Asia/Chongqing');
insert into `timezone` (`id`, `name`, `code`) values ('221', 'Asia/Chungking', 'Asia/Chungking');
insert into `timezone` (`id`, `name`, `code`) values ('222', 'Asia/Colombo', 'Asia/Colombo');
insert into `timezone` (`id`, `name`, `code`) values ('223', 'Asia/Dacca', 'Asia/Dacca');
insert into `timezone` (`id`, `name`, `code`) values ('224', 'Asia/Damascus', 'Asia/Damascus');
insert into `timezone` (`id`, `name`, `code`) values ('225', 'Asia/Dhaka', 'Asia/Dhaka');
insert into `timezone` (`id`, `name`, `code`) values ('226', 'Asia/Dili', 'Asia/Dili');
insert into `timezone` (`id`, `name`, `code`) values ('227', 'Asia/Dubai', 'Asia/Dubai');
insert into `timezone` (`id`, `name`, `code`) values ('228', 'Asia/Dushanbe', 'Asia/Dushanbe');
insert into `timezone` (`id`, `name`, `code`) values ('229', 'Asia/Gaza', 'Asia/Gaza');
insert into `timezone` (`id`, `name`, `code`) values ('230', 'Asia/Harbin', 'Asia/Harbin');
insert into `timezone` (`id`, `name`, `code`) values ('231', 'Asia/Ho_Chi_Minh', 'Asia/Ho_Chi_Minh');
insert into `timezone` (`id`, `name`, `code`) values ('232', 'Asia/Hong_Kong', 'Asia/Hong_Kong');
insert into `timezone` (`id`, `name`, `code`) values ('233', 'Asia/Hovd', 'Asia/Hovd');
insert into `timezone` (`id`, `name`, `code`) values ('234', 'Asia/Irkutsk', 'Asia/Irkutsk');
insert into `timezone` (`id`, `name`, `code`) values ('235', 'Asia/Istanbul', 'Asia/Istanbul');
insert into `timezone` (`id`, `name`, `code`) values ('236', 'Asia/Jakarta', 'Asia/Jakarta');
insert into `timezone` (`id`, `name`, `code`) values ('237', 'Asia/Jayapura', 'Asia/Jayapura');
insert into `timezone` (`id`, `name`, `code`) values ('238', 'Asia/Jerusalem', 'Asia/Jerusalem');
insert into `timezone` (`id`, `name`, `code`) values ('239', 'Asia/Kabul', 'Asia/Kabul');
insert into `timezone` (`id`, `name`, `code`) values ('240', 'Asia/Kamchatka', 'Asia/Kamchatka');
insert into `timezone` (`id`, `name`, `code`) values ('241', 'Asia/Karachi', 'Asia/Karachi');
insert into `timezone` (`id`, `name`, `code`) values ('242', 'Asia/Kashgar', 'Asia/Kashgar');
insert into `timezone` (`id`, `name`, `code`) values ('243', 'Asia/Kathmandu', 'Asia/Kathmandu');
insert into `timezone` (`id`, `name`, `code`) values ('244', 'Asia/Katmandu', 'Asia/Katmandu');
insert into `timezone` (`id`, `name`, `code`) values ('245', 'Asia/Kolkata', 'Asia/Kolkata');
insert into `timezone` (`id`, `name`, `code`) values ('246', 'Asia/Krasnoyarsk', 'Asia/Krasnoyarsk');
insert into `timezone` (`id`, `name`, `code`) values ('247', 'Asia/Kuala_Lumpur', 'Asia/Kuala_Lumpur');
insert into `timezone` (`id`, `name`, `code`) values ('248', 'Asia/Kuching', 'Asia/Kuching');
insert into `timezone` (`id`, `name`, `code`) values ('249', 'Asia/Kuwait', 'Asia/Kuwait');
insert into `timezone` (`id`, `name`, `code`) values ('250', 'Asia/Macao', 'Asia/Macao');
insert into `timezone` (`id`, `name`, `code`) values ('251', 'Asia/Macau', 'Asia/Macau');
insert into `timezone` (`id`, `name`, `code`) values ('252', 'Asia/Magadan', 'Asia/Magadan');
insert into `timezone` (`id`, `name`, `code`) values ('253', 'Asia/Makassar', 'Asia/Makassar');
insert into `timezone` (`id`, `name`, `code`) values ('254', 'Asia/Manila', 'Asia/Manila');
insert into `timezone` (`id`, `name`, `code`) values ('255', 'Asia/Muscat', 'Asia/Muscat');
insert into `timezone` (`id`, `name`, `code`) values ('256', 'Asia/Nicosia', 'Asia/Nicosia');
insert into `timezone` (`id`, `name`, `code`) values ('257', 'Asia/Novokuznetsk', 'Asia/Novokuznetsk');
insert into `timezone` (`id`, `name`, `code`) values ('258', 'Asia/Novosibirsk', 'Asia/Novosibirsk');
insert into `timezone` (`id`, `name`, `code`) values ('259', 'Asia/Omsk', 'Asia/Omsk');
insert into `timezone` (`id`, `name`, `code`) values ('260', 'Asia/Oral', 'Asia/Oral');
insert into `timezone` (`id`, `name`, `code`) values ('261', 'Asia/Phnom_Penh', 'Asia/Phnom_Penh');
insert into `timezone` (`id`, `name`, `code`) values ('262', 'Asia/Pontianak', 'Asia/Pontianak');
insert into `timezone` (`id`, `name`, `code`) values ('263', 'Asia/Pyongyang', 'Asia/Pyongyang');
insert into `timezone` (`id`, `name`, `code`) values ('264', 'Asia/Qatar', 'Asia/Qatar');
insert into `timezone` (`id`, `name`, `code`) values ('265', 'Asia/Qyzylorda', 'Asia/Qyzylorda');
insert into `timezone` (`id`, `name`, `code`) values ('266', 'Asia/Rangoon', 'Asia/Rangoon');
insert into `timezone` (`id`, `name`, `code`) values ('267', 'Asia/Riyadh', 'Asia/Riyadh');
insert into `timezone` (`id`, `name`, `code`) values ('268', 'Asia/Saigon', 'Asia/Saigon');
insert into `timezone` (`id`, `name`, `code`) values ('269', 'Asia/Sakhalin', 'Asia/Sakhalin');
insert into `timezone` (`id`, `name`, `code`) values ('270', 'Asia/Samarkand', 'Asia/Samarkand');
insert into `timezone` (`id`, `name`, `code`) values ('271', 'Asia/Seoul', 'Asia/Seoul');
insert into `timezone` (`id`, `name`, `code`) values ('272', 'Asia/Shanghai', 'Asia/Shanghai');
insert into `timezone` (`id`, `name`, `code`) values ('273', 'Asia/Singapore', 'Asia/Singapore');
insert into `timezone` (`id`, `name`, `code`) values ('274', 'Asia/Taipei', 'Asia/Taipei');
insert into `timezone` (`id`, `name`, `code`) values ('275', 'Asia/Tashkent', 'Asia/Tashkent');
insert into `timezone` (`id`, `name`, `code`) values ('276', 'Asia/Tbilisi', 'Asia/Tbilisi');
insert into `timezone` (`id`, `name`, `code`) values ('277', 'Asia/Tehran', 'Asia/Tehran');
insert into `timezone` (`id`, `name`, `code`) values ('278', 'Asia/Tel_Aviv', 'Asia/Tel_Aviv');
insert into `timezone` (`id`, `name`, `code`) values ('279', 'Asia/Thimbu', 'Asia/Thimbu');
insert into `timezone` (`id`, `name`, `code`) values ('280', 'Asia/Thimphu', 'Asia/Thimphu');
insert into `timezone` (`id`, `name`, `code`) values ('281', 'Asia/Tokyo', 'Asia/Tokyo');
insert into `timezone` (`id`, `name`, `code`) values ('282', 'Asia/Ujung_Pandang', 'Asia/Ujung_Pandang');
insert into `timezone` (`id`, `name`, `code`) values ('283', 'Asia/Ulaanbaatar', 'Asia/Ulaanbaatar');
insert into `timezone` (`id`, `name`, `code`) values ('284', 'Asia/Ulan_Bator', 'Asia/Ulan_Bator');
insert into `timezone` (`id`, `name`, `code`) values ('285', 'Asia/Urumqi', 'Asia/Urumqi');
insert into `timezone` (`id`, `name`, `code`) values ('286', 'Asia/Vientiane', 'Asia/Vientiane');
insert into `timezone` (`id`, `name`, `code`) values ('287', 'Asia/Vladivostok', 'Asia/Vladivostok');
insert into `timezone` (`id`, `name`, `code`) values ('288', 'Asia/Yakutsk', 'Asia/Yakutsk');
insert into `timezone` (`id`, `name`, `code`) values ('289', 'Asia/Yekaterinburg', 'Asia/Yekaterinburg');
insert into `timezone` (`id`, `name`, `code`) values ('290', 'Asia/Yerevan', 'Asia/Yerevan');
insert into `timezone` (`id`, `name`, `code`) values ('291', 'Atlantic/Azores', 'Atlantic/Azores');
insert into `timezone` (`id`, `name`, `code`) values ('292', 'Atlantic/Bermuda', 'Atlantic/Bermuda');
insert into `timezone` (`id`, `name`, `code`) values ('293', 'Atlantic/Canary', 'Atlantic/Canary');
insert into `timezone` (`id`, `name`, `code`) values ('294', 'Atlantic/Cape_Verde', 'Atlantic/Cape_Verde');
insert into `timezone` (`id`, `name`, `code`) values ('295', 'Atlantic/Faeroe', 'Atlantic/Faeroe');
insert into `timezone` (`id`, `name`, `code`) values ('296', 'Atlantic/Faroe', 'Atlantic/Faroe');
insert into `timezone` (`id`, `name`, `code`) values ('297', 'Atlantic/Jan_Mayen', 'Atlantic/Jan_Mayen');
insert into `timezone` (`id`, `name`, `code`) values ('298', 'Atlantic/Madeira', 'Atlantic/Madeira');
insert into `timezone` (`id`, `name`, `code`) values ('299', 'Atlantic/Reykjavik', 'Atlantic/Reykjavik');
insert into `timezone` (`id`, `name`, `code`) values ('300', 'Atlantic/South_Georgia', 'Atlantic/South_Georgia');
insert into `timezone` (`id`, `name`, `code`) values ('301', 'Atlantic/St_Helena', 'Atlantic/St_Helena');
insert into `timezone` (`id`, `name`, `code`) values ('302', 'Atlantic/Stanley', 'Atlantic/Stanley');
insert into `timezone` (`id`, `name`, `code`) values ('303', 'Australia/ACT', 'Australia/ACT');
insert into `timezone` (`id`, `name`, `code`) values ('304', 'Australia/Adelaide', 'Australia/Adelaide');
insert into `timezone` (`id`, `name`, `code`) values ('305', 'Australia/Brisbane', 'Australia/Brisbane');
insert into `timezone` (`id`, `name`, `code`) values ('306', 'Australia/Broken_Hill', 'Australia/Broken_Hill');
insert into `timezone` (`id`, `name`, `code`) values ('307', 'Australia/Canberra', 'Australia/Canberra');
insert into `timezone` (`id`, `name`, `code`) values ('308', 'Australia/Currie', 'Australia/Currie');
insert into `timezone` (`id`, `name`, `code`) values ('309', 'Australia/Darwin', 'Australia/Darwin');
insert into `timezone` (`id`, `name`, `code`) values ('310', 'Australia/Eucla', 'Australia/Eucla');
insert into `timezone` (`id`, `name`, `code`) values ('311', 'Australia/Hobart', 'Australia/Hobart');
insert into `timezone` (`id`, `name`, `code`) values ('312', 'Australia/LHI', 'Australia/LHI');
insert into `timezone` (`id`, `name`, `code`) values ('313', 'Australia/Lindeman', 'Australia/Lindeman');
insert into `timezone` (`id`, `name`, `code`) values ('314', 'Australia/Lord_Howe', 'Australia/Lord_Howe');
insert into `timezone` (`id`, `name`, `code`) values ('315', 'Australia/Melbourne', 'Australia/Melbourne');
insert into `timezone` (`id`, `name`, `code`) values ('316', 'Australia/NSW', 'Australia/NSW');
insert into `timezone` (`id`, `name`, `code`) values ('317', 'Australia/North', 'Australia/North');
insert into `timezone` (`id`, `name`, `code`) values ('318', 'Australia/Perth', 'Australia/Perth');
insert into `timezone` (`id`, `name`, `code`) values ('319', 'Australia/Queensland', 'Australia/Queensland');
insert into `timezone` (`id`, `name`, `code`) values ('320', 'Australia/South', 'Australia/South');
insert into `timezone` (`id`, `name`, `code`) values ('321', 'Australia/Sydney', 'Australia/Sydney');
insert into `timezone` (`id`, `name`, `code`) values ('322', 'Australia/Tasmania', 'Australia/Tasmania');
insert into `timezone` (`id`, `name`, `code`) values ('323', 'Australia/Victoria', 'Australia/Victoria');
insert into `timezone` (`id`, `name`, `code`) values ('324', 'Australia/West', 'Australia/West');
insert into `timezone` (`id`, `name`, `code`) values ('325', 'Australia/Yancowinna', 'Australia/Yancowinna');
insert into `timezone` (`id`, `name`, `code`) values ('326', 'Brazil/Acre', 'Brazil/Acre');
insert into `timezone` (`id`, `name`, `code`) values ('327', 'Brazil/DeNoronha', 'Brazil/DeNoronha');
insert into `timezone` (`id`, `name`, `code`) values ('328', 'Brazil/East', 'Brazil/East');
insert into `timezone` (`id`, `name`, `code`) values ('329', 'Brazil/West', 'Brazil/West');
insert into `timezone` (`id`, `name`, `code`) values ('330', 'CET', 'CET');
insert into `timezone` (`id`, `name`, `code`) values ('331', 'CST6CDT', 'CST6CDT');
insert into `timezone` (`id`, `name`, `code`) values ('332', 'Canada/Atlantic', 'Canada/Atlantic');
insert into `timezone` (`id`, `name`, `code`) values ('333', 'Canada/Central', 'Canada/Central');
insert into `timezone` (`id`, `name`, `code`) values ('334', 'Canada/East-Saskatchewan', 'Canada/East-Saskatchewan');
insert into `timezone` (`id`, `name`, `code`) values ('335', 'Canada/Eastern', 'Canada/Eastern');
insert into `timezone` (`id`, `name`, `code`) values ('336', 'Canada/Mountain', 'Canada/Mountain');
insert into `timezone` (`id`, `name`, `code`) values ('337', 'Canada/Newfoundland', 'Canada/Newfoundland');
insert into `timezone` (`id`, `name`, `code`) values ('338', 'Canada/Pacific', 'Canada/Pacific');
insert into `timezone` (`id`, `name`, `code`) values ('339', 'Canada/Saskatchewan', 'Canada/Saskatchewan');
insert into `timezone` (`id`, `name`, `code`) values ('340', 'Canada/Yukon', 'Canada/Yukon');
insert into `timezone` (`id`, `name`, `code`) values ('341', 'Chile/Continental', 'Chile/Continental');
insert into `timezone` (`id`, `name`, `code`) values ('342', 'Chile/EasterIsland', 'Chile/EasterIsland');
insert into `timezone` (`id`, `name`, `code`) values ('343', 'Cuba', 'Cuba');
insert into `timezone` (`id`, `name`, `code`) values ('344', 'EET', 'EET');
insert into `timezone` (`id`, `name`, `code`) values ('345', 'EST', 'EST');
insert into `timezone` (`id`, `name`, `code`) values ('346', 'EST5EDT', 'EST5EDT');
insert into `timezone` (`id`, `name`, `code`) values ('347', 'Egypt', 'Egypt');
insert into `timezone` (`id`, `name`, `code`) values ('348', 'Eire', 'Eire');
insert into `timezone` (`id`, `name`, `code`) values ('349', 'Etc/GMT+0', 'Etc/GMT+0');
insert into `timezone` (`id`, `name`, `code`) values ('350', 'Etc/GMT+1', 'Etc/GMT+1');
insert into `timezone` (`id`, `name`, `code`) values ('351', 'Etc/GMT+10', 'Etc/GMT+10');
insert into `timezone` (`id`, `name`, `code`) values ('352', 'Etc/GMT+11', 'Etc/GMT+11');
insert into `timezone` (`id`, `name`, `code`) values ('353', 'Etc/GMT+12', 'Etc/GMT+12');
insert into `timezone` (`id`, `name`, `code`) values ('354', 'Etc/GMT+2', 'Etc/GMT+2');
insert into `timezone` (`id`, `name`, `code`) values ('355', 'Etc/GMT+3', 'Etc/GMT+3');
insert into `timezone` (`id`, `name`, `code`) values ('356', 'Etc/GMT+4', 'Etc/GMT+4');
insert into `timezone` (`id`, `name`, `code`) values ('357', 'Etc/GMT+5', 'Etc/GMT+5');
insert into `timezone` (`id`, `name`, `code`) values ('358', 'Etc/GMT+6', 'Etc/GMT+6');
insert into `timezone` (`id`, `name`, `code`) values ('359', 'Etc/GMT+7', 'Etc/GMT+7');
insert into `timezone` (`id`, `name`, `code`) values ('360', 'Etc/GMT+8', 'Etc/GMT+8');
insert into `timezone` (`id`, `name`, `code`) values ('361', 'Etc/GMT+9', 'Etc/GMT+9');
insert into `timezone` (`id`, `name`, `code`) values ('362', 'Etc/GMT-0', 'Etc/GMT-0');
insert into `timezone` (`id`, `name`, `code`) values ('363', 'Etc/GMT-1', 'Etc/GMT-1');
insert into `timezone` (`id`, `name`, `code`) values ('364', 'Etc/GMT-10', 'Etc/GMT-10');
insert into `timezone` (`id`, `name`, `code`) values ('365', 'Etc/GMT-11', 'Etc/GMT-11');
insert into `timezone` (`id`, `name`, `code`) values ('366', 'Etc/GMT-12', 'Etc/GMT-12');
insert into `timezone` (`id`, `name`, `code`) values ('367', 'Etc/GMT-13', 'Etc/GMT-13');
insert into `timezone` (`id`, `name`, `code`) values ('368', 'Etc/GMT-14', 'Etc/GMT-14');
insert into `timezone` (`id`, `name`, `code`) values ('369', 'Etc/GMT-2', 'Etc/GMT-2');
insert into `timezone` (`id`, `name`, `code`) values ('370', 'Etc/GMT-3', 'Etc/GMT-3');
insert into `timezone` (`id`, `name`, `code`) values ('371', 'Etc/GMT-4', 'Etc/GMT-4');
insert into `timezone` (`id`, `name`, `code`) values ('372', 'Etc/GMT-5', 'Etc/GMT-5');
insert into `timezone` (`id`, `name`, `code`) values ('373', 'Etc/GMT-6', 'Etc/GMT-6');
insert into `timezone` (`id`, `name`, `code`) values ('374', 'Etc/GMT-7', 'Etc/GMT-7');
insert into `timezone` (`id`, `name`, `code`) values ('375', 'Etc/GMT-8', 'Etc/GMT-8');
insert into `timezone` (`id`, `name`, `code`) values ('376', 'Etc/GMT-9', 'Etc/GMT-9');
insert into `timezone` (`id`, `name`, `code`) values ('377', 'Etc/GMT', 'Etc/GMT');
insert into `timezone` (`id`, `name`, `code`) values ('378', 'Etc/GMT0', 'Etc/GMT0');
insert into `timezone` (`id`, `name`, `code`) values ('379', 'Etc/Greenwich', 'Etc/Greenwich');
insert into `timezone` (`id`, `name`, `code`) values ('380', 'Etc/UCT', 'Etc/UCT');
insert into `timezone` (`id`, `name`, `code`) values ('381', 'Etc/UTC', 'Etc/UTC');
insert into `timezone` (`id`, `name`, `code`) values ('382', 'Etc/Universal', 'Etc/Universal');
insert into `timezone` (`id`, `name`, `code`) values ('383', 'Etc/Zulu', 'Etc/Zulu');
insert into `timezone` (`id`, `name`, `code`) values ('384', 'Europe/Amsterdam', 'Europe/Amsterdam');
insert into `timezone` (`id`, `name`, `code`) values ('385', 'Europe/Andorra', 'Europe/Andorra');
insert into `timezone` (`id`, `name`, `code`) values ('386', 'Europe/Athens', 'Europe/Athens');
insert into `timezone` (`id`, `name`, `code`) values ('387', 'Europe/Belfast', 'Europe/Belfast');
insert into `timezone` (`id`, `name`, `code`) values ('388', 'Europe/Belgrade', 'Europe/Belgrade');
insert into `timezone` (`id`, `name`, `code`) values ('389', 'Europe/Berlin', 'Europe/Berlin');
insert into `timezone` (`id`, `name`, `code`) values ('390', 'Europe/Bratislava', 'Europe/Bratislava');
insert into `timezone` (`id`, `name`, `code`) values ('391', 'Europe/Brussels', 'Europe/Brussels');
insert into `timezone` (`id`, `name`, `code`) values ('392', 'Europe/Bucharest', 'Europe/Bucharest');
insert into `timezone` (`id`, `name`, `code`) values ('393', 'Europe/Budapest', 'Europe/Budapest');
insert into `timezone` (`id`, `name`, `code`) values ('394', 'Europe/Chisinau', 'Europe/Chisinau');
insert into `timezone` (`id`, `name`, `code`) values ('395', 'Europe/Copenhagen', 'Europe/Copenhagen');
insert into `timezone` (`id`, `name`, `code`) values ('396', 'Europe/Dublin', 'Europe/Dublin');
insert into `timezone` (`id`, `name`, `code`) values ('397', 'Europe/Gibraltar', 'Europe/Gibraltar');
insert into `timezone` (`id`, `name`, `code`) values ('398', 'Europe/Guernsey', 'Europe/Guernsey');
insert into `timezone` (`id`, `name`, `code`) values ('399', 'Europe/Helsinki', 'Europe/Helsinki');
insert into `timezone` (`id`, `name`, `code`) values ('400', 'Europe/Isle_of_Man', 'Europe/Isle_of_Man');
insert into `timezone` (`id`, `name`, `code`) values ('401', 'Europe/Istanbul', 'Europe/Istanbul');
insert into `timezone` (`id`, `name`, `code`) values ('402', 'Europe/Jersey', 'Europe/Jersey');
insert into `timezone` (`id`, `name`, `code`) values ('403', 'Europe/Kaliningrad', 'Europe/Kaliningrad');
insert into `timezone` (`id`, `name`, `code`) values ('404', 'Europe/Kiev', 'Europe/Kiev');
insert into `timezone` (`id`, `name`, `code`) values ('405', 'Europe/Lisbon', 'Europe/Lisbon');
insert into `timezone` (`id`, `name`, `code`) values ('406', 'Europe/Ljubljana', 'Europe/Ljubljana');
insert into `timezone` (`id`, `name`, `code`) values ('407', 'Europe/London', 'Europe/London');
insert into `timezone` (`id`, `name`, `code`) values ('408', 'Europe/Luxembourg', 'Europe/Luxembourg');
insert into `timezone` (`id`, `name`, `code`) values ('409', 'Europe/Madrid', 'Europe/Madrid');
insert into `timezone` (`id`, `name`, `code`) values ('410', 'Europe/Malta', 'Europe/Malta');
insert into `timezone` (`id`, `name`, `code`) values ('411', 'Europe/Mariehamn', 'Europe/Mariehamn');
insert into `timezone` (`id`, `name`, `code`) values ('412', 'Europe/Minsk', 'Europe/Minsk');
insert into `timezone` (`id`, `name`, `code`) values ('413', 'Europe/Monaco', 'Europe/Monaco');
insert into `timezone` (`id`, `name`, `code`) values ('414', 'Europe/Moscow', 'Europe/Moscow');
insert into `timezone` (`id`, `name`, `code`) values ('415', 'Europe/Nicosia', 'Europe/Nicosia');
insert into `timezone` (`id`, `name`, `code`) values ('416', 'Europe/Oslo', 'Europe/Oslo');
insert into `timezone` (`id`, `name`, `code`) values ('417', 'Europe/Paris', 'Europe/Paris');
insert into `timezone` (`id`, `name`, `code`) values ('418', 'Europe/Podgorica', 'Europe/Podgorica');
insert into `timezone` (`id`, `name`, `code`) values ('419', 'Europe/Prague', 'Europe/Prague');
insert into `timezone` (`id`, `name`, `code`) values ('420', 'Europe/Riga', 'Europe/Riga');
insert into `timezone` (`id`, `name`, `code`) values ('421', 'Europe/Rome', 'Europe/Rome');
insert into `timezone` (`id`, `name`, `code`) values ('422', 'Europe/Samara', 'Europe/Samara');
insert into `timezone` (`id`, `name`, `code`) values ('423', 'Europe/San_Marino', 'Europe/San_Marino');
insert into `timezone` (`id`, `name`, `code`) values ('424', 'Europe/Sarajevo', 'Europe/Sarajevo');
insert into `timezone` (`id`, `name`, `code`) values ('425', 'Europe/Simferopol', 'Europe/Simferopol');
insert into `timezone` (`id`, `name`, `code`) values ('426', 'Europe/Skopje', 'Europe/Skopje');
insert into `timezone` (`id`, `name`, `code`) values ('427', 'Europe/Sofia', 'Europe/Sofia');
insert into `timezone` (`id`, `name`, `code`) values ('428', 'Europe/Stockholm', 'Europe/Stockholm');
insert into `timezone` (`id`, `name`, `code`) values ('429', 'Europe/Tallinn', 'Europe/Tallinn');
insert into `timezone` (`id`, `name`, `code`) values ('430', 'Europe/Tirane', 'Europe/Tirane');
insert into `timezone` (`id`, `name`, `code`) values ('431', 'Europe/Tiraspol', 'Europe/Tiraspol');
insert into `timezone` (`id`, `name`, `code`) values ('432', 'Europe/Uzhgorod', 'Europe/Uzhgorod');
insert into `timezone` (`id`, `name`, `code`) values ('433', 'Europe/Vaduz', 'Europe/Vaduz');
insert into `timezone` (`id`, `name`, `code`) values ('434', 'Europe/Vatican', 'Europe/Vatican');
insert into `timezone` (`id`, `name`, `code`) values ('435', 'Europe/Vienna', 'Europe/Vienna');
insert into `timezone` (`id`, `name`, `code`) values ('436', 'Europe/Vilnius', 'Europe/Vilnius');
insert into `timezone` (`id`, `name`, `code`) values ('437', 'Europe/Volgograd', 'Europe/Volgograd');
insert into `timezone` (`id`, `name`, `code`) values ('438', 'Europe/Warsaw', 'Europe/Warsaw');
insert into `timezone` (`id`, `name`, `code`) values ('439', 'Europe/Zagreb', 'Europe/Zagreb');
insert into `timezone` (`id`, `name`, `code`) values ('440', 'Europe/Zaporozhye', 'Europe/Zaporozhye');
insert into `timezone` (`id`, `name`, `code`) values ('441', 'Europe/Zurich', 'Europe/Zurich');
insert into `timezone` (`id`, `name`, `code`) values ('442', 'GB-Eire', 'GB-Eire');
insert into `timezone` (`id`, `name`, `code`) values ('443', 'GB', 'GB');
insert into `timezone` (`id`, `name`, `code`) values ('444', 'GMT+0', 'GMT+0');
insert into `timezone` (`id`, `name`, `code`) values ('445', 'GMT-0', 'GMT-0');
insert into `timezone` (`id`, `name`, `code`) values ('446', 'GMT', 'GMT');
insert into `timezone` (`id`, `name`, `code`) values ('447', 'GMT0', 'GMT0');
insert into `timezone` (`id`, `name`, `code`) values ('448', 'Greenwich', 'Greenwich');
insert into `timezone` (`id`, `name`, `code`) values ('449', 'HST', 'HST');
insert into `timezone` (`id`, `name`, `code`) values ('450', 'Hongkong', 'Hongkong');
insert into `timezone` (`id`, `name`, `code`) values ('451', 'Iceland', 'Iceland');
insert into `timezone` (`id`, `name`, `code`) values ('452', 'Indian/Antananarivo', 'Indian/Antananarivo');
insert into `timezone` (`id`, `name`, `code`) values ('453', 'Indian/Chagos', 'Indian/Chagos');
insert into `timezone` (`id`, `name`, `code`) values ('454', 'Indian/Christmas', 'Indian/Christmas');
insert into `timezone` (`id`, `name`, `code`) values ('455', 'Indian/Cocos', 'Indian/Cocos');
insert into `timezone` (`id`, `name`, `code`) values ('456', 'Indian/Comoro', 'Indian/Comoro');
insert into `timezone` (`id`, `name`, `code`) values ('457', 'Indian/Kerguelen', 'Indian/Kerguelen');
insert into `timezone` (`id`, `name`, `code`) values ('458', 'Indian/Mahe', 'Indian/Mahe');
insert into `timezone` (`id`, `name`, `code`) values ('459', 'Indian/Maldives', 'Indian/Maldives');
insert into `timezone` (`id`, `name`, `code`) values ('460', 'Indian/Mauritius', 'Indian/Mauritius');
insert into `timezone` (`id`, `name`, `code`) values ('461', 'Indian/Mayotte', 'Indian/Mayotte');
insert into `timezone` (`id`, `name`, `code`) values ('462', 'Indian/Reunion', 'Indian/Reunion');
insert into `timezone` (`id`, `name`, `code`) values ('463', 'Iran', 'Iran');
insert into `timezone` (`id`, `name`, `code`) values ('464', 'Israel', 'Israel');
insert into `timezone` (`id`, `name`, `code`) values ('465', 'Jamaica', 'Jamaica');
insert into `timezone` (`id`, `name`, `code`) values ('466', 'Japan', 'Japan');
insert into `timezone` (`id`, `name`, `code`) values ('467', 'Kwajalein', 'Kwajalein');
insert into `timezone` (`id`, `name`, `code`) values ('468', 'Libya', 'Libya');
insert into `timezone` (`id`, `name`, `code`) values ('469', 'MET', 'MET');
insert into `timezone` (`id`, `name`, `code`) values ('470', 'MST', 'MST');
insert into `timezone` (`id`, `name`, `code`) values ('471', 'MST7MDT', 'MST7MDT');
insert into `timezone` (`id`, `name`, `code`) values ('472', 'Mexico/BajaNorte', 'Mexico/BajaNorte');
insert into `timezone` (`id`, `name`, `code`) values ('473', 'Mexico/BajaSur', 'Mexico/BajaSur');
insert into `timezone` (`id`, `name`, `code`) values ('474', 'Mexico/General', 'Mexico/General');
insert into `timezone` (`id`, `name`, `code`) values ('475', 'NZ-CHAT', 'NZ-CHAT');
insert into `timezone` (`id`, `name`, `code`) values ('476', 'NZ', 'NZ');
insert into `timezone` (`id`, `name`, `code`) values ('477', 'Navajo', 'Navajo');
insert into `timezone` (`id`, `name`, `code`) values ('478', 'PRC', 'PRC');
insert into `timezone` (`id`, `name`, `code`) values ('479', 'PST8PDT', 'PST8PDT');
insert into `timezone` (`id`, `name`, `code`) values ('480', 'Pacific/Apia', 'Pacific/Apia');
insert into `timezone` (`id`, `name`, `code`) values ('481', 'Pacific/Auckland', 'Pacific/Auckland');
insert into `timezone` (`id`, `name`, `code`) values ('482', 'Pacific/Chatham', 'Pacific/Chatham');
insert into `timezone` (`id`, `name`, `code`) values ('483', 'Pacific/Chuuk', 'Pacific/Chuuk');
insert into `timezone` (`id`, `name`, `code`) values ('484', 'Pacific/Easter', 'Pacific/Easter');
insert into `timezone` (`id`, `name`, `code`) values ('485', 'Pacific/Efate', 'Pacific/Efate');
insert into `timezone` (`id`, `name`, `code`) values ('486', 'Pacific/Enderbury', 'Pacific/Enderbury');
insert into `timezone` (`id`, `name`, `code`) values ('487', 'Pacific/Fakaofo', 'Pacific/Fakaofo');
insert into `timezone` (`id`, `name`, `code`) values ('488', 'Pacific/Fiji', 'Pacific/Fiji');
insert into `timezone` (`id`, `name`, `code`) values ('489', 'Pacific/Funafuti', 'Pacific/Funafuti');
insert into `timezone` (`id`, `name`, `code`) values ('490', 'Pacific/Galapagos', 'Pacific/Galapagos');
insert into `timezone` (`id`, `name`, `code`) values ('491', 'Pacific/Gambier', 'Pacific/Gambier');
insert into `timezone` (`id`, `name`, `code`) values ('492', 'Pacific/Guadalcanal', 'Pacific/Guadalcanal');
insert into `timezone` (`id`, `name`, `code`) values ('493', 'Pacific/Guam', 'Pacific/Guam');
insert into `timezone` (`id`, `name`, `code`) values ('494', 'Pacific/Honolulu', 'Pacific/Honolulu');
insert into `timezone` (`id`, `name`, `code`) values ('495', 'Pacific/Johnston', 'Pacific/Johnston');
insert into `timezone` (`id`, `name`, `code`) values ('496', 'Pacific/Kiritimati', 'Pacific/Kiritimati');
insert into `timezone` (`id`, `name`, `code`) values ('497', 'Pacific/Kosrae', 'Pacific/Kosrae');
insert into `timezone` (`id`, `name`, `code`) values ('498', 'Pacific/Kwajalein', 'Pacific/Kwajalein');
insert into `timezone` (`id`, `name`, `code`) values ('499', 'Pacific/Majuro', 'Pacific/Majuro');
insert into `timezone` (`id`, `name`, `code`) values ('500', 'Pacific/Marquesas', 'Pacific/Marquesas');
insert into `timezone` (`id`, `name`, `code`) values ('501', 'Pacific/Midway', 'Pacific/Midway');
insert into `timezone` (`id`, `name`, `code`) values ('502', 'Pacific/Nauru', 'Pacific/Nauru');
insert into `timezone` (`id`, `name`, `code`) values ('503', 'Pacific/Niue', 'Pacific/Niue');
insert into `timezone` (`id`, `name`, `code`) values ('504', 'Pacific/Norfolk', 'Pacific/Norfolk');
insert into `timezone` (`id`, `name`, `code`) values ('505', 'Pacific/Noumea', 'Pacific/Noumea');
insert into `timezone` (`id`, `name`, `code`) values ('506', 'Pacific/Pago_Pago', 'Pacific/Pago_Pago');
insert into `timezone` (`id`, `name`, `code`) values ('507', 'Pacific/Palau', 'Pacific/Palau');
insert into `timezone` (`id`, `name`, `code`) values ('508', 'Pacific/Pitcairn', 'Pacific/Pitcairn');
insert into `timezone` (`id`, `name`, `code`) values ('509', 'Pacific/Pohnpei', 'Pacific/Pohnpei');
insert into `timezone` (`id`, `name`, `code`) values ('510', 'Pacific/Ponape', 'Pacific/Ponape');
insert into `timezone` (`id`, `name`, `code`) values ('511', 'Pacific/Port_Moresby', 'Pacific/Port_Moresby');
insert into `timezone` (`id`, `name`, `code`) values ('512', 'Pacific/Rarotonga', 'Pacific/Rarotonga');
insert into `timezone` (`id`, `name`, `code`) values ('513', 'Pacific/Saipan', 'Pacific/Saipan');
insert into `timezone` (`id`, `name`, `code`) values ('514', 'Pacific/Samoa', 'Pacific/Samoa');
insert into `timezone` (`id`, `name`, `code`) values ('515', 'Pacific/Tahiti', 'Pacific/Tahiti');
insert into `timezone` (`id`, `name`, `code`) values ('516', 'Pacific/Tarawa', 'Pacific/Tarawa');
insert into `timezone` (`id`, `name`, `code`) values ('517', 'Pacific/Tongatapu', 'Pacific/Tongatapu');
insert into `timezone` (`id`, `name`, `code`) values ('518', 'Pacific/Truk', 'Pacific/Truk');
insert into `timezone` (`id`, `name`, `code`) values ('519', 'Pacific/Wake', 'Pacific/Wake');
insert into `timezone` (`id`, `name`, `code`) values ('520', 'Pacific/Wallis', 'Pacific/Wallis');
insert into `timezone` (`id`, `name`, `code`) values ('521', 'Pacific/Yap', 'Pacific/Yap');
insert into `timezone` (`id`, `name`, `code`) values ('522', 'Poland', 'Poland');
insert into `timezone` (`id`, `name`, `code`) values ('523', 'Portugal', 'Portugal');
insert into `timezone` (`id`, `name`, `code`) values ('524', 'ROC', 'ROC');
insert into `timezone` (`id`, `name`, `code`) values ('525', 'ROK', 'ROK');
insert into `timezone` (`id`, `name`, `code`) values ('526', 'Singapore', 'Singapore');
insert into `timezone` (`id`, `name`, `code`) values ('527', 'Turkey', 'Turkey');
insert into `timezone` (`id`, `name`, `code`) values ('528', 'UCT', 'UCT');
insert into `timezone` (`id`, `name`, `code`) values ('529', 'US/Alaska', 'US/Alaska');
insert into `timezone` (`id`, `name`, `code`) values ('530', 'US/Aleutian', 'US/Aleutian');
insert into `timezone` (`id`, `name`, `code`) values ('531', 'US/Arizona', 'US/Arizona');
insert into `timezone` (`id`, `name`, `code`) values ('532', 'US/Central', 'US/Central');
insert into `timezone` (`id`, `name`, `code`) values ('533', 'US/East-Indiana', 'US/East-Indiana');
insert into `timezone` (`id`, `name`, `code`) values ('534', 'US/Eastern', 'US/Eastern');
insert into `timezone` (`id`, `name`, `code`) values ('535', 'US/Hawaii', 'US/Hawaii');
insert into `timezone` (`id`, `name`, `code`) values ('536', 'US/Indiana-Starke', 'US/Indiana-Starke');
insert into `timezone` (`id`, `name`, `code`) values ('537', 'US/Michigan', 'US/Michigan');
insert into `timezone` (`id`, `name`, `code`) values ('538', 'US/Mountain', 'US/Mountain');
insert into `timezone` (`id`, `name`, `code`) values ('539', 'US/Pacific', 'US/Pacific');
insert into `timezone` (`id`, `name`, `code`) values ('540', 'US/Samoa', 'US/Samoa');
insert into `timezone` (`id`, `name`, `code`) values ('541', 'UTC', 'UTC');
insert into `timezone` (`id`, `name`, `code`) values ('542', 'Universal', 'Universal');
insert into `timezone` (`id`, `name`, `code`) values ('543', 'W-SU', 'W-SU');
insert into `timezone` (`id`, `name`, `code`) values ('544', 'WET', 'WET');
insert into `timezone` (`id`, `name`, `code`) values ('545', 'Zulu', 'Zulu');

drop table if exists `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) collate utf8_unicode_ci default NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `usertype` enum('A','S','T','P') collate utf8_unicode_ci NOT NULL,
  `schoolid` int(11) NOT NULL,
  `hashed_password` varchar(255) collate utf8_unicode_ci default NULL,
  `salt` varchar(255) collate utf8_unicode_ci default NULL,
  `reset_password_code` varchar(255) collate utf8_unicode_ci default NULL,
  `reset_password_code_until` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_users_on_username` (`username`(10))
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('1', 'admin', 'Administrator', NULL, 'mscosian@gmail.com', 'A', '0', '21232f297a57a5a743894a0e4a801fc3 ', NULL, NULL, NULL, '2011-10-18 14:11:22', '2011-10-18 14:11:26');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('2', 'sec1', 'Rohit', 'Kumar', 'sec1@gmail.com', 'S', '1', '35f7bba0a937a63ed13dae2232ee4b51', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('3', 'emp1', 'Rajesh', '', 'abc@ymail.com', 'S', '1', 'b2157e7b2ae716a747597717f1efb7a0', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('5', 'teacher1', NULL, NULL, NULL, 'T', '1', '8d788385431273d11e8b43bb78f3aa41', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('6', 'emp3', NULL, NULL, NULL, 'T', '1', '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('7', 'pr11', NULL, NULL, NULL, 'P', '0', '2859691746dcfd5fe9d9c17adff9c5e7', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('8', 'teacher2', NULL, NULL, NULL, 'T', '1', '8d788385431273d11e8b43bb78f3aa41', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('9', 'teacher4', NULL, NULL, NULL, 'T', '1', '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('10', 'teacher5', NULL, NULL, NULL, 'T', '1', '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('12', 'pr1', 'Suresh', NULL, NULL, 'P', '1', 'a6c85163d954c307a1d552fb61054bb8', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('13', 'pr3', NULL, NULL, NULL, 'P', '1', 'f5fa6d847e7c75cf5a2d09d5598c3919', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('14', 'pr4', NULL, NULL, NULL, 'P', '1', '900150983cd24fb0d6963f7d28e17f72', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('15', 'sec3', 'Vikas', '', 'xyz@gmail.com', 'S', '2', '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('16', 't21', 'Ajay', NULL, NULL, 'T', '2', '9c1b6f896457f01432dd4e3f3f48851d', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('17', 'pr5', NULL, NULL, NULL, 'P', '2', 'bbd995f68703c80c22e8864dd4983682', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('18', 'pr6', NULL, NULL, NULL, 'P', '2', 'a33703c87cca53aa16998617bde71873', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('19', 'pr7', NULL, NULL, NULL, 'P', '1', 'fa814d01ed04095d007f6d3e4685d19d', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('20', 'sec5', 'Mahesh', 'Kumar', 'xyz@ymail.com', 'S', '4', '5c76745167db82c78ce2647a6ea7b425', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('21', 'pr8', NULL, NULL, NULL, 'P', '1', '6cc051dd270924a68edcddae9009845d', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('22', 'jai', NULL, NULL, NULL, 'P', '0', '421493fa48fc8df84d1f5f3478cf247a', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('23', 'pr10', NULL, NULL, NULL, 'P', '1', '5f6b2a23aa03240e01914ff83be86f19', NULL, NULL, NULL, NULL, NULL);
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`) values ('24', 'pr12', NULL, NULL, NULL, 'P', '1', '4b45b618444f7f90fc84d5f7c5326dce', NULL, NULL, NULL, NULL, NULL);

drop table if exists `weekdays`;
CREATE TABLE `weekdays` (
  `id` int(11) NOT NULL auto_increment,
  `batch_id` int(11) default NULL,
  `weekday` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_weekdays_on_batch_id` (`batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `weekdays` (`id`, `batch_id`, `weekday`) values ('5', '5', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`) values ('6', '5', '3');
insert into `weekdays` (`id`, `batch_id`, `weekday`) values ('7', '4', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`) values ('8', '4', '2');
insert into `weekdays` (`id`, `batch_id`, `weekday`) values ('9', '4', '3');
insert into `weekdays` (`id`, `batch_id`, `weekday`) values ('10', '4', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`) values ('11', '4', '5');
insert into `weekdays` (`id`, `batch_id`, `weekday`) values ('12', '4', '6');
