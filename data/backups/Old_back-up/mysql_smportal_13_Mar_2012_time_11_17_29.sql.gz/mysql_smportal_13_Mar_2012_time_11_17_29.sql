# MySQL backup created by phpMySQLAutoBackup
#
# http://www.dwalker.co.uk/phpmysqlautobackup/
#
# Database: smportal
# Domain name: localhost
# (c)2012 localhost
#
# Backup START time: 11:17:29
# Backup END time: 11:17:29
# Backup Date: 13 Mar 2012

drop table if exists `additional_exam_groups`;
CREATE TABLE `additional_exam_groups` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `exam_type` varchar(255) collate utf8_unicode_ci default NULL,
  `is_published` tinyint(1) default '0',
  `result_published` tinyint(1) default '0',
  `students_list` varchar(255) collate utf8_unicode_ci default NULL,
  `exam_date` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

drop table if exists `additional_exam_scores`;
CREATE TABLE `additional_exam_scores` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `additional_exam_id` int(11) default NULL,
  `marks` decimal(7,2) default NULL,
  `grading_level_id` int(11) default NULL,
  `remarks` varchar(255) collate utf8_unicode_ci default NULL,
  `is_failed` tinyint(1) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

drop table if exists `additional_exams`;
CREATE TABLE `additional_exams` (
  `id` int(11) NOT NULL auto_increment,
  `additional_exam_group_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  `start_time` datetime default NULL,
  `end_time` datetime default NULL,
  `maximum_marks` int(11) default NULL,
  `minimum_marks` int(11) default NULL,
  `grading_level_id` int(11) default NULL,
  `weightage` int(11) default '0',
  `event_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

drop table if exists `archive_attendances`;
CREATE TABLE `archive_attendances` (
  `id` int(11) NOT NULL auto_increment,
  `arc_student_id` int(11) default NULL,
  `student_id` int(11) default NULL,
  `schoolid` int(11) NOT NULL default '0',
  `period_table_entry_id` int(11) default NULL,
  `forenoon` tinyint(1) default '0',
  `afternoon` tinyint(1) default '0',
  `reason` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `archive_attendances` (`id`, `arc_student_id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('1', '20', '13', '1', '8', '1', '1', 'went outside');
insert into `archive_attendances` (`id`, `arc_student_id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('2', '20', '13', '1', '2', '1', '0', 'taking rest');
insert into `archive_attendances` (`id`, `arc_student_id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('3', '24', '30', '4', '788', '1', '0', 'Party');
insert into `archive_attendances` (`id`, `arc_student_id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('4', '24', '30', '4', '804', '1', '1', 'went outside');
insert into `archive_attendances` (`id`, `arc_student_id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('5', '24', '30', '4', '905', '1', '1', 'fever');
insert into `archive_attendances` (`id`, `arc_student_id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('6', '24', '30', '4', '928', '0', '1', 'leave');
insert into `archive_attendances` (`id`, `arc_student_id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('7', '25', '31', '4', '2064', '0', '1', 'Headache');
insert into `archive_attendances` (`id`, `arc_student_id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('8', '25', '31', '4', '2071', '1', '1', 'Occassion at home');
insert into `archive_attendances` (`id`, `arc_student_id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('9', '25', '31', '4', '2140', '1', '0', 'Hav Not Studied');
insert into `archive_attendances` (`id`, `arc_student_id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('10', '25', '31', '4', '2152', '1', '1', 'Exam Preparation');
insert into `archive_attendances` (`id`, `arc_student_id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('11', '25', '31', '4', '2153', '1', '1', 'Exam Preparation');
insert into `archive_attendances` (`id`, `arc_student_id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('12', '25', '31', '4', '2154', '0', '1', 'aaaa');
insert into `archive_attendances` (`id`, `arc_student_id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('13', '26', '2', '1', '1257', '1', '0', 'aasa');

drop table if exists `archive_exam_scores`;
CREATE TABLE `archive_exam_scores` (
  `id` int(11) NOT NULL auto_increment,
  `arc_student_id` int(11) default NULL,
  `student_id` int(11) default NULL,
  `schoolid` int(11) NOT NULL,
  `exam_id` int(11) default NULL,
  `marks` decimal(7,2) default NULL,
  `grading_level_id` int(11) default NULL,
  `remarks` varchar(255) collate utf8_unicode_ci default NULL,
  `is_failed` tinyint(1) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_exam_scores_on_student_id_and_exam_id` (`student_id`,`exam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('32', '18', NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('33', '18', NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('34', '18', NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('35', '18', NULL, '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('36', '19', '12', '1', '1', '40.00', '0', '', '0', '2011-12-12 04:46:34', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('37', '19', '12', '1', '2', '20.00', '0', '', '1', '2011-12-12 04:47:06', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('38', '19', '12', '1', '3', '60.00', '0', '', '0', '2011-12-12 04:58:02', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('39', '19', '12', '1', '4', '20.00', '0', '', '1', '2011-12-12 04:58:25', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('40', '20', '13', '1', '1', '20.00', '0', '', '1', '2011-12-12 04:46:34', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('41', '20', '13', '1', '2', '20.00', '0', '', '1', '2011-12-12 04:47:06', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('42', '20', '13', '1', '3', '29.00', '0', '', '1', '2011-12-12 04:58:02', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('43', '20', '13', '1', '4', '35.00', '0', '', '0', '2011-12-12 04:58:26', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('44', '21', '19', '1', '14', '56.00', '0', '', '0', '2012-01-24 04:02:33', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('45', '21', '19', '1', '15', '96.00', '0', '', '0', '2012-01-24 04:02:42', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('46', '21', '19', '1', '16', '61.00', '0', '', '0', '2012-01-24 04:02:49', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('47', '21', '19', '1', '17', '75.00', '0', '', '0', '2012-01-24 04:02:57', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('48', '21', '19', '1', '18', '46.00', '0', '', '0', '2012-01-24 04:03:03', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('49', '22', '22', '4', '26', '52.00', '0', '', '0', '2012-02-29 02:11:52', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('50', '22', '22', '4', '27', '39.00', '0', '', '1', '2012-02-29 02:12:06', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('51', '22', '22', '4', '28', '69.00', '0', '', '0', '2012-02-29 02:14:39', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('52', '22', '22', '4', '29', '75.00', '0', '', '0', '2012-02-29 02:14:44', '2012-02-29 02:17:56');
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('53', '23', '27', '4', '30', '56.00', '0', '', '0', '2012-02-29 02:24:24', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('54', '23', '27', '4', '31', '49.00', '0', '', '0', '2012-02-29 02:24:38', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('55', '23', '27', '4', '32', '63.00', '0', '', '0', '2012-02-29 02:28:06', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('56', '23', '27', '4', '33', '46.00', '0', '', '0', '2012-02-29 02:28:26', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('57', '26', '2', '1', '14', '0.00', '0', '', '0', '2012-01-24 04:02:33', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('58', '26', '2', '1', '15', '0.00', '0', '', '0', '2012-01-24 04:02:42', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('59', '26', '2', '1', '16', '0.00', '0', '', '0', '2012-01-24 04:02:49', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('60', '26', '2', '1', '17', '0.00', '0', '', '0', '2012-01-24 04:02:57', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('61', '26', '2', '1', '18', '0.00', '0', '', '0', '2012-01-24 04:03:03', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('62', '26', '2', '1', '19', '89.00', '0', '', '0', '2012-02-29 05:13:06', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('63', '26', '2', '1', '20', '56.00', '0', '', '0', '2012-02-29 05:13:16', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('64', '26', '2', '1', '38', '50.00', '0', '', '0', '2012-02-29 05:08:58', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('65', '27', '14', '1', '14', '0.00', '0', '', '0', '2012-01-24 04:02:33', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('66', '27', '14', '1', '15', '0.00', '0', '', '0', '2012-01-24 04:02:42', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('67', '27', '14', '1', '16', '0.00', '0', '', '0', '2012-01-24 04:02:49', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('68', '27', '14', '1', '17', '0.00', '0', '', '0', '2012-01-24 04:02:57', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('69', '27', '14', '1', '18', '0.00', '0', '', '0', '2012-01-24 04:03:03', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('70', '27', '14', '1', '19', '0.00', '0', '', '0', '2012-02-29 05:13:06', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('71', '27', '14', '1', '20', '0.00', '0', '', '0', '2012-02-29 05:13:16', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('72', '27', '14', '1', '38', '70.00', '0', '', '0', '2012-02-29 05:08:58', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('73', '28', '17', '1', '14', '0.00', '0', '', '0', '2012-01-24 04:02:33', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('74', '28', '17', '1', '15', '0.00', '0', '', '0', '2012-01-24 04:02:42', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('75', '28', '17', '1', '16', '0.00', '0', '', '0', '2012-01-24 04:02:49', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('76', '28', '17', '1', '17', '0.00', '0', '', '0', '2012-01-24 04:02:57', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('77', '28', '17', '1', '18', '0.00', '0', '', '0', '2012-01-24 04:03:03', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('78', '28', '17', '1', '19', '0.00', '0', '', '0', '2012-02-29 05:13:06', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('79', '28', '17', '1', '20', '0.00', '0', '', '0', '2012-02-29 05:13:16', NULL);
insert into `archive_exam_scores` (`id`, `arc_student_id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('80', '28', '17', '1', '38', '80.00', '0', '', '0', '2012-02-29 05:08:58', NULL);

drop table if exists `archive_students`;
CREATE TABLE `archive_students` (
  `id` int(11) NOT NULL auto_increment,
  `studentid` int(11) NOT NULL,
  `schoolid` int(11) NOT NULL,
  `admission_no` varchar(255) collate utf8_unicode_ci default NULL,
  `passport_or_id` int(11) NOT NULL,
  `student_passport_no` varchar(200) collate utf8_unicode_ci NOT NULL,
  `guardian_id` int(10) NOT NULL,
  `class_roll_no` varchar(255) collate utf8_unicode_ci default NULL,
  `admission_date` date default NULL,
  `title` varchar(20) collate utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `middle_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `date_of_birth` date default NULL,
  `gender` varchar(255) collate utf8_unicode_ci default NULL,
  `blood_group` varchar(255) collate utf8_unicode_ci default NULL,
  `birth_place` varchar(255) collate utf8_unicode_ci default NULL,
  `nationality_id` int(11) default NULL,
  `language` varchar(255) collate utf8_unicode_ci default NULL,
  `religion` varchar(255) collate utf8_unicode_ci default NULL,
  `student_category_id` int(11) default NULL,
  `address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `city` varchar(255) collate utf8_unicode_ci default NULL,
  `state` varchar(255) collate utf8_unicode_ci default NULL,
  `pin_code` varchar(255) collate utf8_unicode_ci default NULL,
  `country_id` int(11) default NULL,
  `phone1` varchar(255) collate utf8_unicode_ci default NULL,
  `phone2` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `immediate_contact_id` int(11) default NULL,
  `is_sms_enabled` tinyint(1) default '1',
  `photo_file_name` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_content_type` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_data` mediumblob,
  `birth_certificate` varchar(300) collate utf8_unicode_ci NOT NULL,
  `status_description` varchar(255) collate utf8_unicode_ci default NULL,
  `is_active` tinyint(1) default '1',
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `has_paid_fees` tinyint(1) default '0',
  `photo_file_size` int(11) default NULL,
  `user_id` int(11) default NULL,
  `student_illness` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id`),
  KEY `index_students_on_admission_no` (`admission_no`(10)),
  KEY `index_students_on_first_name_and_middle_name_and_last_name` (`first_name`(10),`middle_name`(10),`last_name`(10))
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `archive_students` (`id`, `studentid`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `guardian_id`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('18', '17', '1', '114108', '1', 'A2498', '0', '', '2011-12-09', 'Miss', 'Sabina', '', 'Khan', '7', '1995-08-10', NULL, NULL, NULL, '86', NULL, 'Islam', NULL, 'main, f21', NULL, NULL, NULL, NULL, NULL, '43221323', NULL, NULL, NULL, '1', '17125.png', NULL, NULL, '17722.jpg', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `archive_students` (`id`, `studentid`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `guardian_id`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('19', '12', '1', '114101', '2', '0', '0', '', '2011-11-19', 'Mr', 'Vikram', '', 'Parekh', '5', '1995-06-23', NULL, NULL, NULL, '1', NULL, '1', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '12191.png', NULL, NULL, '12675.png', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `archive_students` (`id`, `studentid`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `guardian_id`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('20', '13', '1', '114103', '1', '0', '0', '', '2011-11-23', 'Mr', 'Pradeep', '', 'Gupta', '5', '1994-12-27', NULL, NULL, NULL, '1', NULL, 'Hindu', NULL, 'abc', NULL, NULL, NULL, NULL, NULL, '3121232', NULL, NULL, NULL, '1', '13537.jpg', NULL, NULL, '13116.png', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `archive_students` (`id`, `studentid`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `guardian_id`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('21', '19', '1', '5435', '1', 'ddgdd', '0', '', '2011-12-14', 'Miss', 'Jeniffer', '', 'Scott', '2', '2011-12-14', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `archive_students` (`id`, `studentid`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `guardian_id`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('22', '22', '4', 'V12001', '2', 'S6062', '16', '', '2012-00-15', 'Mr', 'Satish', '', 'Kumar', '9', '1996-08-14', NULL, NULL, NULL, '76', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `archive_students` (`id`, `studentid`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `guardian_id`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('23', '27', '4', 'V12001', '2', 'S6062', '16', NULL, '2012-00-15', 'Mr', 'Satish', '', 'Kumar', '12', '1996-08-14', NULL, NULL, NULL, '76', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `archive_students` (`id`, `studentid`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `guardian_id`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('24', '30', '4', 'vb512', '1', 'FL133', '20', '', '2012-03-03', 'Mr', 'Yash', '', 'Paul', '9', '1996-07-09', NULL, NULL, NULL, '31', NULL, '1', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `archive_students` (`id`, `studentid`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `guardian_id`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('25', '31', '4', 'vb512', '1', 'FL133', '20', NULL, '2012-03-03', 'Mr', 'Yash', '', 'Paul', '12', '1996-07-09', NULL, NULL, NULL, '31', NULL, '1', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `archive_students` (`id`, `studentid`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `guardian_id`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('26', '2', '1', 'V12001', '1', '0', '1', '', '2011-11-04', 'Mr', 'Kamlesh', '', 'Singh', '2', '2011-11-04', NULL, NULL, NULL, '1', NULL, '1', NULL, 'chouhano ki dhani', NULL, NULL, NULL, NULL, NULL, 'ger', NULL, NULL, NULL, '1', '2250.jpg', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `archive_students` (`id`, `studentid`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `guardian_id`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('27', '14', '1', '1000201', '1', '0', '0', '', '2011-11-25', 'Mr', 'Parvez', '', 'Khan', '2', '1999-08-24', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '14806.png', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `archive_students` (`id`, `studentid`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `guardian_id`, `class_roll_no`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('28', '17', '1', '114101', '2', '0', '0', NULL, '2011-11-19', 'Mr', 'Vikram', '', 'Parekh', '2', '1995-06-23', NULL, NULL, NULL, '1', NULL, '1', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '12191.png', NULL, NULL, '12675.png', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);

drop table if exists `attendances`;
CREATE TABLE `attendances` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `schoolid` int(11) NOT NULL default '0',
  `period_table_entry_id` int(11) default NULL,
  `forenoon` tinyint(1) default '0',
  `afternoon` tinyint(1) default '0',
  `reason` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('2', '6', '1', '11', '0', '1', 'not well');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('4', '8', '1', '43', '1', '0', 'fever');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('5', '8', '1', '49', '1', '1', 'went early');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('6', '3', '1', '51', '1', '1', 'abc');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('7', '5', '1', '50', '0', '1', 'pqr');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('8', '8', '1', '42', '1', '1', 'm,nm,');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('9', '16', '1', '594', '1', '1', 'bvnbvn');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('10', '16', '1', '367', '1', '1', 'mkm');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('11', '16', '1', '377', '1', '0', 'some reason');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('23', '29', '4', '1706', '1', '1', 'Out of Town');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('24', '32', '4', '1706', '1', '1', 'Out of Town');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('25', '32', '4', '1707', '1', '1', 'Out of Town');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('26', '28', '4', '1724', '1', '0', 'Late');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('27', '28', '4', '1730', '1', '1', 'fever');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('28', '28', '4', '1909', '0', '1', 'Other Exam');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('29', '32', '4', '1728', '1', '1', 'bnsdn');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('30', '32', '4', '1736', '1', '0', 'asdghasf');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('31', '32', '4', '1760', '1', '1', 'asgasg');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('32', '32', '4', '1781', '1', '1', 'sfggg');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('33', '32', '4', '1778', '1', '1', 'asdgfasg');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('34', '36', '4', '891', '1', '1', 'Genuine reason');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('35', '36', '4', '914', '0', '1', 'Half Day');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('36', '36', '4', '906', '1', '1', 'Function');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('37', '36', '4', '803', '1', '0', 'asdf');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('38', '36', '4', '783', '1', '0', 'sdf');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('39', '36', '4', '792', '0', '1', 'tjrt');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('40', '36', '4', '793', '1', '1', 'teyjet');
insert into `attendances` (`id`, `student_id`, `schoolid`, `period_table_entry_id`, `forenoon`, `afternoon`, `reason`) values ('41', '24', '1', '121', '1', '0', 'aaa');

drop table if exists `batch_events`;
CREATE TABLE `batch_events` (
  `id` int(11) NOT NULL auto_increment,
  `event_id` int(11) default NULL,
  `batch_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_batch_events_on_batch_id` (`batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `batch_events` (`id`, `event_id`, `batch_id`, `created_at`, `updated_at`) values ('1', '9', '5', '2011-11-29 12:37:00', NULL);
insert into `batch_events` (`id`, `event_id`, `batch_id`, `created_at`, `updated_at`) values ('2', '11', '11', '2012-03-05 02:27:03', NULL);
insert into `batch_events` (`id`, `event_id`, `batch_id`, `created_at`, `updated_at`) values ('3', '11', '7', '2012-03-05 02:27:03', NULL);
insert into `batch_events` (`id`, `event_id`, `batch_id`, `created_at`, `updated_at`) values ('4', '11', '10', '2012-03-05 02:27:03', NULL);
insert into `batch_events` (`id`, `event_id`, `batch_id`, `created_at`, `updated_at`) values ('5', '11', '2', '2012-03-05 02:27:03', NULL);
insert into `batch_events` (`id`, `event_id`, `batch_id`, `created_at`, `updated_at`) values ('6', '11', '6', '2012-03-05 02:27:03', NULL);
insert into `batch_events` (`id`, `event_id`, `batch_id`, `created_at`, `updated_at`) values ('7', '11', '9', '2012-03-05 02:27:03', NULL);
insert into `batch_events` (`id`, `event_id`, `batch_id`, `created_at`, `updated_at`) values ('8', '11', '4', '2012-03-05 02:27:03', NULL);
insert into `batch_events` (`id`, `event_id`, `batch_id`, `created_at`, `updated_at`) values ('9', '12', '11', '2012-03-13 08:24:32', NULL);
insert into `batch_events` (`id`, `event_id`, `batch_id`, `created_at`, `updated_at`) values ('10', '12', '7', '2012-03-13 08:24:32', NULL);
insert into `batch_events` (`id`, `event_id`, `batch_id`, `created_at`, `updated_at`) values ('11', '13', '11', '2012-03-13 08:24:39', NULL);
insert into `batch_events` (`id`, `event_id`, `batch_id`, `created_at`, `updated_at`) values ('12', '13', '7', '2012-03-13 08:24:39', NULL);

drop table if exists `batches`;
CREATE TABLE `batches` (
  `id` int(11) NOT NULL auto_increment,
  `schoolid` int(11) default NULL,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `grade_id` int(11) default NULL,
  `start_date` datetime default NULL,
  `sec_sem_start_date` datetime NOT NULL,
  `end_date` datetime default NULL,
  `is_active` tinyint(1) default '1',
  `is_deleted` tinyint(1) default '0',
  `employee_id` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_batches_on_is_deleted_and_is_active` (`is_deleted`,`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `sec_sem_start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('2', '1', '8A', '1', '2011-01-11 00:00:00', '2012-00-23 00:00:00', '2012-11-28 00:00:00', '1', '0', '3');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `sec_sem_start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('4', '1', 'C', '2', '2011-11-09 00:00:00', '0000-00-00 00:00:00', '2012-11-09 00:00:00', '1', '0', '3');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `sec_sem_start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('5', '1', 'A', '2', '2011-11-15 00:00:00', '0000-00-00 00:00:00', '2011-12-14 00:00:00', '1', '0', '2');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `sec_sem_start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('6', '2', '9A', '3', '2011-11-15 00:00:00', '0000-00-00 00:00:00', '2012-10-30 00:00:00', '1', '0', '6');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `sec_sem_start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('7', '1', '12AA', '4', '2011-11-15 00:00:00', '2012-02-28 00:00:00', '2012-10-25 00:00:00', '1', '0', '0');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `sec_sem_start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('8', '1', '12B', '4', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '0', '0');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `sec_sem_start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('9', '4', '9A', '5', '2011-07-04 00:00:00', '2012-03-12 00:00:00', '2012-06-30 00:00:00', '1', '0', '12');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `sec_sem_start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('10', '6', '2A', '6', '2012-01-02 00:00:00', '2012-07-01 00:00:00', '2012-12-30 00:00:00', '1', '0', '10');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `sec_sem_start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('11', '1', '10B', '7', '2012-01-10 00:00:00', '2012-07-02 00:00:00', '2012-12-26 00:00:00', '1', '0', '7');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `sec_sem_start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('12', '4', '10A', '8', '2012-07-09 00:00:00', '2013-01-02 00:00:00', '2013-06-22 00:00:00', '1', '0', '0');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `sec_sem_start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('13', '4', '11A', '9', '2013-07-22 00:00:00', '2014-01-20 00:00:00', '2014-05-30 00:00:00', '1', '0', '0');
insert into `batches` (`id`, `schoolid`, `name`, `grade_id`, `start_date`, `sec_sem_start_date`, `end_date`, `is_active`, `is_deleted`, `employee_id`) values ('14', '4', '11 D', '9', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '0000-00-00 00:00:00', '1', '0', '13');

drop table if exists `batches_template`;
CREATE TABLE `batches_template` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `class_id` int(11) default NULL,
  `start_date` datetime default NULL,
  `end_date` datetime default NULL,
  `is_active` tinyint(1) default '1',
  `is_deleted` tinyint(1) default '0',
  `employee_id` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_batches_on_is_deleted_and_is_active` (`is_deleted`,`is_active`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

drop table if exists `class_timings`;
CREATE TABLE `class_timings` (
  `id` int(11) NOT NULL auto_increment,
  `batch_id` int(11) default NULL,
  `schoolid` int(11) NOT NULL,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `start_time` time default NULL,
  `end_time` time default NULL,
  `is_break` tinyint(1) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_class_timings_on_batch_id_and_start_time_and_end_time` (`batch_id`,`start_time`,`end_time`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('14', '5', '1', 'First Period', '09:30:00', '10:30:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('15', '5', '1', 'Second Period', '10:30:00', '11:30:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('16', '5', '1', 'Third Period', '11:30:00', '12:30:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('17', '7', '1', 'First Period', '09:00:00', '09:30:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('18', '7', '1', 'break', '09:30:00', '10:10:00', '1');
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('19', '7', '1', 'Second Period', '10:00:00', '10:30:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('21', '0', '1', 'Third Period', '10:30:00', '11:00:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('22', '4', '1', 'First Period', '09:00:00', '10:00:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('23', '4', '1', 'Second Period', '10:00:00', '11:00:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('24', '9', '4', 'First Period', '09:00:00', '10:30:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('25', '9', '4', 'Second Period', '11:00:00', '12:30:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('26', '9', '4', 'Third Period', '12:30:00', '01:30:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('27', '2', '1', 'First', '05:00:00', '05:30:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('28', '2', '1', 'Second', '05:30:00', '06:00:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('29', '10', '6', 'First Period', '09:00:00', '09:30:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('30', '10', '6', 'Second Period', '09:30:00', '10:00:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('31', '10', '6', 'Third Period', '10:30:00', '11:00:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('33', '12', '4', 'Second Period', '09:15:00', '10:15:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('34', '12', '4', 'Third Period', '10:30:00', '11:00:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('35', '12', '4', 'Fourth Period', '11:00:00', '12:00:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('36', '13', '4', 'First Period', '11:00:00', '12:00:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('37', '13', '4', 'Second Period', '12:00:00', '13:00:00', NULL);
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('38', '13', '4', 'Third Period', '13:00:00', '13:30:00', '1');
insert into `class_timings` (`id`, `batch_id`, `schoolid`, `name`, `start_time`, `end_time`, `is_break`) values ('39', '13', '4', 'Fourth Period', '13:30:00', '14:30:00', NULL);

drop table if exists `countries`;
CREATE TABLE `countries` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=196 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `countries` (`id`, `name`) values ('1', 'Afghanistan');
insert into `countries` (`id`, `name`) values ('2', 'Albania');
insert into `countries` (`id`, `name`) values ('3', 'Algeria');
insert into `countries` (`id`, `name`) values ('4', 'Andorra');
insert into `countries` (`id`, `name`) values ('5', 'Angola');
insert into `countries` (`id`, `name`) values ('6', 'Antigua & Deps');
insert into `countries` (`id`, `name`) values ('7', 'Argentina');
insert into `countries` (`id`, `name`) values ('8', 'Armenia');
insert into `countries` (`id`, `name`) values ('9', 'Australia');
insert into `countries` (`id`, `name`) values ('10', 'Austria');
insert into `countries` (`id`, `name`) values ('11', 'Azerbaijan');
insert into `countries` (`id`, `name`) values ('12', 'Bahamas');
insert into `countries` (`id`, `name`) values ('13', 'Bahrain');
insert into `countries` (`id`, `name`) values ('14', 'Bangladesh');
insert into `countries` (`id`, `name`) values ('15', 'Barbados');
insert into `countries` (`id`, `name`) values ('16', 'Belarus');
insert into `countries` (`id`, `name`) values ('17', 'Belgium');
insert into `countries` (`id`, `name`) values ('18', 'Belize');
insert into `countries` (`id`, `name`) values ('19', 'Benin');
insert into `countries` (`id`, `name`) values ('20', 'Bhutan');
insert into `countries` (`id`, `name`) values ('21', 'Bolivia');
insert into `countries` (`id`, `name`) values ('22', 'Bosnia Herzegovina');
insert into `countries` (`id`, `name`) values ('23', 'Botswana');
insert into `countries` (`id`, `name`) values ('24', 'Brazil');
insert into `countries` (`id`, `name`) values ('25', 'Brunei');
insert into `countries` (`id`, `name`) values ('26', 'Bulgaria');
insert into `countries` (`id`, `name`) values ('27', 'Burkina');
insert into `countries` (`id`, `name`) values ('28', 'Burundi');
insert into `countries` (`id`, `name`) values ('29', 'Cambodia');
insert into `countries` (`id`, `name`) values ('30', 'Cameroon');
insert into `countries` (`id`, `name`) values ('31', 'Canada');
insert into `countries` (`id`, `name`) values ('32', 'Cape Verde');
insert into `countries` (`id`, `name`) values ('33', 'Central African Rep');
insert into `countries` (`id`, `name`) values ('34', 'Chad');
insert into `countries` (`id`, `name`) values ('35', 'Chile');
insert into `countries` (`id`, `name`) values ('36', 'China');
insert into `countries` (`id`, `name`) values ('37', 'Colombia');
insert into `countries` (`id`, `name`) values ('38', 'Comoros');
insert into `countries` (`id`, `name`) values ('39', 'Congo');
insert into `countries` (`id`, `name`) values ('40', 'Congo {Democratic Rep}');
insert into `countries` (`id`, `name`) values ('41', 'Costa Rica');
insert into `countries` (`id`, `name`) values ('42', 'Croatia');
insert into `countries` (`id`, `name`) values ('43', 'Cuba');
insert into `countries` (`id`, `name`) values ('44', 'Cyprus');
insert into `countries` (`id`, `name`) values ('45', 'Czech Republic');
insert into `countries` (`id`, `name`) values ('46', 'Denmark');
insert into `countries` (`id`, `name`) values ('47', 'Djibouti');
insert into `countries` (`id`, `name`) values ('48', 'Dominica');
insert into `countries` (`id`, `name`) values ('49', 'Dominican Republic');
insert into `countries` (`id`, `name`) values ('50', 'East Timor');
insert into `countries` (`id`, `name`) values ('51', 'Ecuador');
insert into `countries` (`id`, `name`) values ('52', 'Egypt');
insert into `countries` (`id`, `name`) values ('53', 'El Salvador');
insert into `countries` (`id`, `name`) values ('54', 'Equatorial Guinea');
insert into `countries` (`id`, `name`) values ('55', 'Eritrea');
insert into `countries` (`id`, `name`) values ('56', 'Estonia');
insert into `countries` (`id`, `name`) values ('57', 'Ethiopia');
insert into `countries` (`id`, `name`) values ('58', 'Fiji');
insert into `countries` (`id`, `name`) values ('59', 'Finland');
insert into `countries` (`id`, `name`) values ('60', 'France');
insert into `countries` (`id`, `name`) values ('61', 'Gabon');
insert into `countries` (`id`, `name`) values ('62', 'Gambia');
insert into `countries` (`id`, `name`) values ('63', 'Georgia');
insert into `countries` (`id`, `name`) values ('64', 'Germany');
insert into `countries` (`id`, `name`) values ('65', 'Ghana');
insert into `countries` (`id`, `name`) values ('66', 'Greece');
insert into `countries` (`id`, `name`) values ('67', 'Grenada');
insert into `countries` (`id`, `name`) values ('68', 'Guatemala');
insert into `countries` (`id`, `name`) values ('69', 'Guinea');
insert into `countries` (`id`, `name`) values ('70', 'Guinea-Bissau');
insert into `countries` (`id`, `name`) values ('71', 'Guyana');
insert into `countries` (`id`, `name`) values ('72', 'Haiti');
insert into `countries` (`id`, `name`) values ('73', 'Honduras');
insert into `countries` (`id`, `name`) values ('74', 'Hungary');
insert into `countries` (`id`, `name`) values ('75', 'Iceland');
insert into `countries` (`id`, `name`) values ('76', 'India');
insert into `countries` (`id`, `name`) values ('77', 'Indonesia');
insert into `countries` (`id`, `name`) values ('78', 'Iran');
insert into `countries` (`id`, `name`) values ('79', 'Iraq');
insert into `countries` (`id`, `name`) values ('80', 'Ireland {Republic}');
insert into `countries` (`id`, `name`) values ('81', 'Israel');
insert into `countries` (`id`, `name`) values ('82', 'Italy');
insert into `countries` (`id`, `name`) values ('83', 'Ivory Coast');
insert into `countries` (`id`, `name`) values ('84', 'Jamaica');
insert into `countries` (`id`, `name`) values ('85', 'Japan');
insert into `countries` (`id`, `name`) values ('86', 'Jordan');
insert into `countries` (`id`, `name`) values ('87', 'Kazakhstan');
insert into `countries` (`id`, `name`) values ('88', 'Kenya');
insert into `countries` (`id`, `name`) values ('89', 'Kiribati');
insert into `countries` (`id`, `name`) values ('90', 'Korea North');
insert into `countries` (`id`, `name`) values ('91', 'Korea South');
insert into `countries` (`id`, `name`) values ('92', 'Kosovo');
insert into `countries` (`id`, `name`) values ('93', 'Kuwait');
insert into `countries` (`id`, `name`) values ('94', 'Kyrgyzstan');
insert into `countries` (`id`, `name`) values ('95', 'Laos');
insert into `countries` (`id`, `name`) values ('96', 'Latvia');
insert into `countries` (`id`, `name`) values ('97', 'Lebanon');
insert into `countries` (`id`, `name`) values ('98', 'Lesotho');
insert into `countries` (`id`, `name`) values ('99', 'Liberia');
insert into `countries` (`id`, `name`) values ('100', 'Libya');
insert into `countries` (`id`, `name`) values ('101', 'Liechtenstein');
insert into `countries` (`id`, `name`) values ('102', 'Lithuania');
insert into `countries` (`id`, `name`) values ('103', 'Luxembourg');
insert into `countries` (`id`, `name`) values ('104', 'Macedonia');
insert into `countries` (`id`, `name`) values ('105', 'Madagascar');
insert into `countries` (`id`, `name`) values ('106', 'Malawi');
insert into `countries` (`id`, `name`) values ('107', 'Malaysia');
insert into `countries` (`id`, `name`) values ('108', 'Maldives');
insert into `countries` (`id`, `name`) values ('109', 'Mali');
insert into `countries` (`id`, `name`) values ('110', 'Malta');
insert into `countries` (`id`, `name`) values ('111', 'Montenegro');
insert into `countries` (`id`, `name`) values ('112', 'Marshall Islands');
insert into `countries` (`id`, `name`) values ('113', 'Mauritania');
insert into `countries` (`id`, `name`) values ('114', 'Mauritius');
insert into `countries` (`id`, `name`) values ('115', 'Mexico');
insert into `countries` (`id`, `name`) values ('116', 'Micronesia');
insert into `countries` (`id`, `name`) values ('117', 'Moldova');
insert into `countries` (`id`, `name`) values ('118', 'Monaco');
insert into `countries` (`id`, `name`) values ('119', 'Mongolia');
insert into `countries` (`id`, `name`) values ('120', 'Morocco');
insert into `countries` (`id`, `name`) values ('121', 'Mozambique');
insert into `countries` (`id`, `name`) values ('122', 'Myanmar, {Burma}');
insert into `countries` (`id`, `name`) values ('123', 'Namibia');
insert into `countries` (`id`, `name`) values ('124', 'Nauru');
insert into `countries` (`id`, `name`) values ('125', 'Nepal');
insert into `countries` (`id`, `name`) values ('126', 'Netherlands');
insert into `countries` (`id`, `name`) values ('127', 'New Zealand');
insert into `countries` (`id`, `name`) values ('128', 'Nicaragua');
insert into `countries` (`id`, `name`) values ('129', 'Niger');
insert into `countries` (`id`, `name`) values ('130', 'Nigeria');
insert into `countries` (`id`, `name`) values ('131', 'Norway');
insert into `countries` (`id`, `name`) values ('132', 'Oman');
insert into `countries` (`id`, `name`) values ('133', 'Pakistan');
insert into `countries` (`id`, `name`) values ('134', 'Palau');
insert into `countries` (`id`, `name`) values ('135', 'Panama');
insert into `countries` (`id`, `name`) values ('136', 'Papua New Guinea');
insert into `countries` (`id`, `name`) values ('137', 'Paraguay');
insert into `countries` (`id`, `name`) values ('138', 'Peru');
insert into `countries` (`id`, `name`) values ('139', 'Philippines');
insert into `countries` (`id`, `name`) values ('140', 'Poland');
insert into `countries` (`id`, `name`) values ('141', 'Portugal');
insert into `countries` (`id`, `name`) values ('142', 'Qatar');
insert into `countries` (`id`, `name`) values ('143', 'Romania');
insert into `countries` (`id`, `name`) values ('144', 'Russian Federation');
insert into `countries` (`id`, `name`) values ('145', 'Rwanda');
insert into `countries` (`id`, `name`) values ('146', 'St Kitts & Nevis');
insert into `countries` (`id`, `name`) values ('147', 'St Lucia');
insert into `countries` (`id`, `name`) values ('148', 'Saint Vincent & the Grenadines');
insert into `countries` (`id`, `name`) values ('149', 'Samoa');
insert into `countries` (`id`, `name`) values ('150', 'San Marino');
insert into `countries` (`id`, `name`) values ('151', 'Sao Tome & Principe');
insert into `countries` (`id`, `name`) values ('152', 'Saudi Arabia');
insert into `countries` (`id`, `name`) values ('153', 'Senegal');
insert into `countries` (`id`, `name`) values ('154', 'Serbia');
insert into `countries` (`id`, `name`) values ('155', 'Seychelles');
insert into `countries` (`id`, `name`) values ('156', 'Sierra Leone');
insert into `countries` (`id`, `name`) values ('157', 'Singapore');
insert into `countries` (`id`, `name`) values ('158', 'Slovakia');
insert into `countries` (`id`, `name`) values ('159', 'Slovenia');
insert into `countries` (`id`, `name`) values ('160', 'Solomon Islands');
insert into `countries` (`id`, `name`) values ('161', 'Somalia');
insert into `countries` (`id`, `name`) values ('162', 'South Africa');
insert into `countries` (`id`, `name`) values ('163', 'Spain');
insert into `countries` (`id`, `name`) values ('164', 'Sri Lanka');
insert into `countries` (`id`, `name`) values ('165', 'Sudan');
insert into `countries` (`id`, `name`) values ('166', 'Suriname');
insert into `countries` (`id`, `name`) values ('167', 'Swaziland');
insert into `countries` (`id`, `name`) values ('168', 'Sweden');
insert into `countries` (`id`, `name`) values ('169', 'Switzerland');
insert into `countries` (`id`, `name`) values ('170', 'Syria');
insert into `countries` (`id`, `name`) values ('171', 'Taiwan');
insert into `countries` (`id`, `name`) values ('172', 'Tajikistan');
insert into `countries` (`id`, `name`) values ('173', 'Tanzania');
insert into `countries` (`id`, `name`) values ('174', 'Thailand');
insert into `countries` (`id`, `name`) values ('175', 'Togo');
insert into `countries` (`id`, `name`) values ('176', 'Tonga');
insert into `countries` (`id`, `name`) values ('177', 'Trinidad & Tobago');
insert into `countries` (`id`, `name`) values ('178', 'Tunisia');
insert into `countries` (`id`, `name`) values ('179', 'Turkey');
insert into `countries` (`id`, `name`) values ('180', 'Turkmenistan');
insert into `countries` (`id`, `name`) values ('181', 'Tuvalu');
insert into `countries` (`id`, `name`) values ('182', 'Uganda');
insert into `countries` (`id`, `name`) values ('183', 'Ukraine');
insert into `countries` (`id`, `name`) values ('184', 'United Arab Emirates');
insert into `countries` (`id`, `name`) values ('185', 'United Kingdom');
insert into `countries` (`id`, `name`) values ('186', 'United States');
insert into `countries` (`id`, `name`) values ('187', 'Uruguay');
insert into `countries` (`id`, `name`) values ('188', 'Uzbekistan');
insert into `countries` (`id`, `name`) values ('189', 'Vanuatu');
insert into `countries` (`id`, `name`) values ('190', 'Vatican City');
insert into `countries` (`id`, `name`) values ('191', 'Venezuea');
insert into `countries` (`id`, `name`) values ('192', 'Vietnam');
insert into `countries` (`id`, `name`) values ('193', 'Yemen');
insert into `countries` (`id`, `name`) values ('194', 'Zambia');
insert into `countries` (`id`, `name`) values ('195', 'Zimbabwe');

drop table if exists `employee_categories`;
CREATE TABLE `employee_categories` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `prefix` varchar(255) collate utf8_unicode_ci default NULL,
  `schoolid` int(11) NOT NULL default '0',
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `employee_categories` (`id`, `name`, `prefix`, `schoolid`, `status`) values ('1', 'First Level', 'F', '1', '1');
insert into `employee_categories` (`id`, `name`, `prefix`, `schoolid`, `status`) values ('2', 'Second Level', 'S', '1', '1');
insert into `employee_categories` (`id`, `name`, `prefix`, `schoolid`, `status`) values ('3', 'Third Level', 'T', '1', '1');
insert into `employee_categories` (`id`, `name`, `prefix`, `schoolid`, `status`) values ('4', 'General', 'gen', '1', '0');
insert into `employee_categories` (`id`, `name`, `prefix`, `schoolid`, `status`) values ('5', 'Teaching', 'teach', '2', '1');
insert into `employee_categories` (`id`, `name`, `prefix`, `schoolid`, `status`) values ('6', 'Senior Level', 'SL', '4', '1');
insert into `employee_categories` (`id`, `name`, `prefix`, `schoolid`, `status`) values ('7', 'Primary Level', 'PL', '4', '1');
insert into `employee_categories` (`id`, `name`, `prefix`, `schoolid`, `status`) values ('8', 'Junior Level', 'JL', '4', '1');

drop table if exists `employee_departments`;
CREATE TABLE `employee_departments` (
  `id` int(11) NOT NULL auto_increment,
  `code` varchar(255) collate utf8_unicode_ci default NULL,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `schoolid` int(11) NOT NULL default '0',
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('1', 'D001', 'Science', '1', '1');
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('2', 'D04', 'Botany', '1', '0');
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('3', 'D002', 'Depatment of Mathematics', '1', '1');
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('4', 'D03', 'Computer Science', '1', '1');
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('5', '101', 'Department of Science', '2', '1');
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('6', '002123', 'Primary Teacher', '6', '1');
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('7', 'V8111', 'Mathematics', '4', '1');
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('8', 'v02', 'Literature', '4', '1');
insert into `employee_departments` (`id`, `code`, `name`, `schoolid`, `status`) values ('9', 'v06', 'Science', '4', '1');

drop table if exists `employee_positions`;
CREATE TABLE `employee_positions` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `employee_category_id` int(11) default NULL,
  `schoolid` int(11) NOT NULL default '0',
  `status` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `employee_positions` (`id`, `name`, `employee_category_id`, `schoolid`, `status`) values ('1', 'Lab Assistant', '3', '1', '1');
insert into `employee_positions` (`id`, `name`, `employee_category_id`, `schoolid`, `status`) values ('2', 'Accountant', '2', '1', '0');
insert into `employee_positions` (`id`, `name`, `employee_category_id`, `schoolid`, `status`) values ('3', 'First', '5', '2', '1');
insert into `employee_positions` (`id`, `name`, `employee_category_id`, `schoolid`, `status`) values ('4', 'Second', '5', '2', '1');

drop table if exists `employees`;
CREATE TABLE `employees` (
  `id` int(11) NOT NULL auto_increment,
  `schoolid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `employee_category_id` int(11) default NULL,
  `employee_number` varchar(255) collate utf8_unicode_ci default NULL,
  `joining_date` date default NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `gender` tinyint(1) default NULL,
  `job_title` varchar(255) collate utf8_unicode_ci default NULL,
  `employee_position_id` int(11) default NULL,
  `employee_department_id` int(11) default NULL,
  `reporting_manager_id` int(11) default NULL,
  `employee_grade_id` int(11) default NULL,
  `qualification` varchar(255) collate utf8_unicode_ci default NULL,
  `experience_detail` text collate utf8_unicode_ci,
  `experience_year` int(11) default NULL,
  `experience_month` int(11) default NULL,
  `status` tinyint(1) default NULL,
  `status_description` varchar(255) collate utf8_unicode_ci default NULL,
  `date_of_birth` date default NULL,
  `marital_status` varchar(255) collate utf8_unicode_ci default NULL,
  `children_count` int(11) default NULL,
  `father_name` varchar(255) collate utf8_unicode_ci default NULL,
  `mother_name` varchar(255) collate utf8_unicode_ci default NULL,
  `husband_name` varchar(255) collate utf8_unicode_ci default NULL,
  `blood_group` varchar(255) collate utf8_unicode_ci default NULL,
  `nationality_id` int(11) default NULL,
  `home_address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `home_address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `home_city` varchar(255) collate utf8_unicode_ci default NULL,
  `home_state` varchar(255) collate utf8_unicode_ci default NULL,
  `home_country_id` int(11) default NULL,
  `home_pin_code` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `office_city` varchar(255) collate utf8_unicode_ci default NULL,
  `office_state` varchar(255) collate utf8_unicode_ci default NULL,
  `office_country_id` int(11) default NULL,
  `office_pin_code` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone2` varchar(255) collate utf8_unicode_ci default NULL,
  `mobile_phone` varchar(255) collate utf8_unicode_ci default NULL,
  `home_phone` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `fax` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_file_name` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_content_type` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_data` mediumblob,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `photo_file_size` int(11) default NULL,
  `user_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_employees_on_employee_number` (`employee_number`(10))
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `employees` (`id`, `schoolid`, `userid`, `employee_category_id`, `employee_number`, `joining_date`, `first_name`, `last_name`, `gender`, `job_title`, `employee_position_id`, `employee_department_id`, `reporting_manager_id`, `employee_grade_id`, `qualification`, `experience_detail`, `experience_year`, `experience_month`, `status`, `status_description`, `date_of_birth`, `marital_status`, `children_count`, `father_name`, `mother_name`, `husband_name`, `blood_group`, `nationality_id`, `home_address_line1`, `home_address_line2`, `home_city`, `home_state`, `home_country_id`, `home_pin_code`, `office_address_line1`, `office_address_line2`, `office_city`, `office_state`, `office_country_id`, `office_pin_code`, `office_phone1`, `office_phone2`, `mobile_phone`, `home_phone`, `email`, `fax`, `photo_file_name`, `photo_content_type`, `photo_data`, `created_at`, `updated_at`, `photo_file_size`, `user_id`) values ('2', '1', '6', '1', '10041', '2011-11-09', 'Ashfaq', 'Khan', '0', NULL, '1', '4', NULL, NULL, '', '', '0', '0', '1', NULL, '1984-06-14', 'Single', '0', '', '', '', '1', '1', '', '', '', '', '1', '', '', '', '', '', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
insert into `employees` (`id`, `schoolid`, `userid`, `employee_category_id`, `employee_number`, `joining_date`, `first_name`, `last_name`, `gender`, `job_title`, `employee_position_id`, `employee_department_id`, `reporting_manager_id`, `employee_grade_id`, `qualification`, `experience_detail`, `experience_year`, `experience_month`, `status`, `status_description`, `date_of_birth`, `marital_status`, `children_count`, `father_name`, `mother_name`, `husband_name`, `blood_group`, `nationality_id`, `home_address_line1`, `home_address_line2`, `home_city`, `home_state`, `home_country_id`, `home_pin_code`, `office_address_line1`, `office_address_line2`, `office_city`, `office_state`, `office_country_id`, `office_pin_code`, `office_phone1`, `office_phone2`, `mobile_phone`, `home_phone`, `email`, `fax`, `photo_file_name`, `photo_content_type`, `photo_data`, `created_at`, `updated_at`, `photo_file_size`, `user_id`) values ('3', '1', '8', '2', '1102', '2011-11-15', 'Shailendra', 'Purohit', '0', NULL, '1', '1', NULL, NULL, '', '', '0', '0', '1', NULL, '1985-07-16', 'Married', '0', '', '', '', '1', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '3400.jpg', NULL, NULL, NULL, NULL, NULL, NULL);
insert into `employees` (`id`, `schoolid`, `userid`, `employee_category_id`, `employee_number`, `joining_date`, `first_name`, `last_name`, `gender`, `job_title`, `employee_position_id`, `employee_department_id`, `reporting_manager_id`, `employee_grade_id`, `qualification`, `experience_detail`, `experience_year`, `experience_month`, `status`, `status_description`, `date_of_birth`, `marital_status`, `children_count`, `father_name`, `mother_name`, `husband_name`, `blood_group`, `nationality_id`, `home_address_line1`, `home_address_line2`, `home_city`, `home_state`, `home_country_id`, `home_pin_code`, `office_address_line1`, `office_address_line2`, `office_city`, `office_state`, `office_country_id`, `office_pin_code`, `office_phone1`, `office_phone2`, `mobile_phone`, `home_phone`, `email`, `fax`, `photo_file_name`, `photo_content_type`, `photo_data`, `created_at`, `updated_at`, `photo_file_size`, `user_id`) values ('6', '2', '16', '5', '1105', '2011-11-17', 'Ajay', 'Sharma', '0', NULL, '3', '5', NULL, NULL, '', '', '0', '0', '1', NULL, '1987-00-24', 'Single', '0', '', '', '', '1', '1', '', '', '', '', '1', '', '', '', '', '', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
insert into `employees` (`id`, `schoolid`, `userid`, `employee_category_id`, `employee_number`, `joining_date`, `first_name`, `last_name`, `gender`, `job_title`, `employee_position_id`, `employee_department_id`, `reporting_manager_id`, `employee_grade_id`, `qualification`, `experience_detail`, `experience_year`, `experience_month`, `status`, `status_description`, `date_of_birth`, `marital_status`, `children_count`, `father_name`, `mother_name`, `husband_name`, `blood_group`, `nationality_id`, `home_address_line1`, `home_address_line2`, `home_city`, `home_state`, `home_country_id`, `home_pin_code`, `office_address_line1`, `office_address_line2`, `office_city`, `office_state`, `office_country_id`, `office_pin_code`, `office_phone1`, `office_phone2`, `mobile_phone`, `home_phone`, `email`, `fax`, `photo_file_name`, `photo_content_type`, `photo_data`, `created_at`, `updated_at`, `photo_file_size`, `user_id`) values ('7', '1', '25', '3', 'E221', '2011-12-08', 'Albert', 'Silvester', '0', NULL, '1', '3', NULL, NULL, 'MBA', '5 years', '5', '4', '1', NULL, '1981-05-19', 'Single', '0', 'James', '', '', '4', '1', 'A-56', 'Michele street', 'London', 'UK', '1', '55021', '', '', '', '', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
insert into `employees` (`id`, `schoolid`, `userid`, `employee_category_id`, `employee_number`, `joining_date`, `first_name`, `last_name`, `gender`, `job_title`, `employee_position_id`, `employee_department_id`, `reporting_manager_id`, `employee_grade_id`, `qualification`, `experience_detail`, `experience_year`, `experience_month`, `status`, `status_description`, `date_of_birth`, `marital_status`, `children_count`, `father_name`, `mother_name`, `husband_name`, `blood_group`, `nationality_id`, `home_address_line1`, `home_address_line2`, `home_city`, `home_state`, `home_country_id`, `home_pin_code`, `office_address_line1`, `office_address_line2`, `office_city`, `office_state`, `office_country_id`, `office_pin_code`, `office_phone1`, `office_phone2`, `mobile_phone`, `home_phone`, `email`, `fax`, `photo_file_name`, `photo_content_type`, `photo_data`, `created_at`, `updated_at`, `photo_file_size`, `user_id`) values ('9', '1', '27', '1', 'ddfss', '2011-12-09', 'ds', ' ds', '0', NULL, '1', '1', NULL, NULL, '', '', '0', '0', '0', 'FGDFGDF', '2011-12-09', 'Single', '0', '', '', '', '1', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
insert into `employees` (`id`, `schoolid`, `userid`, `employee_category_id`, `employee_number`, `joining_date`, `first_name`, `last_name`, `gender`, `job_title`, `employee_position_id`, `employee_department_id`, `reporting_manager_id`, `employee_grade_id`, `qualification`, `experience_detail`, `experience_year`, `experience_month`, `status`, `status_description`, `date_of_birth`, `marital_status`, `children_count`, `father_name`, `mother_name`, `husband_name`, `blood_group`, `nationality_id`, `home_address_line1`, `home_address_line2`, `home_city`, `home_state`, `home_country_id`, `home_pin_code`, `office_address_line1`, `office_address_line2`, `office_city`, `office_state`, `office_country_id`, `office_pin_code`, `office_phone1`, `office_phone2`, `mobile_phone`, `home_phone`, `email`, `fax`, `photo_file_name`, `photo_content_type`, `photo_data`, `created_at`, `updated_at`, `photo_file_size`, `user_id`) values ('10', '6', '33', '1', '01244', '2012-00-23', 'Hemendra', '', '0', NULL, '1', '6', NULL, NULL, '', '', '0', '0', '1', NULL, '2012-00-23', 'Single', '0', '', '', '', '1', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
insert into `employees` (`id`, `schoolid`, `userid`, `employee_category_id`, `employee_number`, `joining_date`, `first_name`, `last_name`, `gender`, `job_title`, `employee_position_id`, `employee_department_id`, `reporting_manager_id`, `employee_grade_id`, `qualification`, `experience_detail`, `experience_year`, `experience_month`, `status`, `status_description`, `date_of_birth`, `marital_status`, `children_count`, `father_name`, `mother_name`, `husband_name`, `blood_group`, `nationality_id`, `home_address_line1`, `home_address_line2`, `home_city`, `home_state`, `home_country_id`, `home_pin_code`, `office_address_line1`, `office_address_line2`, `office_city`, `office_state`, `office_country_id`, `office_pin_code`, `office_phone1`, `office_phone2`, `mobile_phone`, `home_phone`, `email`, `fax`, `photo_file_name`, `photo_content_type`, `photo_data`, `created_at`, `updated_at`, `photo_file_size`, `user_id`) values ('11', '6', '34', '1', '10023', '2012-00-23', 'Ashraf', '', '0', NULL, '1', '6', NULL, NULL, '', '', '0', '0', '1', NULL, '2012-00-23', 'Single', '0', '', '', '', '1', '1', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
insert into `employees` (`id`, `schoolid`, `userid`, `employee_category_id`, `employee_number`, `joining_date`, `first_name`, `last_name`, `gender`, `job_title`, `employee_position_id`, `employee_department_id`, `reporting_manager_id`, `employee_grade_id`, `qualification`, `experience_detail`, `experience_year`, `experience_month`, `status`, `status_description`, `date_of_birth`, `marital_status`, `children_count`, `father_name`, `mother_name`, `husband_name`, `blood_group`, `nationality_id`, `home_address_line1`, `home_address_line2`, `home_city`, `home_state`, `home_country_id`, `home_pin_code`, `office_address_line1`, `office_address_line2`, `office_city`, `office_state`, `office_country_id`, `office_pin_code`, `office_phone1`, `office_phone2`, `mobile_phone`, `home_phone`, `email`, `fax`, `photo_file_name`, `photo_content_type`, `photo_data`, `created_at`, `updated_at`, `photo_file_size`, `user_id`) values ('12', '4', '36', '6', 'VB501', '2012-02-28', 'Gajendra', 'Singh', '0', NULL, '1', '7', NULL, NULL, '', '', '0', '0', '1', NULL, '1983-08-12', 'Single', '0', '', '', '', '1', '1', 'banar road', 'jodhpur', 'jodhpur', 'rajasthan', '1', '', '', '', '', '', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
insert into `employees` (`id`, `schoolid`, `userid`, `employee_category_id`, `employee_number`, `joining_date`, `first_name`, `last_name`, `gender`, `job_title`, `employee_position_id`, `employee_department_id`, `reporting_manager_id`, `employee_grade_id`, `qualification`, `experience_detail`, `experience_year`, `experience_month`, `status`, `status_description`, `date_of_birth`, `marital_status`, `children_count`, `father_name`, `mother_name`, `husband_name`, `blood_group`, `nationality_id`, `home_address_line1`, `home_address_line2`, `home_city`, `home_state`, `home_country_id`, `home_pin_code`, `office_address_line1`, `office_address_line2`, `office_city`, `office_state`, `office_country_id`, `office_pin_code`, `office_phone1`, `office_phone2`, `mobile_phone`, `home_phone`, `email`, `fax`, `photo_file_name`, `photo_content_type`, `photo_data`, `created_at`, `updated_at`, `photo_file_size`, `user_id`) values ('13', '4', '42', '7', 'VE1231', '2012-03-09', 'Ravindra', 'Sharma', '0', NULL, '1', '8', NULL, NULL, '', '', '0', '0', '1', NULL, '1987-07-14', 'Single', '0', '', '', '', '1', '1', 'af', 'sdgfg', 'Jodhpur', 'Rajasthan', '1', '', '', '', '', '', '1', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

drop table if exists `employees_subjects`;
CREATE TABLE `employees_subjects` (
  `id` int(11) NOT NULL auto_increment,
  `employee_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  `schoolid` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `index_employees_subjects_on_subject_id` (`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('1', '1', '1', '0');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('3', '2', '4', '0');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('4', '2', '5', '0');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('5', '6', '14', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('6', '7', '22', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('7', '7', '28', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('8', '9', '30', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('9', '6', '29', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('10', '2', '29', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('11', '9', '33', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('12', '2', '31', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('13', '2', '32', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('14', '6', '34', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('16', '7', '31', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('17', '7', '34', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('18', '7', '2', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('19', '3', '1', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('20', '3', '28', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('21', '10', '36', '6');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('23', '3', '33', '1');
insert into `employees_subjects` (`id`, `employee_id`, `subject_id`, `schoolid`) values ('25', '13', '39', '4');

drop table if exists `events`;
CREATE TABLE `events` (
  `id` int(11) NOT NULL auto_increment,
  `schoolid` int(11) NOT NULL,
  `title` varchar(255) collate utf8_unicode_ci default NULL,
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  `start_date` datetime default NULL,
  `end_date` datetime default NULL,
  `is_common` tinyint(1) default '0',
  `is_holiday` tinyint(1) default '0',
  `is_exam` tinyint(1) default '0',
  `is_due` tinyint(1) default '0',
  `is_active` int(1) NOT NULL default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_events_on_is_common_and_is_holiday_and_is_exam` (`is_common`,`is_holiday`,`is_exam`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `events` (`id`, `schoolid`, `title`, `description`, `start_date`, `end_date`, `is_common`, `is_holiday`, `is_exam`, `is_due`, `is_active`, `created_at`, `updated_at`) values ('6', '1', 'dfgdf', 'dfgdfg', '2011-11-15 12:00:00', '2011-11-15 12:00:00', '0', '1', '0', '0', '0', '2011-11-22 10:09:35', NULL);
insert into `events` (`id`, `schoolid`, `title`, `description`, `start_date`, `end_date`, `is_common`, `is_holiday`, `is_exam`, `is_due`, `is_active`, `created_at`, `updated_at`) values ('7', '1', 'Last Working Day', 'last working day is a holiday', '2011-11-30 12:00:00', '2011-11-30 12:00:00', '1', '1', '0', '0', '1', '2011-11-17 12:47:57', NULL);
insert into `events` (`id`, `schoolid`, `title`, `description`, `start_date`, `end_date`, `is_common`, `is_holiday`, `is_exam`, `is_due`, `is_active`, `created_at`, `updated_at`) values ('8', '1', 'Occassion', 'Occassion Special wedding garments are often worn, and the ceremony is 
sometimes followed by a wedding reception. Music, poetry, prayers or readings from 
Scripturs or literature is also optionally incorporated into the ceremony.', '2011-11-18 12:00:00', '2011-11-18 12:00:00', '1', '1', '0', '0', '1', '2011-11-28 01:09:52', NULL);
insert into `events` (`id`, `schoolid`, `title`, `description`, `start_date`, `end_date`, `is_common`, `is_holiday`, `is_exam`, `is_due`, `is_active`, `created_at`, `updated_at`) values ('9', '2', 'event', 'Full MIME Support
supports MIME email messages, allowing users to receive attached pictures, multimedia content and
data contained in email messages. Users can compose email messages and attach files to outgoing
messages.
IMAP / IMAPs support
utilize', '2011-11-19 12:00:00', '2011-11-19 23:55:00', '0', '0', '0', '0', '1', '2011-11-29 12:36:51', NULL);
insert into `events` (`id`, `schoolid`, `title`, `description`, `start_date`, `end_date`, `is_common`, `is_holiday`, `is_exam`, `is_due`, `is_active`, `created_at`, `updated_at`) values ('10', '1', 'rr', 'afda', '2012-00-08 12:00:00', '2012-00-08 12:00:00', '0', '0', '0', '0', '0', '2012-02-16 02:44:03', NULL);
insert into `events` (`id`, `schoolid`, `title`, `description`, `start_date`, `end_date`, `is_common`, `is_holiday`, `is_exam`, `is_due`, `is_active`, `created_at`, `updated_at`) values ('11', '4', 'aass', 'adfaf', '2012-03-22 12:00:00', '2012-03-22 12:00:00', '0', '1', '0', '0', '1', '2012-03-05 02:26:43', NULL);
insert into `events` (`id`, `schoolid`, `title`, `description`, `start_date`, `end_date`, `is_common`, `is_holiday`, `is_exam`, `is_due`, `is_active`, `created_at`, `updated_at`) values ('12', '1', 'aaa', 'aaaadsfadf', '2012-03-13 08:23:00', '2012-03-13 08:23:00', '0', '1', '0', '0', '0', '2012-03-13 08:23:16', NULL);
insert into `events` (`id`, `schoolid`, `title`, `description`, `start_date`, `end_date`, `is_common`, `is_holiday`, `is_exam`, `is_due`, `is_active`, `created_at`, `updated_at`) values ('13', '1', 'asdfg', 'adehjt', '2012-03-05 12:00:00', '2012-03-05 12:00:00', '0', '1', '0', '0', '0', '2012-03-13 08:23:42', NULL);

drop table if exists `exam_groups`;
CREATE TABLE `exam_groups` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `schoolid` int(11) NOT NULL,
  `batch_id` int(11) default NULL,
  `exam_type` varchar(255) collate utf8_unicode_ci default NULL,
  `is_published` tinyint(1) default '0',
  `result_published` tinyint(1) default '0',
  `exam_date` date default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('1', 'First test', '1', '5', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('2', 'Second Test', '1', '5', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('4', 'Third Test', '1', '5', 'Marks', '0', '0', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('5', 'kmkm', '1', '4', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('6', 'Final', '1', '7', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('7', 'Major tests', '1', '2', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('8', 'Second', '1', '2', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('9', 'Weekly Test', '1', '4', 'Marks', '1', '0', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('10', 'First Test', '6', '10', 'Marks', '1', '0', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('11', 'First Term', '4', '9', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('12', 'Second Term', '4', '9', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('13', 'Quaterly Exam', '4', '12', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('14', 'Pre Board', '4', '12', 'Marks', '1', '0', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('15', 'First Sessional', '4', '13', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('16', 'Second Sessional', '4', '13', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('17', 'final', '1', '2', 'Marks', '1', '1', NULL);
insert into `exam_groups` (`id`, `name`, `schoolid`, `batch_id`, `exam_type`, `is_published`, `result_published`, `exam_date`) values ('18', 'First Exam', '1', '11', 'Marks', '1', '1', NULL);

drop table if exists `exam_scores`;
CREATE TABLE `exam_scores` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `schoolid` int(11) NOT NULL,
  `exam_id` int(11) default NULL,
  `marks` decimal(7,2) default NULL,
  `grading_level_id` int(11) default NULL,
  `remarks` varchar(255) collate utf8_unicode_ci default NULL,
  `is_failed` tinyint(1) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_exam_scores_on_student_id_and_exam_id` (`student_id`,`exam_id`)
) ENGINE=InnoDB AUTO_INCREMENT=111 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('1', '6', '1', '1', '50.00', '0', '', '0', '2011-12-12 04:46:34', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('4', '15', '1', '1', '80.00', '0', '', '0', '2011-12-12 04:46:34', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('5', '6', '1', '2', '50.00', '0', '', '0', '2011-12-12 04:47:06', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('8', '15', '1', '2', '70.00', '0', '', '0', '2011-12-12 04:47:06', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('9', '6', '1', '3', '50.00', '0', '', '0', '2011-12-12 04:58:02', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('12', '15', '1', '3', '80.00', '0', '', '0', '2011-12-12 04:58:02', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('13', '6', '1', '4', '40.00', '0', '', '0', '2011-12-12 04:58:25', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('16', '15', '1', '4', '65.00', '0', '', '0', '2011-12-12 04:58:26', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('17', '16', '1', '11', '45.00', '0', '', '0', '2012-01-24 11:08:09', '2012-01-24 11:08:16');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('18', '20', '1', '11', '56.00', '0', '', '0', '2012-01-24 11:08:09', '2012-01-24 11:08:16');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('19', '3', '1', '10', '56.00', '0', '', '0', '2012-01-24 02:36:21', '2012-01-24 03:00:34');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('20', '5', '1', '10', '75.00', '0', '', '0', '2012-01-24 02:36:21', '2012-01-24 03:00:34');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('21', '8', '1', '10', '86.00', '0', '', '0', '2012-01-24 02:36:21', '2012-01-24 03:00:34');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('22', '21', '1', '10', '95.00', '0', '', '0', '2012-01-24 02:36:21', '2012-01-24 03:00:34');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('24', '7', '1', '14', '0.00', '0', '', '0', '2012-01-24 04:02:33', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('27', '18', '1', '14', '0.00', '0', '', '0', '2012-01-24 04:02:33', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('30', '7', '1', '15', '0.00', '0', '', '0', '2012-01-24 04:02:42', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('33', '18', '1', '15', '0.00', '0', '', '0', '2012-01-24 04:02:42', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('36', '7', '1', '16', '0.00', '0', '', '0', '2012-01-24 04:02:49', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('39', '18', '1', '16', '0.00', '0', '', '0', '2012-01-24 04:02:49', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('42', '7', '1', '17', '0.00', '0', '', '0', '2012-01-24 04:02:57', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('45', '18', '1', '17', '0.00', '0', '', '0', '2012-01-24 04:02:57', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('48', '7', '1', '18', '0.00', '0', '', '0', '2012-01-24 04:03:03', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('51', '18', '1', '18', '0.00', '0', '', '0', '2012-01-24 04:03:03', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('53', '16', '1', '12', '65.00', '0', '', '0', '2012-01-24 04:27:42', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('54', '20', '1', '12', '43.00', '0', '', '0', '2012-01-24 04:27:43', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('55', '16', '1', '13', '85.00', '0', '', '0', '2012-01-24 04:27:55', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('56', '20', '1', '13', '45.00', '0', '', '0', '2012-01-24 04:27:55', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('65', '28', '4', '35', '82.00', '0', '', '0', '2012-02-29 02:37:46', '2012-03-07 09:02:20');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('66', '28', '4', '34', '76.00', '0', '', '0', '2012-02-29 02:37:58', '2012-03-07 09:02:07');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('67', '28', '4', '36', '60.00', '0', '', '0', '2012-02-29 02:38:19', '2012-03-07 09:03:05');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('68', '28', '4', '37', '59.00', '0', '', '0', '2012-02-29 02:38:36', '2012-03-07 09:03:17');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('70', '7', '1', '38', '60.00', '0', '', '0', '2012-02-29 05:08:58', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('73', '18', '1', '38', '90.00', '0', '', '0', '2012-02-29 05:08:58', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('75', '7', '1', '19', '0.00', '0', '', '0', '2012-02-29 05:13:06', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('78', '18', '1', '19', '0.00', '0', '', '0', '2012-02-29 05:13:06', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('80', '7', '1', '20', '0.00', '0', '', '0', '2012-02-29 05:13:16', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('83', '18', '1', '20', '0.00', '0', '', '0', '2012-02-29 05:13:16', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('84', '29', '4', '34', '63.00', '0', '', '0', '2012-03-07 09:02:07', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('85', '32', '4', '34', '89.00', '0', '', '0', '2012-03-07 09:02:07', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('86', '29', '4', '35', '64.00', '0', '', '0', '2012-03-07 09:02:20', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('87', '32', '4', '35', '90.00', '0', '', '0', '2012-03-07 09:02:20', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('88', '29', '4', '36', '82.00', '0', '', '0', '2012-03-07 09:03:06', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('89', '32', '4', '36', '61.00', '0', '', '0', '2012-03-07 09:03:06', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('90', '29', '4', '37', '57.00', '0', '', '0', '2012-03-07 09:03:17', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('91', '32', '4', '37', '56.00', '0', '', '0', '2012-03-07 09:03:17', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('92', '25', '1', '39', '69.00', '0', '', '0', '2012-03-07 10:53:16', '2012-03-07 11:33:31');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('93', '26', '1', '39', '45.00', '0', '', '0', '2012-03-07 10:53:16', '2012-03-07 11:33:31');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('94', '25', '1', '40', '82.00', '0', '', '0', '2012-03-07 10:54:34', '2012-03-07 11:33:47');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('95', '26', '1', '40', '93.00', '0', '', '0', '2012-03-07 10:54:34', '2012-03-07 11:33:47');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('96', '25', '1', '41', '65.00', '0', '', '0', '2012-03-07 10:54:42', '2012-03-07 11:33:53');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('97', '26', '1', '41', '63.00', '0', '', '0', '2012-03-07 10:54:42', '2012-03-07 11:33:53');
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('98', '33', '1', '39', '65.00', '0', '', '0', '2012-03-07 11:33:31', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('99', '34', '1', '39', '0.00', '0', '', '0', '2012-03-07 11:33:31', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('100', '35', '1', '39', '0.00', '0', '', '0', '2012-03-07 11:33:31', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('101', '33', '1', '40', '75.00', '0', '', '0', '2012-03-07 11:33:47', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('102', '34', '1', '40', '0.00', '0', '', '0', '2012-03-07 11:33:47', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('103', '35', '1', '40', '0.00', '0', '', '0', '2012-03-07 11:33:47', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('104', '33', '1', '41', '49.00', '0', '', '0', '2012-03-07 11:33:53', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('105', '34', '1', '41', '0.00', '0', '', '0', '2012-03-07 11:33:53', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('106', '35', '1', '41', '0.00', '0', '', '0', '2012-03-07 11:33:53', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('107', '36', '4', '29', '43.00', '0', '', '0', '2012-03-09 09:37:50', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('108', '36', '4', '28', '62.00', '0', '', '0', '2012-03-09 09:37:58', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('109', '36', '4', '26', '56.00', '0', '', '0', '2012-03-09 09:38:15', NULL);
insert into `exam_scores` (`id`, `student_id`, `schoolid`, `exam_id`, `marks`, `grading_level_id`, `remarks`, `is_failed`, `created_at`, `updated_at`) values ('110', '36', '4', '27', '59.00', '0', '', '0', '2012-03-09 09:38:21', NULL);

drop table if exists `exams`;
CREATE TABLE `exams` (
  `id` int(11) NOT NULL auto_increment,
  `exam_group_id` int(11) default NULL,
  `subject_id` int(11) default NULL,
  `schoolid` int(11) NOT NULL,
  `start_time` datetime default NULL,
  `end_time` datetime default NULL,
  `maximum_marks` decimal(10,2) default NULL,
  `minimum_marks` decimal(10,2) default NULL,
  `grading_level_id` int(11) default NULL,
  `weightage` int(11) default '0',
  `event_id` int(11) default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_exams_on_exam_group_id_and_subject_id` (`exam_group_id`,`subject_id`)
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('1', '1', '31', '1', '2011-12-12 08:14:00', '2011-12-12 11:15:00', '100.00', '30.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('2', '1', '32', '1', '2011-12-13 08:15:00', '2011-12-13 11:15:00', '100.00', '30.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('3', '2', '31', '1', '2011-12-12 08:14:00', '2011-12-12 11:15:00', '100.00', '30.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('4', '2', '32', '1', '2011-12-13 08:15:00', '2011-12-13 11:15:00', '100.00', '30.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('7', '4', '31', '1', '2011-12-12 08:14:00', '2011-12-12 11:15:00', '50.00', '17.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('9', '4', '32', '1', '2011-12-13 08:55:00', '2011-12-13 11:55:00', '50.00', '17.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('10', '5', '31', '1', '2012-01-05 21:10:00', '2012-01-05 23:11:00', '100.00', '33.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('11', '6', '28', '1', '2012-01-20 09:00:00', '2012-01-20 00:00:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('12', '6', '29', '1', '2012-01-23 08:00:00', '2012-01-23 11:00:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('13', '6', '30', '1', '2012-01-24 11:00:00', '2012-01-24 14:00:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('14', '7', '1', '1', '2012-01-25 08:00:00', '2012-01-25 11:00:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('15', '7', '2', '1', '2012-01-26 07:30:00', '2012-01-26 10:30:00', '100.00', '33.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('16', '7', '5', '1', '2012-01-27 08:30:00', '2012-01-27 11:30:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('17', '7', '13', '1', '2012-01-28 08:30:00', '2012-01-28 11:30:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('18', '7', '24', '1', '2012-01-30 09:00:00', '2012-01-30 00:00:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('19', '8', '1', '1', '2012-01-26 22:20:00', '2012-01-26 23:23:00', '100.00', '33.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('20', '8', '2', '1', '2012-01-27 05:24:00', '2012-01-27 07:24:00', '100.00', '33.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('21', '9', '31', '1', '2012-01-26 11:00:00', '2012-01-26 13:00:00', '70.00', '25.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('22', '9', '32', '1', '2012-01-27 14:00:00', '2012-01-27 17:00:00', '70.00', '25.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('23', '10', '36', '6', '2012-01-25 08:00:00', '2012-01-25 11:00:00', '100.00', '30.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('24', '10', '37', '6', '2012-01-26 07:30:00', '2012-01-26 10:30:00', '100.00', '30.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('25', '10', '38', '6', '2012-01-27 08:30:00', '2012-01-27 11:30:00', '100.00', '30.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('26', '11', '39', '4', '2011-07-26 08:00:00', '2011-07-26 11:00:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('27', '11', '40', '4', '2011-07-28 09:00:00', '2011-07-28 00:00:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('28', '12', '39', '4', '2012-03-12 10:00:00', '2012-03-12 01:00:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('29', '12', '40', '4', '2012-03-15 09:30:00', '2012-03-15 00:30:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('30', '13', '41', '4', '2012-08-20 11:30:00', '2012-08-20 13:30:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('31', '13', '42', '4', '2012-08-27 10:30:00', '2012-08-27 00:30:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('32', '14', '41', '4', '2013-01-22 01:00:00', '2013-01-22 16:00:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('33', '14', '42', '4', '2013-01-25 00:30:00', '2013-01-25 15:30:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('34', '15', '43', '4', '2013-09-09 02:00:00', '2013-09-09 17:00:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('35', '15', '44', '4', '2013-09-10 11:00:00', '2013-09-10 14:00:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('36', '16', '43', '4', '2014-02-14 15:00:00', '2014-02-14 18:00:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('37', '16', '44', '4', '2014-02-17 15:00:00', '2014-02-17 18:00:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('38', '17', '1', '1', '2012-08-20 11:30:00', '2012-08-20 13:30:00', '100.00', '40.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('39', '18', '45', '1', '2012-03-12 09:00:00', '2012-03-12 00:00:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('40', '18', '46', '1', '2012-03-13 08:00:00', '2012-03-13 11:00:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);
insert into `exams` (`id`, `exam_group_id`, `subject_id`, `schoolid`, `start_time`, `end_time`, `maximum_marks`, `minimum_marks`, `grading_level_id`, `weightage`, `event_id`, `created_at`, `updated_at`) values ('41', '18', '47', '1', '2012-03-14 09:00:00', '2012-03-14 00:00:00', '100.00', '35.00', NULL, '0', NULL, NULL, NULL);

drop table if exists `generate_final_score`;
CREATE TABLE `generate_final_score` (
  `id` int(11) NOT NULL auto_increment,
  `schoolid` int(10) NOT NULL,
  `batchid` int(10) NOT NULL,
  `sem_id` int(10) NOT NULL,
  `student_id` int(10) NOT NULL,
  `stu_max_marks` int(50) NOT NULL,
  `stu_obt_marks` int(50) NOT NULL,
  `percentage` float(15,2) NOT NULL,
  `status` int(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1; 
insert into `generate_final_score` (`id`, `schoolid`, `batchid`, `sem_id`, `student_id`, `stu_max_marks`, `stu_obt_marks`, `percentage`, `status`) values ('1', '4', '13', '1', '28', '200', '158', '79.00', '1');
insert into `generate_final_score` (`id`, `schoolid`, `batchid`, `sem_id`, `student_id`, `stu_max_marks`, `stu_obt_marks`, `percentage`, `status`) values ('2', '4', '13', '1', '29', '200', '127', '63.50', '1');
insert into `generate_final_score` (`id`, `schoolid`, `batchid`, `sem_id`, `student_id`, `stu_max_marks`, `stu_obt_marks`, `percentage`, `status`) values ('3', '4', '13', '1', '32', '200', '179', '89.50', '1');
insert into `generate_final_score` (`id`, `schoolid`, `batchid`, `sem_id`, `student_id`, `stu_max_marks`, `stu_obt_marks`, `percentage`, `status`) values ('12', '4', '13', '2', '32', '200', '117', '58.50', '1');
insert into `generate_final_score` (`id`, `schoolid`, `batchid`, `sem_id`, `student_id`, `stu_max_marks`, `stu_obt_marks`, `percentage`, `status`) values ('11', '4', '13', '2', '29', '200', '139', '69.50', '1');
insert into `generate_final_score` (`id`, `schoolid`, `batchid`, `sem_id`, `student_id`, `stu_max_marks`, `stu_obt_marks`, `percentage`, `status`) values ('10', '4', '13', '2', '28', '200', '119', '59.50', '1');
insert into `generate_final_score` (`id`, `schoolid`, `batchid`, `sem_id`, `student_id`, `stu_max_marks`, `stu_obt_marks`, `percentage`, `status`) values ('13', '4', '9', '1', '36', '200', '115', '57.50', '1');

drop table if exists `grades`;
CREATE TABLE `grades` (
  `id` int(11) NOT NULL auto_increment,
  `schoolid` int(11) NOT NULL,
  `grade_name` varchar(255) collate utf8_unicode_ci default NULL,
  `code` varchar(255) collate utf8_unicode_ci default NULL,
  `section_name` varchar(255) collate utf8_unicode_ci default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `grades` (`id`, `schoolid`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('1', '1', '8', 'G01', NULL, '0', NULL, NULL);
insert into `grades` (`id`, `schoolid`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('2', '1', '11', 'f02', NULL, '0', NULL, NULL);
insert into `grades` (`id`, `schoolid`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('3', '2', '9', 'H01', NULL, '0', NULL, NULL);
insert into `grades` (`id`, `schoolid`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('4', '1', '12', 'L1', NULL, '0', '2011-12-06 10:03:05', NULL);
insert into `grades` (`id`, `schoolid`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('5', '4', '9', 'VB1', NULL, '0', '2012-02-14 01:06:43', NULL);
insert into `grades` (`id`, `schoolid`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('6', '6', '2', '10002', NULL, '0', '2012-02-23 08:59:44', NULL);
insert into `grades` (`id`, `schoolid`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('7', '1', '10', 'L10', NULL, '0', '2012-02-27 10:53:15', NULL);
insert into `grades` (`id`, `schoolid`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('8', '4', '10', 'VB02', NULL, '0', '2012-02-29 02:00:31', NULL);
insert into `grades` (`id`, `schoolid`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('9', '4', '11', 'VB03', NULL, '0', '2012-02-29 02:30:08', NULL);

drop table if exists `grades_template`;
CREATE TABLE `grades_template` (
  `id` int(11) NOT NULL auto_increment,
  `grade_name` varchar(255) collate utf8_unicode_ci default NULL,
  `code` varchar(255) collate utf8_unicode_ci default NULL,
  `section_name` varchar(255) collate utf8_unicode_ci default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `grades_template` (`id`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('1', '11', NULL, NULL, '0', NULL, NULL);
insert into `grades_template` (`id`, `grade_name`, `code`, `section_name`, `is_deleted`, `created_at`, `updated_at`) values ('2', '10', NULL, NULL, '0', NULL, NULL);

drop table if exists `grading_levels`;
CREATE TABLE `grading_levels` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `schoolid` int(11) NOT NULL,
  `min_score` int(11) default NULL,
  `order` int(11) default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_grading_levels_on_batch_id_and_is_deleted` (`batch_id`,`is_deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

drop table if exists `grouped_exams`;
CREATE TABLE `grouped_exams` (
  `id` int(11) NOT NULL auto_increment,
  `exam_group_id` int(11) default NULL,
  `batch_id` int(11) default NULL,
  `schoolid` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `index_grouped_exams_on_batch_id` (`batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `grouped_exams` (`id`, `exam_group_id`, `batch_id`, `schoolid`) values ('3', '1', '5', '1');
insert into `grouped_exams` (`id`, `exam_group_id`, `batch_id`, `schoolid`) values ('4', '2', '5', '1');
insert into `grouped_exams` (`id`, `exam_group_id`, `batch_id`, `schoolid`) values ('5', '4', '5', '1');

drop table if exists `guardians`;
CREATE TABLE `guardians` (
  `id` int(11) NOT NULL auto_increment,
  `ward_id` int(11) default NULL,
  `userid` int(11) NOT NULL,
  `schoolid` int(11) NOT NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `relation` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `parent_id_card` varchar(255) collate utf8_unicode_ci NOT NULL,
  `office_phone1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_phone2` varchar(255) collate utf8_unicode_ci default NULL,
  `mobile_phone` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `office_address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `city` varchar(255) collate utf8_unicode_ci default NULL,
  `state` varchar(255) collate utf8_unicode_ci default NULL,
  `country_id` int(11) default NULL,
  `dob` date default NULL,
  `occupation` varchar(255) collate utf8_unicode_ci default NULL,
  `income` varchar(255) collate utf8_unicode_ci default NULL,
  `education` varchar(255) collate utf8_unicode_ci default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('1', '3', '7', '1', 'Ravindra', 'Singh', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2011-05-12 02:12:40', '2011-05-12 02:12:40');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('3', '7', '12', '1', 'kk', 'kumar', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('4', '8', '13', '1', 'Ramesh', 'Singh', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('5', '9', '14', '1', 'm', 'qwergt', 'ddwe', NULL, '5251.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('6', '10', '17', '1', 'Rajesh', 'Sen', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('7', '11', '18', '1', 'Ram', 'Singh', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('8', '12', '19', '1', 'Yashpal', 'Singh', 'Father', NULL, '8601.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('9', '13', '21', '1', 'Swaroop', 'Gupta', 'Father', NULL, '9833.png', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('10', '1', '22', '1', 'Jai', 'Prakash', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('11', '14', '23', '1', 'Abdul', 'Khan', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('12', '18', '24', '1', 'Aarti', 'Singh', 'Mother', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('13', '16', '28', '1', 'Ramzan', 'Seikh', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2011-09-12 11:12:46', '2011-09-12 11:12:46');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('14', '17', '29', '1', 'Tasmeez', 'Khan', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2011-09-12 11:12:26', '2011-09-12 11:12:26');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('15', '20', '30', '0', 'manohar', 'singh', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('16', NULL, '31', '4', 'Gaurav', 'Kumar', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('17', NULL, '35', '6', 'Kunal', 'Kumar', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('18', NULL, '37', '1', 'Ramzan', 'Seikh', 'Uncle', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('19', NULL, '38', '1', 'Rajesh', 'Joshi', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '0000-00-00 00:00:00', '0000-00-00 00:00:00');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('20', NULL, '39', '4', 'Simon', 'Paul', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2012-03-03 03:03:03', '2012-03-03 03:03:03');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('21', '25', '40', '1', 'Rahul', 'Scott', 'Uncle', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2012-07-03 10:03:22', '2012-07-03 10:03:22');
insert into `guardians` (`id`, `ward_id`, `userid`, `schoolid`, `first_name`, `last_name`, `relation`, `email`, `parent_id_card`, `office_phone1`, `office_phone2`, `mobile_phone`, `office_address_line1`, `office_address_line2`, `city`, `state`, `country_id`, `dob`, `occupation`, `income`, `education`, `created_at`, `updated_at`) values ('22', NULL, '41', '4', 'Hariram', 'Singh', 'Father', NULL, '', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2012-09-03 09:03:57', '2012-09-03 09:03:57');

drop table if exists `label_values`;
CREATE TABLE `label_values` (
  `id` int(11) NOT NULL auto_increment,
  `lb` varchar(200) NOT NULL,
  `en_value` varchar(1000) character set utf8 collate utf8_bin default NULL,
  `ar_value` varchar(1000) character set utf8 collate utf8_bin default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1475 DEFAULT CHARSET=latin1; 
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1', 'LNG_SAVE_AND_PROCEED', 'Add', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('2', 'LNG_CHANGE_LANG', 'Change Language', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('3', 'LNG_NEW', 'New', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('4', 'LNG_HOME', 'Home', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('5', 'LNG_ADD', 'Add', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('6', 'LNG_EDIT', 'Edit', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('7', 'LNG_DELETE', 'Delete', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('8', 'LNG_ENABLE', 'Enable', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('9', 'LNG_DISABLE', 'Disable', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('10', 'LNG_SAVE', 'Save', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('11', 'LNG_SUBMIT', 'Submit', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('12', 'LNG_REPLY', 'Reply', '??');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('13', 'LNG_SUBMIT', 'Finish', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('14', 'LNG_GO', 'Go', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('15', 'LNG_VIEW', 'View', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('16', 'LNG_CREATE', 'Create', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('17', 'LNG_UPDATE', 'Update', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('18', 'LNG_SHOW', 'Show', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('19', 'LNG_NAME', 'Name', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('20', 'LNG_START_DATE', 'Start date', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('21', 'LNG_END_DATE', 'End date', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('22', 'LNG_CONFIGURATION', 'Configuration', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('23', 'LNG_CONFIGURATION_HOME', 'Configuration Home', '??????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('24', 'LNG_BATCHES', 'Classes', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('25', 'LNG_MANAGE_BATCHES', 'Manage Classes', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('26', 'LNG_BATCH', 'Class', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('27', 'LNG_BATCH_NAME', 'Class Name', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('28', 'LNG_NEW_BATCH', 'New Class', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('29', 'LNG_SELECT_A_BATCH', 'Select a class', '??? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('30', 'LNG_ACTIVE_BATCHES', 'Active Classes', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('31', 'LNG_EDIT_BATCHES', 'Edit Classes', '????? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('32', 'LNG_NO_BATCHES_AVAILABLE', 'No Class Available.', '?? ??? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('33', 'LNG_CODE', 'Code', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('34', 'LNG_GRADES', 'Grades', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('35', 'LNG_NEWGRADES', 'New Grades', '????? ??');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('36', 'LNG_GRADE_NAME', 'Grade Name', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('37', 'LNG_MANAGE_GRADE', 'Manage Grade', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('38', 'LNG_SELECT_A_GRADE', 'Select a grade', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('39', 'LNG_MANAGE_GRADES', 'Manage Grades', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('40', 'LNG_SELECT_GRADE', 'Select a grade:', '??? ???? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('41', 'LNG_MANAGE_GRADES_BATCHES', 'Manage Grades / Classes', '????? ?????? / ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('42', 'LNG_ADDNEW_COURSE_OR_BATCH', 'Add a new Grades or Classes for this academic year.', '????? ?????? ????? ?? ???? ???? ????? ???????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('43', 'LNG_MANAGE_CREATE_GRADES', 'Manage Grades and create grades', '????? ?????? ???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('44', 'LNG_MANAGE_BATCHES', 'Manage Classes', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('45', 'LNG_MANAGE_ACTIVE_BATCHES', 'Manage Active Classes', '????? ?????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('46', 'LNG_GRADES_S', 'grades', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('47', 'LNG_GRADE', 'Grade', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('48', 'LNG_SUBJECT', 'Course', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('49', 'LNG_SELECT_A_SUBJECT', 'Select a Course', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('50', 'LNG_SUBJECTS', 'Courses', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('51', 'LNG_ADD_SUBJECT', 'Add Course', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('52', 'LNG_ADD_SUBJECTS', 'Add Courses', '????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('53', 'LNG_SELECT_SUBJECTS', 'Select Courses', '??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('54', 'LNG_ADD_NEW_SUBJECT', 'Add New Course', '????? ???? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('55', 'LNG_MANAGE_SUBJECTS', 'Manage Courses', '????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('56', 'LNG_MANAGE_SUBJECTS_CORRESPONDING_TO_GRADES', 'Manage courses corresponding to different grades.', '????? ???????? ???????? ?????? ???????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('57', 'LNG_SLNO', 'Sl.no', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('58', 'LNG_ADMISSION_NO', 'Admission Number', '???? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('59', 'LNG_STUDENT_ADMISSION_NO', 'Student Admission Number', '???? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('60', 'LNG_ADM_NO', 'Adm Number.', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('61', 'LNG_VIEW_PROFILE', 'View Profile', '??? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('62', 'LNG_STUDENT_DETAILS', 'Students Details', '??????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('63', 'LNG_VIEW_DETAILS', 'View Details', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('64', 'LNG_INITIAL_BATCH_DETAIL', 'Initial batch details', '?????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('65', 'LNG_STUDENTS', 'Students', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('66', 'LNG_REPORTS_CENTER', 'Reports center', '?????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('67', 'LNG_ACADEMICS', 'Academics', '???????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('68', 'LNG_RECENT_EXAMS', 'Recent exams', '???????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('69', 'LNG_SUBJECTWISE_RESULTS', 'Coursewise results', '????? ???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('70', 'LNG_DETAILED_REPORTS', 'Detailed reports', '?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('71', 'LNG_CURRENT_YEAR_REPORTS', 'Current year reports', '?????? ????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('72', 'LNG_STUDENT_INFO', 'Student Info', '???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('73', 'LNG_STUDENT_PROFILE', 'Student Profile', '?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('74', 'LNG_GUARDIANS', 'Guardians', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('75', 'LNG_ADMISSION_DATE', 'Admission Date', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('76', 'LNG_DOB', 'Date of birth', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('77', 'LNG_NATIONALITY', 'Nationality', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('78', 'LNG_RELIGION', 'Religion', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('79', 'LNG_ADDRESS', 'Address', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('80', 'LNG_PHONE', 'Phone', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('81', 'LNG_PHONENO', 'Phone No.', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('82', 'LNG_PARENTS_INFO', 'Parent Information', '??????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('83', 'LNG_EDIT_DETAILS', 'Edit details', '????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('84', 'LNG_STUDENT_DETAILS', 'Student details', '???? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('85', 'LNG_STEP_1_STUDENT_DETAILS', 'Step 1 - Student details', '?????? 1 -- ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('86', 'LNG_STEP_2_PARENT_DETAILS', 'Step 2 - Parent/guardian details', '?????? 2 -- ???? / ????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('87', 'LNG_ADMISSION', 'Admission', '?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('88', 'LNG_EDIT_PARENT_DETAIL', 'Edit Parent/guardian details', '????? ???????? / ????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('89', 'LNG_PARENTS_GUARDIANS', 'Parents/Guardian', '?????? / ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('90', 'LNG_RELATION', 'Relation', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('91', 'LNG_USERNAME', 'Username', '??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('92', 'LNG_PASSWORD', 'Password', '???? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('93', 'LNG_PARENT_PERSONAL_DETAIL', 'Parent - Personal Details', '????? -- ?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('94', 'LNG_FIRST_NAME', 'First Name', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('95', 'LNG_MIDDLE_NAME', 'Middle Name', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('96', 'LNG_LAST_NAME', 'Last Name', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('97', 'LNG_RELATIONSHIP', 'Relationship', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('98', 'LNG_UPLOAD_PARENT_ID_CARD', 'Upload Parent ID Card photo', '??? ???? ????? ?????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('99', 'LNG_PARENT_USERNAME', 'Parent Username', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('100', 'LNG_PARENT_PASSWORD', 'Parent Password', '???? ???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('101', 'LNG_FIELDS_MARKED_WITH', '', '');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('102', 'LNG_MUST_BE_FILLED', 'maindatory fields', '???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('103', 'LNG_PERSONAL_DETAIL', 'Personal Details', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('104', 'LNG_PASSPORT_OR_ID', 'Passport / ID Card', '???? ????? / ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('105', 'LNG_ID', 'ID', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('106', 'LNG_PASSPORT', 'Passport', '???? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('107', 'LNG_TITLE', 'Title', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('108', 'LNG_SENT_ON', 'Sent on', '????? ??');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('109', 'LNG_GRADE_AND_BATCH', 'Grade & Class', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('110', 'LNG_CONTACT_DETAILS', 'Contact Details', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('111', 'LNG_UPLOAD_USER_PHOTO', 'Photos', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('112', 'LNG_UPLOAD_PHOTO', 'Personal Photo (250KB max)', '?????? ??????? (250 ???????? ??? ????)');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('113', 'LNG_UPLOAD_BIRTH_CERTIFICATE', 'Birth Certificate�', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('114', 'LNG_MESSAGE_STUDENT_RECORD_SAVED', 'Student Record Saved Successfully. Please fill the Parent Details.', '???????? ??? ?????? ?????. ?????? ??? ?????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('115', 'LNG_ATTENDANCE', 'Attendance', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('116', 'LNG_ATTENDANCE_HOME', 'Attendance Home', '?????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('117', 'LNG_ATTENDANCE_REGISTER', 'Attendance Register', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('118', 'LNG_ATTENDANCE_REGISTER_FOR_STUDENTS', 'Attendance register for students', '????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('119', 'LNG_MANAGE_ATTENDANCE_REGISTER', 'Manage Attendance Register', '????? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('120', 'LNG_CREATE_UPDATE_ATTENDANCE_REGISTER', 'Create and update attendance register', '????? ?????? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('121', 'LNG_ATTENDANCE_REPORT', 'Attendance Report', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('122', 'LNG_ATTENDANCE_REPORT_OF_STUDENTS', 'Attendance report of students', '????? ?????? ?? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('123', 'LNG_REASON_FOR_ABSENCE', 'Reason for absence', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('124', 'LNG_ATTENDANCE_FOR', 'Attendance for', '?????? ??');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('125', 'LNG_FROM', 'From', '?? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('126', 'LNG_TO', 'To :', '??? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('127', 'LNG_PUBLISH_REGISTER', 'Publish Register', '??? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('128', 'LNG_EVENTS', 'Events', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('129', 'LNG_EXAMINATIONS', 'Examinations', '??????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('130', 'LNG_HOLIDAYS', 'Holidays', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('131', 'LNG_SUNDAY', 'Sunday', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('132', 'LNG_MONDAY', 'Monday', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('133', 'LNG_TUESDAY', 'Tuesday', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('134', 'LNG_WEDNESDAY', 'Wednesday', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('135', 'LNG_THURSDAY', 'Thursday', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('136', 'LNG_FRIDAY', 'Friday', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('137', 'LNG_SATURDAY', 'Saturday', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('138', 'LNG_IS_HOLIDAY', 'Is Holiday?', '?? ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('139', 'LNG_COMMON', 'Common', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('140', 'LNG_EVENT_COMMON_TO_ALL', 'Event common to all', '???????? ????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('141', 'LNG_CREATE_EVENT', 'Create Event', '????? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('142', 'LNG_UPDATE_EVENT', 'Update Event', '??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('143', 'LNG_STEP1_EVENT_CREATE', 'Step 1 - Event creation', '?????? 1 -- ????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('144', 'LNG_STEP2_CONFIRMATION', 'Step 2 - Confirmation', '?????? 2 -- ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('145', 'LNG_SEPERATOR_1', ':', ':');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('146', 'LNG_SEPERATOR_2', '-', '--');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('147', 'LNG_DESCRIPTION', 'Description', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('148', 'LNG_OTHER_EVENTS', 'Other Events', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('149', 'LNG_THIS_EVENT_IS_COMMON_ACROSS_ALL_CLASSES', 'This event is common across all classes', '??? ????? ?? ????? ??? ???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('150', 'LNG_COURSES_ASSOCIATED', 'Courses Associated', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('151', 'LNG_NO_CLASS_SELECTED_FOR_THIS_EVENT', 'No class selected for this event yet', '?? ??? ?????? ???? ????? ??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('152', 'LNG_SELECT_MORE_COURSES', 'Select more Courses', '????? ???? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('153', 'LNG_REMOVE', 'Remove', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('154', 'LNG_CANCEL', 'Cancel', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('155', 'LNG_WELCOME_MESSAGE1', 'Welcome', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('156', 'LNG_WELCOME_MESSAGE2', 'to My School dashboard', '???? ??????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('157', 'LNG_ADD_SCHOOL', 'Add School', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('158', 'LNG_STEP1_SCHOOL_DETAILS', 'Step 1 - School details', '?????? 1 -- ?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('159', 'LNG_SCHOOL_NAME', 'School/College Name', '??????? / ?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('160', 'LNG_SCHOOL_ADDRESS', 'School/College Address', '??????? / ?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('161', 'LNG_SCHOOL_PHONE', 'School/College Phone', '??????? / ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('162', 'LNG_SCHOOL_FAX_NO', 'School/College Fax No.', '??????? / ?????? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('163', 'LNG_UPLOAD_LOGO', 'Upload Logo', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('164', 'LNG_SCHOOL_DETAILS', 'School details', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('165', 'LNG_VIEW_SCHOOLS', 'View Schools', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('166', 'LNG_ADD_SECRETARY', 'Add secritary', '????? ????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('167', 'LNG_MANAGE_SECRETARY', 'Manage Secretary', '?????? ??????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('168', 'LNG_MY_PROFILE', 'My Profile', '???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('169', 'LNG_TIMETABLE', 'Timetable', '??????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('170', 'LNG_SETTINGS', 'Settings', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('171', 'LNG_MANAGE_EMPLOYEE', 'Manage Employee', '????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('172', 'LNG_CREATE_EDIT_TIMETABLE', 'Create/Edit Timetable', '????? / ????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('173', 'LNG_TIMETABLE_TEXT2', 'Select a class and edit the timetable for that class.', '????? ?????? ?????? ?????? ?????? ???? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('174', 'LNG_SET_CLASS_TIMINGS', 'Set class timings', '??? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('175', 'LNG_TIMETABLE_TEXT3', 'Select a class and edit the timetable for that class.', '????? ?????? ?????? ?????? ?????? ???? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('176', 'LNG_VIEW_TIMETABLE', 'View Timetables', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('177', 'LNG_TIMETABLE_TEXT4', 'View the timetable for a class.', '??? ???? ???? ????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('178', 'LNG_CREATE_WEEKDAYS', 'Create weekdays', '????? ???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('179', 'LNG_SELECT_CLASS_TO_EDIT', 'Select class to edit', '??? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('180', 'LNG_EDIT_BATCH', 'Edit Class', '????? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('181', 'LNG_ADD_SUBJECTS_EMPLOYEE', 'Add Subjects/Employee', '????? ?????? / ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('182', 'LNG_SET_IN_COMMON', 'Set in common', '?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('183', 'LNG_START_TIME', 'Start time', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('184', 'LNG_END_TIME', 'End time', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('185', 'LNG_OPERATIONS', 'Operations', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('186', 'LNG_IS_A_BREAK', 'Is a break', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('187', 'LNG_EDIT_CLASSTIMINGS_FOR', 'Edit class timing for', '????? ????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('188', 'LNG_ADD_NEW_CLASSTIMINGS_FOR', 'Add new class timing for', '????? ????? ??????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('189', 'LNG_SELECT_BATCH_TO_VIEW', 'Select class to view', '??? ??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('190', 'LNG_WEEKDAYS', 'Weekdays', '???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('191', 'LNG_TEACHER', 'Teacher', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('192', 'LNG_EMPLOYEE_SETTINGS', 'Employee settings.', '??? ????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('193', 'LNG_EMPLOYEE_MANAGEMENT', 'Employee Management', '???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('194', 'LNG_MANAGE_ALL_EMPLOYEE', 'Manage all employees', '????? ???? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('195', 'LNG_EMPLOYEE_LIST', 'Employee List', '????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('196', 'LNG_SEARCH_FOR_EMPLOYEES', 'Search for employees', '????? ?? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('197', 'LNG_ADD_EMP_CATEGORY', 'Add employee category', '????? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('198', 'LNG_EMP_TEXT2', 'Add and edit employee category.', '????? ?????? ??? ??????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('199', 'LNG_ADD_EMP_POSITION', 'Add employee position', '????? ???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('200', 'LNG_EMP_TEXT3', 'Add and edit employee position.', '????? ?????? ???? ????????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('201', 'LNG_ADD_EMP_DEPT', 'Add employee department', '????? ??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('202', 'LNG_EMP_TEXT4', 'Add and edit employee department.', '????? ?????? ??? ??????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('203', 'LNG_PREFIX', 'Prefix', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('204', 'LNG_STATUS', 'Status', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('205', 'LNG_ACTIVE_CATEGORIES', 'Active Categories', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('206', 'LNG_INACTIVE_CATEGORIES', 'Inactive Categories', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('207', 'LNG_EMP_CATEGORY', 'Employee category', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('208', 'LNG_ACTIVE_POSITIONS', 'Active Positions', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('209', 'LNG_INACTIVE_POSITIONS', 'Inactive Positions', '????? ??? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('210', 'LNG_DEPT_CODE', 'Dept. code', '??? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('211', 'LNG_ACTIVE_DEPARTMENTS', 'Active Departments', '???????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('212', 'LNG_INACTIVE_DEPARTMENTS', 'Inactive Departments', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('213', 'LNG_EMP_ADMISSION', 'Employee admission', '???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('214', 'LNG_EMP_ADMISSION_FORM', 'Employee admission form', '?????? ???? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('215', 'LNG_EMP_SUBJECT_ASSOCIATION', 'Employee Subject Association', '????? ?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('216', 'LNG_EMP_TEXT5', 'Assign an employee with one or more subjects', '????? ???? ???? ?? ???? ?? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('217', 'LNG_EMP_CLASS_ASSOCIATION', 'Employee Class Association', '???? ??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('218', 'LNG_EMP_TEXT6', 'Assign an employee with one or more class', '????? ???? ???? ?? ???? ?? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('219', 'LNG_STEP1', 'Step-1', '???? 1');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('220', 'LNG_GENERAL_DETAILS', 'General Details', '?????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('221', 'LNG_EMP_NO', 'Employee no.', '?? ????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('222', 'LNG_JOINING_DATE', 'Joining date.', '????? ????????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('223', 'LNG_GENDER', 'Gender', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('224', 'LNG_DEPT', 'Department', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('225', 'LNG_CATEGORY', 'Category', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('226', 'LNG_POSITION', 'Position', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('227', 'LNG_QUALIFICATION', 'Qualification', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('228', 'LNG_EXP_INFO', 'Experience Info', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('229', 'LNG_TOTAL_EXP', 'Total Experience', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('230', 'LNG_MARTIAL_STATUS', 'Marital status', '?????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('231', 'LNG_NO_OF_CHILD', 'No. of children', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('232', 'LNG_FATHER_NAME', 'Father name', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('233', 'LNG_MOTHER_NAME', 'Mother name', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('234', 'LNG_SPOUSE_NAME', 'Spouse name', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('235', 'LNG_BLOOD_GROUP', 'Blood group', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('236', 'LNG_STEP2', 'Step-2', '???? 2');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('237', 'LNG_HOME_ADDRESS', 'Home Address', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('238', 'LNG_LINE1', 'Line 1', '????? 1');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('239', 'LNG_LINE2', 'Line 2', '????? 2');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('240', 'LNG_CITY', 'City', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('241', 'LNG_STATE', 'State', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('242', 'LNG_COUNTRY', 'Country', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('243', 'LNG_PIN', 'PIN', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('244', 'LNG_OFFICE_ADDRESS', 'Office Address', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('245', 'LNG_SKIP_THIS_STEP', 'Skip This Step', '???? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('246', 'LNG_EMP_RECORD_SAVED', 'Employee record saved', '??? ?????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('247', 'LNG_EMP_PROFILE', 'Employee Profile', '?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('248', 'LNG_DETAILS', 'Details', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('249', 'LNG_PROFILE', 'Profile', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('250', 'LNG_GENERAL', 'General', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('251', 'LNG_PERSONAL', 'Personal', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('252', 'LNG_ADDRESS', 'Address', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('253', 'LNG_YEARS', 'Years', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('254', 'LNG_MONTHS', 'Months', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('255', 'LNG_EDIT_EMP_INFO', 'Edit employee information', '????? ??????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('256', 'LNG_EMPLOYEE_SUBJECT', 'Employee Subject', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('257', 'LNG_ASSOCIATE', 'Associate', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('258', 'LNG_EMPLOYEE_CLASS', 'Employee Class', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('259', 'LNG_EMPLOYEES', 'Employees', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('260', 'LNG_CURRENTLY_ASSIGNED', 'Currently assigned:', '??????? ????? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('261', 'LNG_NO_EMPLYEES_ASSIGNED', 'No employee assigned yet.', '????? ?? ???? ??? ????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('262', 'LNG_SELECT_DEPARTMENT', 'Select department', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('263', 'LNG_NO_EMPLOYEES_IN_DEPARTMENT', 'No employee in this department.', '?? ???? ?? ??? ???????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('264', 'LNG_ASSIGN_NEW', 'Assign new:', '????? ???? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('265', 'LNG_ASSIGN', 'Assign', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('266', 'LNG_VIEW_ALL', 'View all', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('267', 'LNG_VIEW_ALL_S', 'view all', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('268', 'LNG_SELECT_A_DEPARTMENT', 'Select a Department :', '??? ????? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('269', 'LNG_SELECT_EMPLOYEE', 'Select Employee', '?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('270', 'LNG_EXAMS', 'Exams', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('271', 'LNG_EXAM', 'Exam', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('272', 'LNG_SET_GRADING_LEVELS', 'Set grading levels', '????? ??????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('273', 'LNG_EXAM_TXT2', 'Set the Grading Levels', '????? ??????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('274', 'LNG_EXAM_MANAGEMENT', 'Exam Management', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('275', 'LNG_EXAM_TXT3', 'Create new exams, enter results.', '????? ???????? ????? ? ?????? ???????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('276', 'LNG_EXAM_WISE_REPORT', 'Exam Wise report', '????? ???????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('277', 'LNG_EXAM_TXT4', 'Generates reports Exam wise', '???? ?????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('278', 'LNG_SUBJECT_WISE_REPORT', 'Subject Wise report', '????? ??????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('279', 'LNG_EXAM_TXT5', 'Generates reports Subject wise', '???? ?????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('280', 'LNG_GROUPED_EXAM_REPORT', 'Grouped Exam report', '????? ?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('281', 'LNG_EXAM_TXT6', 'Group up exams for specific reports', '??? ?????? ???????? ???????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('282', 'LNG_GRADING_LEVELS', 'Grading levels', '????? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('283', 'LNG_ADD_GRADES', 'Add Grades', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('284', 'LNG_MIN_SCORE', 'Min score', '???? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('285', 'LNG_ADD_NEW_GRADING_LEVEL', 'Add new grading level', '????? ????? ??? ????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('286', 'LNG_MIN_SCORE_FOR_THIS_GRADE', 'Min score for this grade', '???? ????? ???? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('287', 'LNG_EDIT_GRADING_LEVEL', 'Edit grading level', '????? ????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('288', 'LNG_CREATE_EXAM', 'Create Exam', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('289', 'LNG_EXAM_GROUPS', 'Exam groups', '?????? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('290', 'LNG_CONNECT_EXAMS', 'Connect exams', '??????? ??????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('291', 'LNG_EXAM_NAME', 'Exam name', '??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('292', 'LNG_ACTION', 'Action', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('293', 'LNG_EXAM_RESULT_PUBLISHED', 'Exam result published.', '????? ?????? ????????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('294', 'LNG_SCHEDULED_PUBLISHED', 'Schedule published.', '???? ????????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('295', 'LNG_PUBLISH_EXAM_RESULT', 'Publish Exam Result', '??? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('296', 'LNG_PUBLISH_EXAM_SCHEDULE', 'Publish Exam Schedule', '??? ???? ??????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('297', 'LNG_SHOWING_EXAM_GROUPS', 'Showing Exam groups', '??? ????????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('298', 'LNG_MAX_MARKS', 'Max marks', '???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('299', 'LNG_MIN_MARKS', 'Min marks', '?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('300', 'LNG_MANAGE', 'Manage', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('301', 'LNG_EDIT_EXAM', 'Edit Exam', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('302', 'LNG_FOR_EXAM_GROUP', 'For exam group', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('303', 'LNG_MAXIMUM_MARKS', 'Maximum Marks', '???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('304', 'LNG_MINIMUM_MARKS', 'Minimum Marks', '???? ?????? ?? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('305', 'LNG_RESULT_ENTRY', 'Result Entry', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('306', 'LNG_MARKS', 'Marks', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('307', 'LNG_REMARKS_ETC', 'Remarks(absent or disqualified)', '??????? (??? ???? / ????)');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('308', 'LNG_NEW_EXAM', 'New Exam', '?????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('309', 'LNG_EXAM_TYPE', 'Exam Type', '??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('310', 'LNG_MARKS_AND_GRADES', 'MarksAndGrades', '???????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('311', 'LNG_SELECT_EXAM_GROUP', 'Select exam group', '??? ???????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('312', 'LNG_GENERATED_REPORT', 'Generated Report', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('313', 'LNG_CONSOLIDATED_REPORT', 'Consolidated Report', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('314', 'LNG_OBTAINED_MARKS', 'Obtained Marks', '?????? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('315', 'LNG_PERCENTAGE', 'Percentage(%)', '?????? ??????? (?)');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('316', 'LNG_TOTAL_MARKS', 'Total Marks:', '????? ???????? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('317', 'LNG_BATCH_AVERAGE_MARKS', 'Class Average Marks', '????? ?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('318', 'LNG_BATCH_AVERAGE_PERCENT', 'Class Average %', '??? ????? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('319', 'LNG_SUBJECT_WISE_REPORT', 'Subject wise Reports', '?????? ?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('320', 'LNG_GROUPING', 'Grouping', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('321', 'LNG_GROUPED_EXAM_REPORT', 'Grouped exam Reports', '?????? ????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('322', 'LNG_NO_RECORD_AVAILABLE', 'No Record Available.', '?? ??? ????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('323', 'LNG_TOTAL', 'Total', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('324', 'LNG_AGGREGATE_PERCENT', 'Aggregate % :', '????????? ? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('325', 'LNG_ENTER_EXAM_RELATED_DETAIL', 'Enter exam related details here:', '????? ???????? ???????? ???????? ??? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('326', 'LNG_SUBJECT_NAME', 'Course name', '?????? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('327', 'LNG_DO_NOT_CREATE', 'Do not create', '?? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('328', 'LNG_SAVE_CHANGES', 'Save Changes', '??? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('329', 'LNG_PUBLISH_RESULT', 'Publish Result', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('330', 'LNG_QUESTIONAIRE', 'Questionnaire', '?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('331', 'LNG_GENERAL_LIST', 'General List', '????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('332', 'LNG_ARCHIVE_LIST', 'Archive List', '????? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('333', 'LNG_ACTIVE_LIST', 'Active List', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('334', 'LNG_SUMMARY', 'Summary', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('335', 'LNG_FULL_DESCRIPTION', 'Full Description :', '???? ????? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('336', 'LNG_DATE', 'Date', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('337', 'LNG_FINAL_REPORT_EXAM_GROUPED', 'Final Report(Exams Grouped)', '??????? ??????? (?????????? ?????)');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('338', 'LNG_COMPARE_WITH_PAST_YEARS', 'Compare with past years (Exams Grouped)', '?????? ?? ??????? ??????? (?????????? ?????)');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('339', 'LNG_TEACHER_TIMETABLE', 'Teacher Time-table', '?????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('340', 'LNG_CREATE_SECRETARY', 'Create Secretary', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('341', 'LNG_ADD_NEW_SECRETARY', 'Add new Secretary', '????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('342', 'LNG_EMAIL', 'Email', '?????? ??????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('343', 'LNG_SCHOOL', 'School', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('344', 'LNG_DETAILS_ABOUT_SECRETARY', 'Details about Secretaries', '?????? ??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('345', 'LNG_ADD_NEW', 'Add new', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('346', 'LNG_SEARCH_SECRETARY', 'Search Secretaries', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('347', 'LNG_ALL_USERS', 'All Users', '???? ??????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('348', 'LNG_SECRETARY_PROFILE', 'Secretary Profile', '???????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('349', 'LNG_SECRETARY_INFORMATION', 'Secretary Information', '???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('350', 'LNG_CHANGE_PASSWORD', 'Change Password', '????? ???? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('352', 'LNG_EDIT_PROFILE', 'Edit Profile', '????? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('353', 'LNG_DETAILS_ABOUT_USERS', 'Details about users', '?????? ??? ??????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('354', 'LNG_SELECT_A_SCHOOL', 'Select a School', '?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('355', 'LNG_REMOVE_STUDENT', 'Remove student', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('356', 'LNG_STUDENT_LEAVING_INSTITUTE', 'Student leaving Institution', '???? ??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('357', 'LNG_REMOVE_STUDENT_TEXT1', 'For students leaving the Institution, use this option to remove them from the list of active students and place them in the former students list.', '?????? ??? ???????? ???????? ??? ?????? ???????? ?? ????? ?????? ????? ?????? ?? ????? ?????? ????????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('358', 'LNG_REMOVE_STUDENT_RECORDS', 'Remove student records', '????? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('359', 'LNG_ID', 'Completely delete student\'s records from the Institution\'s databases. Use this option only if you created the student record by accident and want to remove it completely.', '??? ????? ????? ?????? ?? ????? ?????? ???????. ??????? ??? ?????? ??? ??? ??? ?????? ??? ?????? ?? ???? ?????? ????? ?????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('360', 'LNG_REMOVE_STUDENT_TEXT2', 'Completely delete student\'s records from the Institution\'s databases. Use this option only if you created the student record by accident and want to remove it completely.', '??? ????? ????? ?????? ?? ????? ?????? ???????. ??????? ??? ?????? ??? ??? ??? ?????? ??? ?????? ?? ???? ?????? ????? ?????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('361', 'LNG_LEAVING_SCHOOL', 'Leaving school', '??? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('362', 'LNG_REASON_FOR_LEAVING', 'Reason for leaving', '??? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('363', 'LNG_BATCH_TEACHER', 'Class Teacher', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('364', 'LNG_COMMENTS', 'Comments', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('365', 'LNG_UPDATE_SECRETARY', 'Update Secretary', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('366', 'LNG_EDIT_SECRETARY', 'Edit Secretary', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('367', 'LNG_EDIT_USER', 'Edit User', '????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('368', 'LNG_UPDATE_USER_INFO', 'Update user information', '????? ??????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('369', 'LNG_NEW_PASSWORD', 'New password', '???? ???? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('370', 'LNG_CONFIRM_PASSWORD', 'Confirm password', '????? ???? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('371', 'LNG_UPDATE_SCHOOL', 'Update School', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('372', 'LNG_UPDATE_SCHOOL_DETAILS', 'Update School Details', '?????? ??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('373', 'LNG_ADMINISTRATOR', 'Administrator', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('374', 'LNG_INFORMATION', 'Information', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('375', 'LNG_UPDATE_DETAILS', 'Update Details', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('376', 'LNG_PRESENT_STUDENTS', 'Present Students', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('377', 'LNG_FORMER_STUDENTS', 'Former Students', '?????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('378', 'LNG_CALENDER', 'Calender', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('379', 'LNG_EMPLOYEE_SEARCH', 'Employee search', '???? ?? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('380', 'LNG_EMPLOYEE_DETAILS', 'Employee Details', '?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('381', 'LNG_SEARCH', 'Search', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('382', 'LNG_SELECT_CATEGORY', 'Select category', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('383', 'LNG_SELECT_POSITION', 'Select position', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('384', 'LNG_POST_A_COMMENT', 'Post a Comment', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('385', 'LNG_MESSAGES', 'Messages', '???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('386', 'LNG_MESSAGE', 'Message', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('387', 'LNG_LOGOUT', 'Log out', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('388', 'LNG_DASHBOARD', 'Dashboard', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('389', 'LNG_MANAGE_SCHOOLS', 'Manage Schools', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('390', 'LNG_POWERED_BY', 'Powered by', '????? ??');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('391', 'LNG_STUDENTS', 'Students', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('392', 'LNG_SUBJECTS_TEMPLATE', 'Courses Template', '????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('393', 'LNG_MANAGE_TEMPLATE', 'Manage template', '????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('394', 'LNG_MANAGE_SUBJECTS_TEMPLATE', 'Manage Courses Template', '????? ???????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('395', 'LNG_ACTIVE_SUBJECTS', 'Active Courses', '??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('396', 'LNG_ADD_SUBJECTS_TEMP', 'Add Courses Template', '????? ???? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('397', 'LNG_SESSION_START_YEAR', 'Session Start Year', '???? ???? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('398', 'LNG_SELECT_A_RELIGION', 'Select a Religion', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('399', 'LNG_ADVANCE_SEARCH', 'Advanced Search', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('400', 'LNG_TOTAL_NO_OF_WORK_DAYS', 'Total no. of working days =', '???? ??. ?? ???? ????? =');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('401', 'LNG_SELECT_MONTH_AND_YEAR', 'Select month & year :', '??? ????? ?????? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('402', 'LNG_SELECT_A_MONTH', 'Select a month', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('403', 'LNG_SELECT_A_MODE', 'Select a mode:', '??? ????? :');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('404', 'LNG_MONTHLY', 'Monthly', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('405', 'LNG_OVERALL', 'Overall', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('406', 'LNG_BIRTH_DATE', 'Birth date', '????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('407', 'LNG_STUDENT', 'Student', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('408', 'LNG_DEPARTMENT', 'Department', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('409', 'LNG_KEYWORD', 'Keyword', '??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('410', 'LNG_FILTER', 'Search', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('411', 'LNG_TO_S', 'to', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('412', 'LNG_ADVANCE_SEARCH_DETAILS', 'Advance Search Details', '?????? ????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('413', 'LNG_SIMPLE_SEARCH', 'Simple Search', '??? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('414', 'LNG_CREATE_NEW', 'Create New', '??? ??? ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('415', 'LNG_CREATE_REMINDER_TO_STAFF', 'Create reminder to a staff', '????? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('416', 'LNG_SELECT_MANAGEMENT', 'Select Management', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('417', 'LNG_SUPER_ADMIN', 'Super Administrator', '???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('418', 'LNG_SELECT_STAFF_NAME', 'Select Staff Name', '?????? ??? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('419', 'LNG_CREATE_REMINDER_TO_GUARDIAN', 'Create reminder to a student\'s guardians', '????? ????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('420', 'LNG_SENT', 'Sent', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('421', 'LNG_INBOX', 'Inbox', '?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('422', 'LNG_CREATE_TICKET_TO_STAFF', 'Create Ticket to Staff', '????? ????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('423', 'LNG_CREATE_TICKET_TO_GUARDIAN', 'Create ticket to a student', '????? ????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('427', 'LNG_BATCH_SAVED', 'Class has been saved.', '?? ??? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('428', 'LNG_BATCH_UPDATED', 'Class updated successfully.', '??? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('429', 'LNG_BATCH_DELETED', 'Class deleted successfully.', '??? ??? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('430', 'LNG_STUDENT_CATEGORY_SAVED', 'Student category has been saved.', '?? ??? ??? ??????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('431', 'LNG_EVENT_UPDATED', 'Event Updated Successfully', '????? ??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('432', 'LNG_EXAM_CREATED', 'Exam created successfully.', '????? ???????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('433', 'LNG_EXAM_GROUPED', 'Exam grouped successfully.', '?????? ????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('434', 'LNG_EXAM_UPDATED', 'Exam updated successfully.', '????? ???????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('435', 'LNG_EXAM_SCORES_UPDATED', 'Exam scores updated.', '????? ???????? ???????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('436', 'LNG_GRADE_UPDATED', 'Grade updated successfully.', '???? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('437', 'LNG_GRADE_CREATED', 'Grade Created successfully.', '????? ???? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('438', 'LNG_GRADE_DELETED', 'Grade has been deleted successfully', '??? ?? ??? ???? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('439', 'LNG_INVALID_EMAILID_PASSWORD', 'Invalid username or password.', '??? ???? ??? ???????? ?? ???? ????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('440', 'LNG_YOU_ARE_LOGGED_OUT', 'You are logged out successfully.', '??? ????? ????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('441', 'LNG_SCHOOL_ADDED', 'School added successfully.', '????? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('442', 'LNG_SCHOOL_UPDATED', 'School information updated successfully.', '????? ??????? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('443', 'LNG_STUDENT_ADDED', 'Student admission successful', '???? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('444', 'LNG_STUDENT_UPDATED', 'Student details updated successfully.', '?????? ?????? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('445', 'LNG_STUDENT_NOT_ADDED', 'Student admission not successful.', '???? ?????? ??? ???????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('446', 'LNG_STUDENT_GUARDIAN_DETAIL_UPDATED', 'Student guardian detail updated successfully.', '???? ??? ????? ???????? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('447', 'LNG_STUDENT_CATEGORY_DELETED', 'Student category has been deleted.', '?? ??? ??? ??????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('448', 'LNG_STUDENT_CATEGORY_UPDATED', 'Student category has been updated.', '?? ????? ??? ??????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('449', 'LNG_STUDENT_CATEGORY_SAVED', 'Student category has been saved.', '?? ??? ??? ??????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('450', 'LNG_SECRETARY_ADDED', 'Secretary added successfully.', '????? ?????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('451', 'LNG_SECRETARY_UPDATED', 'Secretary updated successfully.', '?????? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('452', 'LNG_WEEKDAY_UPDATED', 'Weekday updated successfully.', '???? ??????? ??????? ?????.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('453', 'LNG_EMPLOYEE_CATEGORY_ADDED', 'Employee category added successfully', '????? ??? ?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('454', 'LNG_EMPLOYEE_CATEGORY_UPDATED', 'Employee category updated successfully', '??? ?????? ??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('455', 'LNG_EMPLOYEE_CATEGORY_DELETED', 'Employee category deleted successfully', '??? ?????? ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('456', 'LNG_EMPLOYEE_DEPARTMENT_ADDED', 'Employee department added successfully', '????? ?????? ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('457', 'LNG_EMPLOYEE_DEPARTMENT_UPDATED', 'Employee department updated successfully', '???? ??? ??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('458', 'LNG_EMPLOYEE_DEPARTMENT_DELETED', 'Employee department deleted successfully', '???? ????? ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('459', 'LNG_EMPLOYEE_POSITION_ADDED', 'Employee position added successfully', '????? ?????? ?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('460', 'LNG_EMPLOYEE_POSITION_UPDATED', 'Employee position updated successfully', '???? ?????? ??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('461', 'LNG_EMPLOYEE_POSITION_DELETED', 'Employee position deleted successfully', '???? ?????? ??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('462', 'LNG_EMPLOYEE_ADDED', 'Employee added successfully', '????? ?????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('463', 'LNG_EMPLOYEE_PRIVILEGES_UPDATED', 'Employee privileges updated successfully', '???????? ?????? ??????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('464', 'LNG_NO_EMPLOYEE_IN_THIS_DEPARTMENT', 'No Employee in the selected department', '?? ???? ?? ??????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('465', 'LNG_NO_STUDENTS_IN_SELECTED_BATCH', 'No Students in selected class', '?? ???? ?? ???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1395', 'LNG_ALL', 'All', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1396', 'LNG_SELECTED', 'Selected', '????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1397', 'LNG_SELECTED_MANAGEMENT_STAFF', 'Selected Management Staff', '?????? ????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1398', 'LNG_COMMENT', 'Post Comment', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1399', 'LNG_COMMENT_SUCCESSFULLY_POSTED', 'Comment Successfully Posted', '????? ????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1400', 'LNG_SET_WEEKDAY_BEFORE_ATTENDANCE_PROCESS', 'Set weekday before attendance process. To set weekday ', '????? ??? ?? ???? ??????? ??? ????? ??????. ?????? ???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1401', 'LNG_CLICK_HERE', 'Click Here', '???? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1402', 'LNG_REPORT', 'Report', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1403', 'LNG_ADD_SUBJECT_TEMPLATE', 'Add Subject Template', '????? ???? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1404', 'LNG_TOTAL_LEAVES', 'Total Leaves', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1405', 'LNG_BACKUP', 'Backup', '????? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1406', 'LNG_DATABASE_BACKUP', 'Database Backup', '????? ?????? ????? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1407', 'LNG_BACKUP_STORE_ON', 'Backup is store on 
', '??? ????? ???? ???????? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1408', 'LNG_BACKUP_ALREADY_MESSAGE', 'Backup Already Made', '????? ????????? ???? ????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1409', 'LNG_SCHOOL_DELETED', 'School Data  Successfully Deleted', '??????  ??????? ????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1410', 'LNG_SCHOOL_STATUS_UPDATED', 'School Status Updated', '???? ?? ????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1411', 'LNG_EXPORT', 'Export', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1412', 'LNG_TEACHER_LOGIN', 'Teacher Login', '???? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1413', 'LNG_PARENT_LOGIN', 'Parent Login', '???? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1414', 'LNG_GENERAL_SETTINGS', 'General settings', '????????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1415', 'LNG_SETTINGS_LINE3', 'Set some general configurations related to school, etc.', '????? ??? ??????? ?????? ??? ????? ??? ??????? ? ???.');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1417', 'LNG_NOTES', 'Notes', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1418', 'LNG_ADD_NOTE', 'Add Note', '?????  ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1419', 'LNG_NOTES_ABOUT_STUDENT', 'Notes About Student', '??????? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1420', 'LNG_WELCOME', 'Welcome, ', '????? ?');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1421', 'LNG_LETTER_A_E', 'Arabic', 'English');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1422', 'LNG_TRANSFER_STUDENT', 'Transfer student', '??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1423', 'LNG_TRANSFER_STUDENT_LINE1', 'Transfer student to another batch', '??? ?????? ??? ???? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1424', 'LNG_NOTE_SUCCESSFULLY_CREATED', 'Note Successfully Created', '?????? ????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1426', 'LNG_BATCH2', 'class', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1427', 'LNG_SELECT_DAY', 'Chose Day', '????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1428', 'LNG_ADD_NEW_EXAM', 'Add New Exam', '????? ?????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1429', 'LNG_CLICK_ON_SUBJECT_TO_ENTER_MARKS', 'Click on courses to enter marks', '???? ??? ????? ?????? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1430', 'LNG_TRANSFER', 'Transfer', '???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1431', 'LNG_CLICK_ON_RESULT_TO_VIEW', 'Click on result to view exam detail', '???? ??? ??????? ???? ?????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1432', 'LNG_CLICK_ON_RESULT_TO_VIEW', 'Click on result to view exam details', '???? ??? ??????? ???? ?????? ????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1433', 'LNG_EXAM_RESULT_NOT_PUBLISHED', 'Exam result not published..', '????? ?????? ?? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1434', 'LNG_EXAM_SCHEDULE_NOT_PUBLISHED', 'Exam schedule not published..', '???? ?????? ?? ???? ');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1435', 'LNG_EXAM_REPORT', 'Exam Report', '?????? ???????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1436', 'LNG_STUDENT_NAME', 'Student Name', '???? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1437', 'LNG_SEARCH_FROM_OTHER', 'Search From Other', '????? ?? ????? ??');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1438', 'LNG_NO_STUDENT_OF_THIS_ID_NUMBER', 'No Student available of this ID Number', '?? ???? ???? ?? ??? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1439', 'LNG_REQUEST_FOR_MORE_INFO', 'Request for more Info', '??? ?????? ??? ???? ?? ?????????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1440', 'LNG_SEARCH_OTHER_STUDENT', 'Search Student from other school', '??? ?????? ?? ????? ????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1441', 'LNG_SEND_REQUEST', 'Send Request', '????? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1442', 'LNG_REQUEST_FOR_STUDENT', 'Request for Student', '??? ?????? ??? ??????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1443', 'LNG_SECONT_SEM_START_DATE', 'Second Sem Start Date', '?????? ????? ????? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1444', 'LNG_REQUEST_SUCCESSFULLY_SEND', 'Request Successfully Send', '?? ???? ????? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1445', 'LNG_ACCEPT', 'Accept', '????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1446', 'LNG_DECLINE', 'Decline', '?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1447', 'LNG_SEMESTER', 'Semester', '??? ?????');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1448', 'LNG_STUDENT_REQUEST', 'Student Request', '???? ???');
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1449', 'LNG_RESULT', 'Result', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1450', 'LNG_STUDENT_MARKS', 'Student Marks', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1451', 'LNG_SELECT_A_STUDENT', 'Select a Student', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1452', 'LNG_SEND_MESSAGE_TEACHER', 'Send Message', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1453', 'LNG_MSG_SUBJECT', 'Message Subject', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1454', 'LNG_STATUS_UPDATED', 'Status Updated', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1455', 'LNG_SEND_MESSAGE', 'Send Message', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1456', 'LNG_SEND_MESSAGE_TO_CLASS_TEACHER', 'Send Message to Class Teacher', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1457', 'LNG_SEND_TO', 'Send To', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1458', 'LNG_MESSAGE_SUCCESSFULLY_SEND', 'Message Successfully Send', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1459', 'LNG_GENERATE_FINAL_RESULT', 'Generate Final Result', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1460', 'LNG_GENERATES_FINAL_RESULT_OF_SEMESTER', 'Generates Final Result of Classes Semester Wise', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1461', 'LNG_TOTAL_MARKS_SCORES', 'Total Marks Scored', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1462', 'LNG_SELECT_SEMESTER', 'Select Semester', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1463', 'LNG_GENERATE_FINAL_REPORT', 'Generate Final Report', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1464', 'LNG_REASON', 'Reason', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1465', 'LNG_STUDENT_REPORT', 'Student Report', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1466', 'LNG_DETAILED_REPORT_FOR', 'Detailed report for', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1467', 'LNG_SELECT_YEAR', 'Select Year', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1468', 'LNG_CLASS_RANK', 'Class Rank :', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1469', 'LNG_TOTAL_ABSENTS', 'Total Absents :', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1470', 'LNG_NO_RIGHT_TO_CREATE_EXAM', 'You Have No Rights to Create Exams. .', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1471', 'LNG_VIEW_BATCH_TIMETABLE', 'View Class Timetable', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1472', 'LNG_DELETE_STUDENT', 'Delete student', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1473', 'LNG_DELETE_STUDENT_TEXT_1', 'Completely delete student\'s records from the school\'s databases. Use this option only if you created the student record by accident and want to remove it completely.', NULL);
insert into `label_values` (`id`, `lb`, `en_value`, `ar_value`) values ('1474', 'LNG_DELETE_STUDENT_TEXT_2', '(Warning: All records will be deleted for the student and cannot be recovered.)', NULL);

drop table if exists `period_entries`;
CREATE TABLE `period_entries` (
  `id` int(11) NOT NULL auto_increment,
  `month_date` date default NULL,
  `batch_id` int(11) default NULL,
  `schoolid` int(11) NOT NULL,
  `subject_id` int(11) default NULL,
  `class_timing_id` int(11) default NULL,
  `employee_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_period_entries_on_month_date_and_batch_id` (`month_date`,`batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2223 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2', '2011-11-21', '5', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('4', '2011-11-28', '5', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('6', '2011-12-05', '5', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('8', '2011-12-12', '5', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('10', '2011-11-16', '5', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('11', '2011-11-23', '5', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('12', '2011-11-30', '5', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('13', '2011-12-07', '5', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('14', '2011-12-14', '5', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('15', '2011-11-09', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('19', '2011-11-14', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('20', '2011-11-15', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('21', '2011-11-16', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('25', '2011-11-21', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('26', '2011-11-22', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('27', '2011-11-23', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('31', '2011-11-28', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('32', '2011-11-29', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('33', '2011-11-30', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('37', '2011-12-05', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('38', '2011-12-06', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('39', '2011-12-07', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('43', '2011-12-12', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('44', '2011-12-13', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('45', '2011-12-14', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('49', '2011-12-19', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('50', '2011-12-20', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('51', '2011-12-21', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('55', '2011-12-26', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('56', '2011-12-27', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('57', '2011-12-28', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('61', '2012-01-02', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('62', '2012-01-03', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('63', '2012-01-04', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('67', '2012-01-09', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('68', '2012-01-10', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('69', '2012-01-11', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('73', '2012-01-16', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('74', '2012-01-17', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('75', '2012-01-18', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('79', '2012-01-23', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('80', '2012-01-24', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('81', '2012-01-25', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('85', '2012-01-30', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('86', '2012-01-31', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('87', '2012-02-01', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('91', '2012-02-06', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('92', '2012-02-07', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('93', '2012-02-08', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('97', '2012-02-13', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('98', '2012-02-14', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('99', '2012-02-15', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('103', '2012-02-20', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('104', '2012-02-21', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('105', '2012-02-22', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('109', '2012-02-27', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('110', '2012-02-28', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('111', '2012-02-29', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('115', '2012-03-05', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('116', '2012-03-06', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('117', '2012-03-07', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('121', '2012-03-12', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('122', '2012-03-13', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('123', '2012-03-14', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('127', '2012-03-19', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('128', '2012-03-20', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('129', '2012-03-21', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('133', '2012-03-26', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('134', '2012-03-27', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('135', '2012-03-28', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('139', '2012-04-02', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('140', '2012-04-03', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('141', '2012-04-04', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('145', '2012-04-09', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('146', '2012-04-10', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('147', '2012-04-11', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('151', '2012-04-16', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('152', '2012-04-17', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('153', '2012-04-18', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('157', '2012-04-23', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('158', '2012-04-24', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('159', '2012-04-25', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('163', '2012-04-30', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('164', '2012-05-01', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('165', '2012-05-02', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('169', '2012-05-07', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('170', '2012-05-08', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('171', '2012-05-09', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('175', '2012-05-14', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('176', '2012-05-15', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('177', '2012-05-16', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('181', '2012-05-21', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('182', '2012-05-22', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('183', '2012-05-23', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('187', '2012-05-28', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('188', '2012-05-29', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('189', '2012-05-30', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('193', '2012-06-04', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('194', '2012-06-05', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('195', '2012-06-06', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('199', '2012-06-11', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('200', '2012-06-12', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('201', '2012-06-13', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('205', '2012-06-18', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('206', '2012-06-19', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('207', '2012-06-20', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('211', '2012-06-25', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('212', '2012-06-26', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('213', '2012-06-27', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('217', '2012-07-02', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('218', '2012-07-03', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('219', '2012-07-04', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('223', '2012-07-09', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('224', '2012-07-10', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('225', '2012-07-11', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('229', '2012-07-16', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('230', '2012-07-17', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('231', '2012-07-18', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('235', '2012-07-23', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('236', '2012-07-24', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('237', '2012-07-25', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('241', '2012-07-30', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('242', '2012-07-31', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('243', '2012-08-01', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('247', '2012-08-06', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('248', '2012-08-07', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('249', '2012-08-08', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('253', '2012-08-13', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('254', '2012-08-14', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('255', '2012-08-15', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('259', '2012-08-20', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('260', '2012-08-21', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('261', '2012-08-22', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('265', '2012-08-27', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('266', '2012-08-28', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('267', '2012-08-29', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('271', '2012-09-03', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('272', '2012-09-04', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('273', '2012-09-05', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('277', '2012-09-10', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('278', '2012-09-11', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('279', '2012-09-12', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('283', '2012-09-17', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('284', '2012-09-18', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('285', '2012-09-19', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('289', '2012-09-24', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('290', '2012-09-25', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('291', '2012-09-26', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('295', '2012-10-01', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('296', '2012-10-02', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('297', '2012-10-03', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('301', '2012-10-08', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('302', '2012-10-09', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('303', '2012-10-10', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('307', '2012-10-15', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('308', '2012-10-16', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('309', '2012-10-17', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('313', '2012-10-22', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('314', '2012-10-23', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('315', '2012-10-24', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('319', '2012-10-29', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('320', '2012-10-30', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('321', '2012-10-31', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('325', '2012-11-05', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('326', '2012-11-06', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('327', '2012-11-07', '4', '0', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('330', '2011-11-15', '5', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('331', '2011-11-17', '5', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('332', '2011-11-18', '5', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('333', '2011-11-22', '5', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('334', '2011-11-24', '5', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('335', '2011-11-25', '5', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('336', '2011-11-29', '5', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('337', '2011-12-01', '5', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('338', '2011-12-02', '5', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('339', '2011-12-06', '5', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('340', '2011-12-08', '5', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('341', '2011-12-09', '5', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('342', '2011-12-13', '5', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('343', '2011-11-16', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('344', '2011-11-18', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('345', '2011-11-21', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('346', '2011-11-23', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('347', '2011-11-25', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('348', '2011-11-28', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('349', '2011-11-30', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('350', '2011-12-02', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('351', '2011-12-05', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('352', '2011-12-07', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('353', '2011-12-09', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('354', '2011-12-12', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('355', '2011-12-14', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('356', '2011-12-16', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('357', '2011-12-19', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('358', '2011-12-21', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('359', '2011-12-23', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('360', '2011-12-26', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('361', '2011-12-28', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('362', '2011-12-30', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('363', '2012-01-02', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('364', '2012-01-04', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('365', '2012-01-06', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('366', '2012-01-09', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('367', '2012-01-11', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('368', '2012-01-13', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('369', '2012-01-16', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('370', '2012-01-18', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('371', '2012-01-20', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('372', '2012-01-23', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('373', '2012-01-25', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('374', '2012-01-27', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('375', '2012-01-30', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('376', '2012-02-01', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('377', '2012-02-03', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('378', '2012-02-06', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('379', '2012-02-08', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('380', '2012-02-10', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('381', '2012-02-13', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('382', '2012-02-15', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('383', '2012-02-17', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('384', '2012-02-20', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('385', '2012-02-22', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('386', '2012-02-24', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('387', '2012-02-27', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('388', '2012-02-29', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('389', '2012-03-02', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('390', '2012-03-05', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('391', '2012-03-07', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('392', '2012-03-09', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('393', '2012-03-12', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('394', '2012-03-14', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('395', '2012-03-16', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('396', '2012-03-19', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('397', '2012-03-21', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('398', '2012-03-23', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('399', '2012-03-26', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('400', '2012-03-28', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('401', '2012-03-30', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('402', '2012-04-02', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('403', '2012-04-04', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('404', '2012-04-06', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('405', '2012-04-09', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('406', '2012-04-11', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('407', '2012-04-13', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('408', '2012-04-16', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('409', '2012-04-18', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('410', '2012-04-20', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('411', '2012-04-23', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('412', '2012-04-25', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('413', '2012-04-27', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('414', '2012-04-30', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('415', '2012-05-02', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('416', '2012-05-04', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('417', '2012-05-07', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('418', '2012-05-09', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('419', '2012-05-11', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('420', '2012-05-14', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('421', '2012-05-16', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('422', '2012-05-18', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('423', '2012-05-21', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('424', '2012-05-23', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('425', '2012-05-25', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('426', '2012-05-28', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('427', '2012-05-30', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('428', '2012-06-01', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('429', '2012-06-04', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('430', '2012-06-06', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('431', '2012-06-08', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('432', '2012-06-11', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('433', '2012-06-13', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('434', '2012-06-15', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('435', '2012-06-18', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('436', '2012-06-20', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('437', '2012-06-22', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('438', '2012-06-25', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('439', '2012-06-27', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('440', '2012-06-29', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('441', '2012-07-02', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('442', '2012-07-04', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('443', '2012-07-06', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('444', '2012-07-09', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('445', '2012-07-11', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('446', '2012-07-13', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('447', '2012-07-16', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('448', '2012-07-18', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('449', '2012-07-20', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('450', '2012-07-23', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('451', '2012-07-25', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('452', '2012-07-27', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('453', '2012-07-30', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('454', '2012-08-01', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('455', '2012-08-03', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('456', '2012-08-06', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('457', '2012-08-08', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('458', '2012-08-10', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('459', '2012-08-13', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('460', '2012-08-15', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('461', '2012-08-17', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('462', '2012-08-20', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('463', '2012-08-22', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('464', '2012-08-24', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('465', '2012-08-27', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('466', '2012-08-29', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('467', '2012-08-31', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('468', '2012-09-03', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('469', '2012-09-05', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('470', '2012-09-07', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('471', '2012-09-10', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('472', '2012-09-12', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('473', '2012-09-14', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('474', '2012-09-17', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('475', '2012-09-19', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('476', '2012-09-21', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('477', '2012-09-24', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('478', '2012-09-26', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('479', '2012-09-28', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('480', '2012-10-01', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('481', '2012-10-03', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('482', '2012-10-05', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('483', '2012-10-08', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('484', '2012-10-10', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('485', '2012-10-12', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('486', '2012-10-15', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('487', '2012-10-17', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('488', '2012-10-19', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('489', '2012-10-22', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('490', '2012-10-24', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('491', '2011-11-15', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('493', '2011-11-22', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('495', '2011-11-29', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('497', '2011-12-06', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('499', '2011-12-13', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('501', '2011-12-20', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('503', '2011-12-27', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('505', '2012-01-03', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('507', '2012-01-10', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('509', '2012-01-17', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('511', '2012-01-24', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('513', '2012-01-31', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('515', '2012-02-07', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('517', '2012-02-14', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('519', '2012-02-21', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('521', '2012-02-28', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('523', '2012-03-06', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('525', '2012-03-13', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('527', '2012-03-20', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('529', '2012-03-27', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('531', '2012-04-03', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('533', '2012-04-10', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('535', '2012-04-17', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('537', '2012-04-24', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('539', '2012-05-01', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('541', '2012-05-08', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('543', '2012-05-15', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('545', '2012-05-22', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('547', '2012-05-29', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('549', '2012-06-05', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('551', '2012-06-12', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('553', '2012-06-19', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('555', '2012-06-26', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('557', '2012-07-03', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('559', '2012-07-10', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('561', '2012-07-17', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('563', '2012-07-24', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('565', '2012-07-31', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('567', '2012-08-07', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('569', '2012-08-14', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('571', '2012-08-21', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('573', '2012-08-28', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('575', '2012-09-04', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('577', '2012-09-11', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('579', '2012-09-18', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('581', '2012-09-25', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('583', '2012-10-02', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('585', '2012-10-09', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('587', '2012-10-16', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('589', '2012-10-23', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('591', '2011-11-17', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('592', '2011-11-24', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('593', '2011-12-01', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('594', '2011-12-08', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('595', '2011-12-15', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('596', '2011-12-22', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('597', '2011-12-29', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('598', '2012-01-05', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('599', '2012-01-12', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('600', '2012-01-19', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('601', '2012-01-26', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('602', '2012-02-02', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('603', '2012-02-09', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('604', '2012-02-16', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('605', '2012-02-23', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('606', '2012-03-01', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('607', '2012-03-08', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('608', '2012-03-15', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('609', '2012-03-22', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('610', '2012-03-29', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('611', '2012-04-05', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('612', '2012-04-12', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('613', '2012-04-19', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('614', '2012-04-26', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('615', '2012-05-03', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('616', '2012-05-10', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('617', '2012-05-17', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('618', '2012-05-24', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('619', '2012-05-31', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('620', '2012-06-07', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('621', '2012-06-14', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('622', '2012-06-21', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('623', '2012-06-28', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('624', '2012-07-05', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('625', '2012-07-12', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('626', '2012-07-19', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('627', '2012-07-26', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('628', '2012-08-02', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('629', '2012-08-09', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('630', '2012-08-16', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('631', '2012-08-23', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('632', '2012-08-30', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('633', '2012-09-06', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('634', '2012-09-13', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('635', '2012-09-20', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('636', '2012-09-27', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('637', '2012-10-04', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('638', '2012-10-11', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('639', '2012-10-18', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('640', '2012-10-25', '7', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('641', '2011-11-10', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('642', '2011-11-11', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('643', '2011-11-17', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('644', '2011-11-18', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('645', '2011-11-24', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('646', '2011-11-25', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('647', '2011-12-01', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('648', '2011-12-02', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('649', '2011-12-08', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('650', '2011-12-09', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('651', '2011-12-15', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('652', '2011-12-16', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('653', '2011-12-22', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('654', '2011-12-23', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('655', '2011-12-29', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('656', '2011-12-30', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('657', '2012-01-05', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('658', '2012-01-06', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('659', '2012-01-12', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('660', '2012-01-13', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('661', '2012-01-19', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('662', '2012-01-20', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('663', '2012-01-26', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('664', '2012-01-27', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('665', '2012-02-02', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('666', '2012-02-03', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('667', '2012-02-09', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('668', '2012-02-10', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('669', '2012-02-16', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('670', '2012-02-17', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('671', '2012-02-23', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('672', '2012-02-24', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('673', '2012-03-01', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('674', '2012-03-02', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('675', '2012-03-08', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('676', '2012-03-09', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('677', '2012-03-15', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('678', '2012-03-16', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('679', '2012-03-22', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('680', '2012-03-23', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('681', '2012-03-29', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('682', '2012-03-30', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('683', '2012-04-05', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('684', '2012-04-06', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('685', '2012-04-12', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('686', '2012-04-13', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('687', '2012-04-19', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('688', '2012-04-20', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('689', '2012-04-26', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('690', '2012-04-27', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('691', '2012-05-03', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('692', '2012-05-04', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('693', '2012-05-10', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('694', '2012-05-11', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('695', '2012-05-17', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('696', '2012-05-18', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('697', '2012-05-24', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('698', '2012-05-25', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('699', '2012-05-31', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('700', '2012-06-01', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('701', '2012-06-07', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('702', '2012-06-08', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('703', '2012-06-14', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('704', '2012-06-15', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('705', '2012-06-21', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('706', '2012-06-22', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('707', '2012-06-28', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('708', '2012-06-29', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('709', '2012-07-05', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('710', '2012-07-06', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('711', '2012-07-12', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('712', '2012-07-13', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('713', '2012-07-19', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('714', '2012-07-20', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('715', '2012-07-26', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('716', '2012-07-27', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('717', '2012-08-02', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('718', '2012-08-03', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('719', '2012-08-09', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('720', '2012-08-10', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('721', '2012-08-16', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('722', '2012-08-17', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('723', '2012-08-23', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('724', '2012-08-24', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('725', '2012-08-30', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('726', '2012-08-31', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('727', '2012-09-06', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('728', '2012-09-07', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('729', '2012-09-13', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('730', '2012-09-14', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('731', '2012-09-20', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('732', '2012-09-21', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('733', '2012-09-27', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('734', '2012-09-28', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('735', '2012-10-04', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('736', '2012-10-05', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('737', '2012-10-11', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('738', '2012-10-12', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('739', '2012-10-18', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('740', '2012-10-19', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('741', '2012-10-25', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('742', '2012-10-26', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('743', '2012-11-01', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('744', '2012-11-02', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('745', '2012-11-08', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('746', '2012-11-09', '4', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('747', '2011-07-05', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('748', '2011-07-07', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('749', '2011-07-09', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('750', '2011-07-10', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('751', '2011-07-12', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('752', '2011-07-14', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('753', '2011-07-16', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('754', '2011-07-17', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('755', '2011-07-19', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('756', '2011-07-21', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('757', '2011-07-23', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('758', '2011-07-24', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('759', '2011-07-26', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('760', '2011-07-28', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('761', '2011-07-30', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('762', '2011-07-31', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('763', '2011-08-02', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('764', '2011-08-04', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('765', '2011-08-06', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('766', '2011-08-07', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('767', '2011-08-09', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('768', '2011-08-11', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('769', '2011-08-13', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('770', '2011-08-14', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('771', '2011-08-16', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('772', '2011-08-18', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('773', '2011-08-20', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('774', '2011-08-21', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('775', '2011-08-23', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('776', '2011-08-25', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('777', '2011-08-27', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('778', '2011-08-28', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('779', '2011-08-30', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('780', '2011-09-01', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('781', '2011-09-03', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('782', '2011-09-04', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('783', '2011-09-06', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('784', '2011-09-08', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('785', '2011-09-10', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('786', '2011-09-11', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('787', '2011-09-13', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('788', '2011-09-15', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('789', '2011-09-17', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('790', '2011-09-18', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('791', '2011-09-20', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('792', '2011-09-22', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('793', '2011-09-24', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('794', '2011-09-25', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('795', '2011-09-27', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('796', '2011-09-29', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('797', '2011-10-01', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('798', '2011-10-02', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('799', '2011-10-04', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('800', '2011-10-06', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('801', '2011-10-08', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('802', '2011-10-09', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('803', '2011-10-11', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('804', '2011-10-13', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('805', '2011-10-15', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('806', '2011-10-16', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('807', '2011-10-18', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('808', '2011-10-20', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('809', '2011-10-22', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('810', '2011-10-23', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('811', '2011-10-25', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('812', '2011-10-27', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('813', '2011-10-29', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('814', '2011-10-30', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('815', '2011-11-01', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('816', '2011-11-03', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('817', '2011-11-05', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('818', '2011-11-06', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('819', '2011-11-08', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('820', '2011-11-10', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('821', '2011-11-12', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('822', '2011-11-13', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('823', '2011-11-15', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('824', '2011-11-17', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('825', '2011-11-19', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('826', '2011-11-20', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('827', '2011-11-22', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('828', '2011-11-24', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('829', '2011-11-26', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('830', '2011-11-27', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('831', '2011-11-29', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('832', '2011-12-01', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('833', '2011-12-03', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('834', '2011-12-04', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('835', '2011-12-06', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('836', '2011-12-08', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('837', '2011-12-10', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('838', '2011-12-11', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('839', '2011-12-13', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('840', '2011-12-15', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('841', '2011-12-17', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('842', '2011-12-18', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('843', '2011-12-20', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('844', '2011-12-22', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('845', '2011-12-24', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('846', '2011-12-25', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('847', '2011-12-27', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('848', '2011-12-29', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('849', '2011-12-31', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('850', '2012-01-01', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('851', '2012-01-03', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('852', '2012-01-05', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('853', '2012-01-07', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('854', '2012-01-08', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('855', '2012-01-10', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('856', '2012-01-12', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('857', '2012-01-14', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('858', '2012-01-15', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('859', '2012-01-17', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('860', '2012-01-19', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('861', '2012-01-21', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('862', '2012-01-22', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('863', '2012-01-24', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('864', '2012-01-26', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('865', '2012-01-28', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('866', '2012-01-29', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('867', '2012-01-31', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('868', '2012-02-02', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('869', '2012-02-04', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('870', '2012-02-05', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('871', '2012-02-07', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('872', '2012-02-09', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('873', '2012-02-11', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('874', '2012-02-12', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('875', '2012-02-14', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('876', '2012-02-16', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('877', '2012-02-18', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('878', '2012-02-19', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('879', '2012-02-21', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('880', '2012-02-23', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('881', '2012-02-25', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('882', '2012-02-26', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('883', '2012-02-28', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('884', '2012-03-01', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('885', '2012-03-03', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('886', '2012-03-04', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('887', '2012-03-06', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('888', '2012-03-08', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('889', '2012-03-10', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('890', '2012-03-11', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('891', '2012-03-13', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('892', '2012-03-15', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('893', '2012-03-17', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('894', '2012-03-18', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('895', '2012-03-20', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('896', '2012-03-22', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('897', '2012-03-24', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('898', '2012-03-25', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('899', '2012-03-27', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('900', '2012-03-29', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('901', '2012-03-31', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('902', '2012-04-01', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('903', '2012-04-03', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('904', '2012-04-05', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('905', '2012-04-07', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('906', '2012-04-08', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('907', '2012-04-10', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('908', '2012-04-12', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('909', '2012-04-14', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('910', '2012-04-15', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('911', '2012-04-17', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('912', '2012-04-19', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('913', '2012-04-21', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('914', '2012-04-22', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('915', '2012-04-24', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('916', '2012-04-26', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('917', '2012-04-28', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('918', '2012-04-29', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('919', '2012-05-01', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('920', '2012-05-03', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('921', '2012-05-05', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('922', '2012-05-06', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('923', '2012-05-08', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('924', '2012-05-10', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('925', '2012-05-12', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('926', '2012-05-13', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('927', '2012-05-15', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('928', '2012-05-17', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('929', '2012-05-19', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('930', '2012-05-20', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('931', '2012-05-22', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('932', '2012-05-24', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('933', '2012-05-26', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('934', '2012-05-27', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('935', '2012-05-29', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('936', '2012-05-31', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('937', '2012-06-02', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('938', '2012-06-03', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('939', '2012-06-05', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('940', '2012-06-07', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('941', '2012-06-09', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('942', '2012-06-10', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('943', '2012-06-12', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('944', '2012-06-14', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('945', '2012-06-16', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('946', '2012-06-17', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('947', '2012-06-19', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('948', '2012-06-21', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('949', '2012-06-23', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('950', '2012-06-24', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('951', '2012-06-26', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('952', '2012-06-28', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('953', '2012-06-30', '9', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('954', '2011-01-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('955', '2011-01-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('956', '2011-01-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('957', '2011-01-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('958', '2011-01-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('959', '2011-01-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('960', '2011-01-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('961', '2011-01-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('962', '2011-01-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('963', '2011-01-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('964', '2011-01-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('965', '2011-01-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('966', '2011-01-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('967', '2011-01-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('968', '2011-01-31', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('969', '2011-02-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('970', '2011-02-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('971', '2011-02-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('972', '2011-02-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('973', '2011-02-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('974', '2011-02-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('975', '2011-02-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('976', '2011-02-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('977', '2011-02-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('978', '2011-02-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('979', '2011-02-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('980', '2011-02-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('981', '2011-02-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('982', '2011-02-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('983', '2011-02-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('984', '2011-02-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('985', '2011-02-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('986', '2011-02-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('987', '2011-02-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('988', '2011-02-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('989', '2011-03-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('990', '2011-03-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('991', '2011-03-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('992', '2011-03-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('993', '2011-03-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('994', '2011-03-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('995', '2011-03-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('996', '2011-03-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('997', '2011-03-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('998', '2011-03-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('999', '2011-03-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1000', '2011-03-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1001', '2011-03-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1002', '2011-03-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1003', '2011-03-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1004', '2011-03-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1005', '2011-03-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1006', '2011-03-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1007', '2011-03-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1008', '2011-03-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1009', '2011-03-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1010', '2011-03-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1011', '2011-03-31', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1012', '2011-04-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1013', '2011-04-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1014', '2011-04-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1015', '2011-04-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1016', '2011-04-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1017', '2011-04-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1018', '2011-04-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1019', '2011-04-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1020', '2011-04-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1021', '2011-04-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1022', '2011-04-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1023', '2011-04-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1024', '2011-04-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1025', '2011-04-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1026', '2011-04-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1027', '2011-04-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1028', '2011-04-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1029', '2011-04-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1030', '2011-04-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1031', '2011-04-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1032', '2011-04-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1033', '2011-05-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1034', '2011-05-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1035', '2011-05-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1036', '2011-05-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1037', '2011-05-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1038', '2011-05-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1039', '2011-05-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1040', '2011-05-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1041', '2011-05-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1042', '2011-05-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1043', '2011-05-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1044', '2011-05-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1045', '2011-05-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1046', '2011-05-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1047', '2011-05-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1048', '2011-05-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1049', '2011-05-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1050', '2011-05-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1051', '2011-05-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1052', '2011-05-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1053', '2011-05-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1054', '2011-05-31', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1055', '2011-06-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1056', '2011-06-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1057', '2011-06-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1058', '2011-06-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1059', '2011-06-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1060', '2011-06-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1061', '2011-06-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1062', '2011-06-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1063', '2011-06-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1064', '2011-06-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1065', '2011-06-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1066', '2011-06-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1067', '2011-06-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1068', '2011-06-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1069', '2011-06-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1070', '2011-06-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1071', '2011-06-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1072', '2011-06-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1073', '2011-06-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1074', '2011-06-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1075', '2011-06-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1076', '2011-06-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1077', '2011-07-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1078', '2011-07-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1079', '2011-07-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1080', '2011-07-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1081', '2011-07-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1082', '2011-07-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1083', '2011-07-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1084', '2011-07-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1085', '2011-07-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1086', '2011-07-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1087', '2011-07-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1088', '2011-07-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1089', '2011-07-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1090', '2011-07-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1091', '2011-07-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1092', '2011-07-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1093', '2011-07-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1094', '2011-07-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1095', '2011-07-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1096', '2011-07-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1097', '2011-07-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1098', '2011-08-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1099', '2011-08-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1100', '2011-08-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1101', '2011-08-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1102', '2011-08-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1103', '2011-08-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1104', '2011-08-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1105', '2011-08-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1106', '2011-08-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1107', '2011-08-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1108', '2011-08-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1109', '2011-08-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1110', '2011-08-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1111', '2011-08-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1112', '2011-08-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1113', '2011-08-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1114', '2011-08-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1115', '2011-08-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1116', '2011-08-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1117', '2011-08-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1118', '2011-08-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1119', '2011-08-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1120', '2011-08-31', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1121', '2011-09-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1122', '2011-09-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1123', '2011-09-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1124', '2011-09-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1125', '2011-09-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1126', '2011-09-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1127', '2011-09-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1128', '2011-09-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1129', '2011-09-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1130', '2011-09-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1131', '2011-09-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1132', '2011-09-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1133', '2011-09-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1134', '2011-09-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1135', '2011-09-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1136', '2011-09-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1137', '2011-09-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1138', '2011-09-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1139', '2011-09-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1140', '2011-09-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1141', '2011-09-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1142', '2011-09-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1143', '2011-10-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1144', '2011-10-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1145', '2011-10-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1146', '2011-10-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1147', '2011-10-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1148', '2011-10-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1149', '2011-10-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1150', '2011-10-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1151', '2011-10-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1152', '2011-10-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1153', '2011-10-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1154', '2011-10-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1155', '2011-10-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1156', '2011-10-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1157', '2011-10-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1158', '2011-10-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1159', '2011-10-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1160', '2011-10-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1161', '2011-10-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1162', '2011-10-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1163', '2011-10-31', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1164', '2011-11-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1165', '2011-11-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1166', '2011-11-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1167', '2011-11-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1168', '2011-11-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1169', '2011-11-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1170', '2011-11-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1171', '2011-11-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1172', '2011-11-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1173', '2011-11-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1174', '2011-11-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1175', '2011-11-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1176', '2011-11-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1177', '2011-11-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1178', '2011-11-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1179', '2011-11-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1180', '2011-11-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1181', '2011-11-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1182', '2011-11-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1183', '2011-11-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1184', '2011-11-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1185', '2011-11-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1186', '2011-12-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1187', '2011-12-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1188', '2011-12-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1189', '2011-12-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1190', '2011-12-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1191', '2011-12-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1192', '2011-12-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1193', '2011-12-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1194', '2011-12-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1195', '2011-12-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1196', '2011-12-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1197', '2011-12-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1198', '2011-12-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1199', '2011-12-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1200', '2011-12-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1201', '2011-12-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1202', '2011-12-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1203', '2011-12-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1204', '2011-12-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1205', '2011-12-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1206', '2011-12-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1207', '2011-12-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1208', '2012-01-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1209', '2012-01-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1210', '2012-01-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1211', '2012-01-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1212', '2012-01-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1213', '2012-01-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1214', '2012-01-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1215', '2012-01-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1216', '2012-01-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1217', '2012-01-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1218', '2012-01-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1219', '2012-01-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1220', '2012-01-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1221', '2012-01-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1222', '2012-01-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1223', '2012-01-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1224', '2012-01-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1225', '2012-01-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1226', '2012-01-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1227', '2012-01-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1228', '2012-01-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1229', '2012-01-31', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1230', '2012-02-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1231', '2012-02-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1232', '2012-02-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1233', '2012-02-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1234', '2012-02-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1235', '2012-02-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1236', '2012-02-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1237', '2012-02-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1238', '2012-02-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1239', '2012-02-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1240', '2012-02-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1241', '2012-02-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1242', '2012-02-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1243', '2012-02-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1244', '2012-02-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1245', '2012-02-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1246', '2012-02-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1247', '2012-02-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1248', '2012-02-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1249', '2012-02-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1250', '2012-02-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1251', '2012-03-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1252', '2012-03-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1253', '2012-03-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1254', '2012-03-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1255', '2012-03-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1256', '2012-03-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1257', '2012-03-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1258', '2012-03-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1259', '2012-03-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1260', '2012-03-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1261', '2012-03-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1262', '2012-03-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1263', '2012-03-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1264', '2012-03-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1265', '2012-03-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1266', '2012-03-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1267', '2012-03-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1268', '2012-03-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1269', '2012-03-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1270', '2012-03-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1271', '2012-03-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1272', '2012-03-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1273', '2012-04-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1274', '2012-04-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1275', '2012-04-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1276', '2012-04-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1277', '2012-04-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1278', '2012-04-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1279', '2012-04-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1280', '2012-04-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1281', '2012-04-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1282', '2012-04-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1283', '2012-04-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1284', '2012-04-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1285', '2012-04-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1286', '2012-04-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1287', '2012-04-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1288', '2012-04-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1289', '2012-04-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1290', '2012-04-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1291', '2012-04-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1292', '2012-04-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1293', '2012-04-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1294', '2012-05-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1295', '2012-05-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1296', '2012-05-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1297', '2012-05-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1298', '2012-05-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1299', '2012-05-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1300', '2012-05-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1301', '2012-05-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1302', '2012-05-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1303', '2012-05-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1304', '2012-05-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1305', '2012-05-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1306', '2012-05-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1307', '2012-05-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1308', '2012-05-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1309', '2012-05-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1310', '2012-05-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1311', '2012-05-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1312', '2012-05-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1313', '2012-05-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1314', '2012-05-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1315', '2012-05-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1316', '2012-05-31', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1317', '2012-06-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1318', '2012-06-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1319', '2012-06-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1320', '2012-06-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1321', '2012-06-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1322', '2012-06-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1323', '2012-06-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1324', '2012-06-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1325', '2012-06-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1326', '2012-06-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1327', '2012-06-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1328', '2012-06-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1329', '2012-06-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1330', '2012-06-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1331', '2012-06-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1332', '2012-06-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1333', '2012-06-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1334', '2012-06-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1335', '2012-06-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1336', '2012-06-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1337', '2012-06-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1338', '2012-07-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1339', '2012-07-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1340', '2012-07-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1341', '2012-07-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1342', '2012-07-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1343', '2012-07-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1344', '2012-07-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1345', '2012-07-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1346', '2012-07-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1347', '2012-07-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1348', '2012-07-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1349', '2012-07-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1350', '2012-07-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1351', '2012-07-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1352', '2012-07-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1353', '2012-07-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1354', '2012-07-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1355', '2012-07-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1356', '2012-07-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1357', '2012-07-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1358', '2012-07-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1359', '2012-07-31', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1360', '2012-08-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1361', '2012-08-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1362', '2012-08-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1363', '2012-08-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1364', '2012-08-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1365', '2012-08-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1366', '2012-08-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1367', '2012-08-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1368', '2012-08-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1369', '2012-08-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1370', '2012-08-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1371', '2012-08-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1372', '2012-08-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1373', '2012-08-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1374', '2012-08-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1375', '2012-08-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1376', '2012-08-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1377', '2012-08-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1378', '2012-08-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1379', '2012-08-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1380', '2012-08-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1381', '2012-08-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1382', '2012-08-31', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1383', '2012-09-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1384', '2012-09-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1385', '2012-09-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1386', '2012-09-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1387', '2012-09-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1388', '2012-09-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1389', '2012-09-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1390', '2012-09-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1391', '2012-09-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1392', '2012-09-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1393', '2012-09-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1394', '2012-09-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1395', '2012-09-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1396', '2012-09-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1397', '2012-09-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1398', '2012-09-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1399', '2012-09-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1400', '2012-09-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1401', '2012-09-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1402', '2012-09-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1403', '2012-10-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1404', '2012-10-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1405', '2012-10-03', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1406', '2012-10-04', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1407', '2012-10-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1408', '2012-10-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1409', '2012-10-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1410', '2012-10-10', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1411', '2012-10-11', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1412', '2012-10-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1413', '2012-10-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1414', '2012-10-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1415', '2012-10-17', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1416', '2012-10-18', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1417', '2012-10-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1418', '2012-10-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1419', '2012-10-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1420', '2012-10-24', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1421', '2012-10-25', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1422', '2012-10-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1423', '2012-10-29', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1424', '2012-10-30', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1425', '2012-10-31', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1426', '2012-11-01', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1427', '2012-11-02', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1428', '2012-11-05', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1429', '2012-11-06', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1430', '2012-11-07', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1431', '2012-11-08', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1432', '2012-11-09', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1433', '2012-11-12', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1434', '2012-11-13', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1435', '2012-11-14', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1436', '2012-11-15', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1437', '2012-11-16', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1438', '2012-11-19', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1439', '2012-11-20', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1440', '2012-11-21', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1441', '2012-11-22', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1442', '2012-11-23', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1443', '2012-11-26', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1444', '2012-11-27', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1445', '2012-11-28', '2', '1', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1446', '2012-01-02', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1447', '2012-01-03', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1448', '2012-01-04', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1449', '2012-01-05', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1450', '2012-01-06', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1451', '2012-01-09', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1452', '2012-01-10', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1453', '2012-01-11', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1454', '2012-01-12', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1455', '2012-01-13', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1456', '2012-01-16', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1457', '2012-01-17', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1458', '2012-01-18', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1459', '2012-01-19', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1460', '2012-01-20', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1461', '2012-01-23', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1462', '2012-01-24', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1463', '2012-01-25', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1464', '2012-01-26', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1465', '2012-01-27', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1466', '2012-01-30', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1467', '2012-01-31', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1468', '2012-02-01', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1469', '2012-02-02', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1470', '2012-02-03', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1471', '2012-02-06', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1472', '2012-02-07', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1473', '2012-02-08', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1474', '2012-02-09', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1475', '2012-02-10', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1476', '2012-02-13', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1477', '2012-02-14', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1478', '2012-02-15', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1479', '2012-02-16', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1480', '2012-02-17', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1481', '2012-02-20', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1482', '2012-02-21', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1483', '2012-02-22', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1484', '2012-02-23', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1485', '2012-02-24', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1486', '2012-02-27', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1487', '2012-02-28', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1488', '2012-02-29', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1489', '2012-03-01', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1490', '2012-03-02', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1491', '2012-03-05', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1492', '2012-03-06', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1493', '2012-03-07', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1494', '2012-03-08', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1495', '2012-03-09', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1496', '2012-03-12', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1497', '2012-03-13', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1498', '2012-03-14', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1499', '2012-03-15', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1500', '2012-03-16', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1501', '2012-03-19', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1502', '2012-03-20', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1503', '2012-03-21', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1504', '2012-03-22', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1505', '2012-03-23', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1506', '2012-03-26', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1507', '2012-03-27', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1508', '2012-03-28', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1509', '2012-03-29', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1510', '2012-03-30', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1511', '2012-04-02', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1512', '2012-04-03', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1513', '2012-04-04', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1514', '2012-04-05', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1515', '2012-04-06', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1516', '2012-04-09', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1517', '2012-04-10', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1518', '2012-04-11', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1519', '2012-04-12', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1520', '2012-04-13', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1521', '2012-04-16', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1522', '2012-04-17', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1523', '2012-04-18', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1524', '2012-04-19', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1525', '2012-04-20', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1526', '2012-04-23', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1527', '2012-04-24', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1528', '2012-04-25', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1529', '2012-04-26', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1530', '2012-04-27', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1531', '2012-04-30', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1532', '2012-05-01', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1533', '2012-05-02', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1534', '2012-05-03', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1535', '2012-05-04', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1536', '2012-05-07', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1537', '2012-05-08', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1538', '2012-05-09', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1539', '2012-05-10', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1540', '2012-05-11', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1541', '2012-05-14', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1542', '2012-05-15', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1543', '2012-05-16', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1544', '2012-05-17', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1545', '2012-05-18', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1546', '2012-05-21', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1547', '2012-05-22', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1548', '2012-05-23', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1549', '2012-05-24', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1550', '2012-05-25', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1551', '2012-05-28', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1552', '2012-05-29', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1553', '2012-05-30', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1554', '2012-05-31', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1555', '2012-06-01', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1556', '2012-06-04', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1557', '2012-06-05', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1558', '2012-06-06', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1559', '2012-06-07', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1560', '2012-06-08', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1561', '2012-06-11', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1562', '2012-06-12', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1563', '2012-06-13', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1564', '2012-06-14', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1565', '2012-06-15', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1566', '2012-06-18', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1567', '2012-06-19', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1568', '2012-06-20', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1569', '2012-06-21', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1570', '2012-06-22', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1571', '2012-06-25', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1572', '2012-06-26', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1573', '2012-06-27', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1574', '2012-06-28', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1575', '2012-06-29', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1576', '2012-07-02', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1577', '2012-07-03', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1578', '2012-07-04', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1579', '2012-07-05', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1580', '2012-07-06', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1581', '2012-07-09', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1582', '2012-07-10', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1583', '2012-07-11', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1584', '2012-07-12', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1585', '2012-07-13', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1586', '2012-07-16', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1587', '2012-07-17', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1588', '2012-07-18', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1589', '2012-07-19', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1590', '2012-07-20', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1591', '2012-07-23', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1592', '2012-07-24', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1593', '2012-07-25', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1594', '2012-07-26', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1595', '2012-07-27', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1596', '2012-07-30', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1597', '2012-07-31', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1598', '2012-08-01', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1599', '2012-08-02', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1600', '2012-08-03', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1601', '2012-08-06', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1602', '2012-08-07', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1603', '2012-08-08', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1604', '2012-08-09', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1605', '2012-08-10', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1606', '2012-08-13', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1607', '2012-08-14', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1608', '2012-08-15', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1609', '2012-08-16', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1610', '2012-08-17', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1611', '2012-08-20', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1612', '2012-08-21', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1613', '2012-08-22', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1614', '2012-08-23', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1615', '2012-08-24', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1616', '2012-08-27', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1617', '2012-08-28', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1618', '2012-08-29', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1619', '2012-08-30', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1620', '2012-08-31', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1621', '2012-09-03', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1622', '2012-09-04', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1623', '2012-09-05', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1624', '2012-09-06', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1625', '2012-09-07', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1626', '2012-09-10', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1627', '2012-09-11', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1628', '2012-09-12', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1629', '2012-09-13', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1630', '2012-09-14', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1631', '2012-09-17', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1632', '2012-09-18', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1633', '2012-09-19', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1634', '2012-09-20', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1635', '2012-09-21', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1636', '2012-09-24', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1637', '2012-09-25', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1638', '2012-09-26', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1639', '2012-09-27', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1640', '2012-09-28', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1641', '2012-10-01', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1642', '2012-10-02', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1643', '2012-10-03', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1644', '2012-10-04', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1645', '2012-10-05', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1646', '2012-10-08', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1647', '2012-10-09', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1648', '2012-10-10', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1649', '2012-10-11', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1650', '2012-10-12', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1651', '2012-10-15', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1652', '2012-10-16', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1653', '2012-10-17', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1654', '2012-10-18', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1655', '2012-10-19', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1656', '2012-10-22', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1657', '2012-10-23', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1658', '2012-10-24', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1659', '2012-10-25', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1660', '2012-10-26', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1661', '2012-10-29', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1662', '2012-10-30', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1663', '2012-10-31', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1664', '2012-11-01', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1665', '2012-11-02', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1666', '2012-11-05', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1667', '2012-11-06', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1668', '2012-11-07', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1669', '2012-11-08', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1670', '2012-11-09', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1671', '2012-11-12', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1672', '2012-11-13', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1673', '2012-11-14', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1674', '2012-11-15', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1675', '2012-11-16', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1676', '2012-11-19', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1677', '2012-11-20', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1678', '2012-11-21', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1679', '2012-11-22', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1680', '2012-11-23', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1681', '2012-11-26', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1682', '2012-11-27', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1683', '2012-11-28', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1684', '2012-11-29', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1685', '2012-11-30', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1686', '2012-12-03', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1687', '2012-12-04', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1688', '2012-12-05', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1689', '2012-12-06', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1690', '2012-12-07', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1691', '2012-12-10', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1692', '2012-12-11', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1693', '2012-12-12', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1694', '2012-12-13', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1695', '2012-12-14', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1696', '2012-12-17', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1697', '2012-12-18', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1698', '2012-12-19', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1699', '2012-12-20', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1700', '2012-12-21', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1701', '2012-12-24', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1702', '2012-12-25', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1703', '2012-12-26', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1704', '2012-12-27', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1705', '2012-12-28', '10', '6', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1706', '2013-07-22', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1707', '2013-07-23', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1708', '2013-07-24', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1709', '2013-07-25', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1710', '2013-07-26', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1711', '2013-07-27', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1712', '2013-07-29', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1713', '2013-07-30', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1714', '2013-07-31', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1715', '2013-08-01', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1716', '2013-08-02', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1717', '2013-08-03', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1718', '2013-08-05', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1719', '2013-08-06', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1720', '2013-08-07', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1721', '2013-08-08', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1722', '2013-08-09', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1723', '2013-08-10', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1724', '2013-08-12', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1725', '2013-08-13', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1726', '2013-08-14', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1727', '2013-08-15', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1728', '2013-08-16', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1729', '2013-08-17', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1730', '2013-08-19', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1731', '2013-08-20', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1732', '2013-08-21', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1733', '2013-08-22', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1734', '2013-08-23', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1735', '2013-08-24', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1736', '2013-08-26', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1737', '2013-08-27', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1738', '2013-08-28', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1739', '2013-08-29', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1740', '2013-08-30', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1741', '2013-08-31', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1742', '2013-09-02', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1743', '2013-09-03', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1744', '2013-09-04', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1745', '2013-09-05', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1746', '2013-09-06', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1747', '2013-09-07', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1748', '2013-09-09', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1749', '2013-09-10', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1750', '2013-09-11', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1751', '2013-09-12', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1752', '2013-09-13', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1753', '2013-09-14', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1754', '2013-09-16', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1755', '2013-09-17', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1756', '2013-09-18', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1757', '2013-09-19', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1758', '2013-09-20', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1759', '2013-09-21', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1760', '2013-09-23', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1761', '2013-09-24', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1762', '2013-09-25', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1763', '2013-09-26', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1764', '2013-09-27', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1765', '2013-09-28', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1766', '2013-09-30', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1767', '2013-10-01', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1768', '2013-10-02', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1769', '2013-10-03', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1770', '2013-10-04', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1771', '2013-10-05', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1772', '2013-10-07', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1773', '2013-10-08', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1774', '2013-10-09', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1775', '2013-10-10', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1776', '2013-10-11', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1777', '2013-10-12', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1778', '2013-10-14', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1779', '2013-10-15', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1780', '2013-10-16', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1781', '2013-10-17', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1782', '2013-10-18', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1783', '2013-10-19', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1784', '2013-10-21', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1785', '2013-10-22', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1786', '2013-10-23', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1787', '2013-10-24', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1788', '2013-10-25', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1789', '2013-10-26', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1790', '2013-10-28', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1791', '2013-10-29', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1792', '2013-10-30', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1793', '2013-10-31', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1794', '2013-11-01', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1795', '2013-11-02', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1796', '2013-11-04', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1797', '2013-11-05', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1798', '2013-11-06', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1799', '2013-11-07', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1800', '2013-11-08', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1801', '2013-11-09', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1802', '2013-11-11', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1803', '2013-11-12', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1804', '2013-11-13', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1805', '2013-11-14', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1806', '2013-11-15', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1807', '2013-11-16', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1808', '2013-11-18', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1809', '2013-11-19', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1810', '2013-11-20', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1811', '2013-11-21', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1812', '2013-11-22', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1813', '2013-11-23', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1814', '2013-11-25', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1815', '2013-11-26', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1816', '2013-11-27', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1817', '2013-11-28', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1818', '2013-11-29', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1819', '2013-11-30', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1820', '2013-12-02', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1821', '2013-12-03', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1822', '2013-12-04', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1823', '2013-12-05', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1824', '2013-12-06', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1825', '2013-12-07', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1826', '2013-12-09', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1827', '2013-12-10', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1828', '2013-12-11', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1829', '2013-12-12', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1830', '2013-12-13', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1831', '2013-12-14', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1832', '2013-12-16', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1833', '2013-12-17', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1834', '2013-12-18', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1835', '2013-12-19', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1836', '2013-12-20', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1837', '2013-12-21', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1838', '2013-12-23', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1839', '2013-12-24', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1840', '2013-12-25', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1841', '2013-12-26', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1842', '2013-12-27', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1843', '2013-12-28', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1844', '2013-12-30', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1845', '2013-12-31', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1846', '2014-01-01', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1847', '2014-01-02', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1848', '2014-01-03', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1849', '2014-01-04', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1850', '2014-01-06', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1851', '2014-01-07', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1852', '2014-01-08', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1853', '2014-01-09', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1854', '2014-01-10', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1855', '2014-01-11', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1856', '2014-01-13', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1857', '2014-01-14', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1858', '2014-01-15', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1859', '2014-01-16', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1860', '2014-01-17', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1861', '2014-01-18', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1862', '2014-01-20', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1863', '2014-01-21', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1864', '2014-01-22', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1865', '2014-01-23', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1866', '2014-01-24', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1867', '2014-01-25', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1868', '2014-01-27', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1869', '2014-01-28', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1870', '2014-01-29', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1871', '2014-01-30', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1872', '2014-01-31', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1873', '2014-02-01', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1874', '2014-02-03', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1875', '2014-02-04', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1876', '2014-02-05', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1877', '2014-02-06', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1878', '2014-02-07', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1879', '2014-02-08', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1880', '2014-02-10', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1881', '2014-02-11', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1882', '2014-02-12', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1883', '2014-02-13', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1884', '2014-02-14', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1885', '2014-02-15', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1886', '2014-02-17', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1887', '2014-02-18', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1888', '2014-02-19', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1889', '2014-02-20', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1890', '2014-02-21', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1891', '2014-02-22', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1892', '2014-02-24', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1893', '2014-02-25', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1894', '2014-02-26', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1895', '2014-02-27', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1896', '2014-02-28', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1897', '2014-03-01', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1898', '2014-03-03', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1899', '2014-03-04', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1900', '2014-03-05', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1901', '2014-03-06', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1902', '2014-03-07', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1903', '2014-03-08', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1904', '2014-03-10', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1905', '2014-03-11', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1906', '2014-03-12', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1907', '2014-03-13', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1908', '2014-03-14', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1909', '2014-03-15', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1910', '2014-03-17', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1911', '2014-03-18', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1912', '2014-03-19', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1913', '2014-03-20', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1914', '2014-03-21', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1915', '2014-03-22', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1916', '2014-03-24', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1917', '2014-03-25', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1918', '2014-03-26', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1919', '2014-03-27', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1920', '2014-03-29', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1921', '2014-03-31', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1922', '2014-04-01', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1923', '2014-04-02', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1924', '2014-04-03', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1925', '2014-04-04', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1926', '2014-04-05', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1927', '2014-04-07', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1928', '2014-04-08', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1929', '2014-04-09', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1930', '2014-04-10', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1931', '2014-04-11', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1932', '2014-04-12', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1933', '2014-04-14', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1934', '2014-04-15', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1935', '2014-04-16', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1936', '2014-04-17', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1937', '2014-04-18', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1938', '2014-04-19', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1939', '2014-04-21', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1940', '2014-04-22', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1941', '2014-04-23', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1942', '2014-04-24', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1943', '2014-04-25', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1944', '2014-04-26', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1945', '2014-04-28', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1946', '2014-04-29', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1947', '2014-04-30', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1948', '2014-05-01', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1949', '2014-05-02', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1950', '2014-05-03', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1951', '2014-05-05', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1952', '2014-05-06', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1953', '2014-05-07', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1954', '2014-05-08', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1955', '2014-05-09', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1956', '2014-05-10', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1957', '2014-05-12', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1958', '2014-05-13', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1959', '2014-05-14', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1960', '2014-05-15', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1961', '2014-05-16', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1962', '2014-05-17', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1963', '2014-05-19', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1964', '2014-05-20', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1965', '2014-05-21', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1966', '2014-05-22', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1967', '2014-05-23', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1968', '2014-05-24', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1969', '2014-05-26', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1970', '2014-05-27', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1971', '2014-05-28', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1972', '2014-05-29', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1973', '2014-05-30', '13', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1974', '2012-07-09', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1975', '2012-07-10', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1976', '2012-07-11', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1977', '2012-07-12', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1978', '2012-07-13', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1979', '2012-07-16', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1980', '2012-07-17', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1981', '2012-07-18', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1982', '2012-07-19', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1983', '2012-07-20', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1984', '2012-07-23', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1985', '2012-07-24', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1986', '2012-07-25', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1987', '2012-07-26', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1988', '2012-07-27', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1989', '2012-07-30', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1990', '2012-07-31', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1991', '2012-08-01', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1992', '2012-08-02', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1993', '2012-08-03', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1994', '2012-08-06', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1995', '2012-08-07', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1996', '2012-08-08', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1997', '2012-08-09', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1998', '2012-08-10', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('1999', '2012-08-13', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2000', '2012-08-14', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2001', '2012-08-15', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2002', '2012-08-16', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2003', '2012-08-17', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2004', '2012-08-20', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2005', '2012-08-21', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2006', '2012-08-22', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2007', '2012-08-23', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2008', '2012-08-24', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2009', '2012-08-27', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2010', '2012-08-28', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2011', '2012-08-29', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2012', '2012-08-30', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2013', '2012-08-31', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2014', '2012-09-03', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2015', '2012-09-04', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2016', '2012-09-05', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2017', '2012-09-06', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2018', '2012-09-07', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2019', '2012-09-10', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2020', '2012-09-11', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2021', '2012-09-12', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2022', '2012-09-13', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2023', '2012-09-14', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2024', '2012-09-17', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2025', '2012-09-18', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2026', '2012-09-19', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2027', '2012-09-20', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2028', '2012-09-21', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2029', '2012-09-24', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2030', '2012-09-25', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2031', '2012-09-26', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2032', '2012-09-27', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2033', '2012-09-28', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2034', '2012-10-01', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2035', '2012-10-02', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2036', '2012-10-03', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2037', '2012-10-04', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2038', '2012-10-05', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2039', '2012-10-08', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2040', '2012-10-09', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2041', '2012-10-10', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2042', '2012-10-11', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2043', '2012-10-12', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2044', '2012-10-15', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2045', '2012-10-16', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2046', '2012-10-17', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2047', '2012-10-18', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2048', '2012-10-19', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2049', '2012-10-22', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2050', '2012-10-23', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2051', '2012-10-24', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2052', '2012-10-25', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2053', '2012-10-26', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2054', '2012-10-29', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2055', '2012-10-30', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2056', '2012-10-31', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2057', '2012-11-01', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2058', '2012-11-02', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2059', '2012-11-05', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2060', '2012-11-06', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2061', '2012-11-07', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2062', '2012-11-08', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2063', '2012-11-09', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2064', '2012-11-12', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2065', '2012-11-13', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2066', '2012-11-14', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2067', '2012-11-15', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2068', '2012-11-16', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2069', '2012-11-19', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2070', '2012-11-20', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2071', '2012-11-21', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2072', '2012-11-22', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2073', '2012-11-23', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2074', '2012-11-26', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2075', '2012-11-27', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2076', '2012-11-28', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2077', '2012-11-29', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2078', '2012-11-30', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2079', '2012-12-03', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2080', '2012-12-04', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2081', '2012-12-05', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2082', '2012-12-06', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2083', '2012-12-07', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2084', '2012-12-10', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2085', '2012-12-11', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2086', '2012-12-12', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2087', '2012-12-13', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2088', '2012-12-14', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2089', '2012-12-17', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2090', '2012-12-18', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2091', '2012-12-19', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2092', '2012-12-20', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2093', '2012-12-21', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2094', '2012-12-24', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2095', '2012-12-25', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2096', '2012-12-26', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2097', '2012-12-27', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2098', '2012-12-28', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2099', '2012-12-31', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2100', '2013-01-01', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2101', '2013-01-02', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2102', '2013-01-03', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2103', '2013-01-04', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2104', '2013-01-07', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2105', '2013-01-08', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2106', '2013-01-09', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2107', '2013-01-10', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2108', '2013-01-11', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2109', '2013-01-14', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2110', '2013-01-15', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2111', '2013-01-16', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2112', '2013-01-17', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2113', '2013-01-18', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2114', '2013-01-21', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2115', '2013-01-22', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2116', '2013-01-23', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2117', '2013-01-24', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2118', '2013-01-25', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2119', '2013-01-28', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2120', '2013-01-29', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2121', '2013-01-30', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2122', '2013-01-31', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2123', '2013-02-01', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2124', '2013-02-04', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2125', '2013-02-05', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2126', '2013-02-06', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2127', '2013-02-07', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2128', '2013-02-08', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2129', '2013-02-11', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2130', '2013-02-12', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2131', '2013-02-13', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2132', '2013-02-14', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2133', '2013-02-15', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2134', '2013-02-18', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2135', '2013-02-19', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2136', '2013-02-20', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2137', '2013-02-21', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2138', '2013-02-22', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2139', '2013-02-25', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2140', '2013-02-26', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2141', '2013-02-27', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2142', '2013-02-28', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2143', '2013-03-01', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2144', '2013-03-04', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2145', '2013-03-05', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2146', '2013-03-06', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2147', '2013-03-07', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2148', '2013-03-08', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2149', '2013-03-11', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2150', '2013-03-12', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2151', '2013-03-13', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2152', '2013-03-14', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2153', '2013-03-15', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2154', '2013-03-18', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2155', '2013-03-19', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2156', '2013-03-20', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2157', '2013-03-21', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2158', '2013-03-22', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2159', '2013-03-25', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2160', '2013-03-26', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2161', '2013-03-27', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2162', '2013-03-28', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2163', '2013-04-01', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2164', '2013-04-02', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2165', '2013-04-03', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2166', '2013-04-04', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2167', '2013-04-05', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2168', '2013-04-08', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2169', '2013-04-09', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2170', '2013-04-10', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2171', '2013-04-11', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2172', '2013-04-12', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2173', '2013-04-15', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2174', '2013-04-16', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2175', '2013-04-17', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2176', '2013-04-18', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2177', '2013-04-19', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2178', '2013-04-22', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2179', '2013-04-23', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2180', '2013-04-24', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2181', '2013-04-25', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2182', '2013-04-26', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2183', '2013-04-29', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2184', '2013-04-30', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2185', '2013-05-01', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2186', '2013-05-02', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2187', '2013-05-03', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2188', '2013-05-06', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2189', '2013-05-07', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2190', '2013-05-08', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2191', '2013-05-09', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2192', '2013-05-10', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2193', '2013-05-13', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2194', '2013-05-14', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2195', '2013-05-15', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2196', '2013-05-16', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2197', '2013-05-17', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2198', '2013-05-20', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2199', '2013-05-21', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2200', '2013-05-22', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2201', '2013-05-23', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2202', '2013-05-24', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2203', '2013-05-27', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2204', '2013-05-28', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2205', '2013-05-29', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2206', '2013-05-30', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2207', '2013-05-31', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2208', '2013-06-03', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2209', '2013-06-04', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2210', '2013-06-05', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2211', '2013-06-06', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2212', '2013-06-07', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2213', '2013-06-10', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2214', '2013-06-11', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2215', '2013-06-12', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2216', '2013-06-13', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2217', '2013-06-14', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2218', '2013-06-17', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2219', '2013-06-18', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2220', '2013-06-19', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2221', '2013-06-20', '12', '4', NULL, NULL, NULL);
insert into `period_entries` (`id`, `month_date`, `batch_id`, `schoolid`, `subject_id`, `class_timing_id`, `employee_id`) values ('2222', '2013-06-21', '12', '4', NULL, NULL, NULL);

drop table if exists `phpmysqlautobackup`;
CREATE TABLE `phpmysqlautobackup` (
  `id` int(11) NOT NULL,
  `version` varchar(6) default NULL,
  `time_last_run` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1; 
insert into `phpmysqlautobackup` (`id`, `version`, `time_last_run`) values ('1', '1.5.2', '1331630249');

drop table if exists `reminder_group`;
CREATE TABLE `reminder_group` (
  `id` int(11) NOT NULL auto_increment,
  `senderID` int(11) NOT NULL,
  `rec_m_IDs` varchar(1000) NOT NULL,
  `rec_s_IDs` varchar(1000) NOT NULL,
  `rec_p_IDs` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1; 
insert into `reminder_group` (`id`, `senderID`, `rec_m_IDs`, `rec_s_IDs`, `rec_p_IDs`) values ('1', '6', '2', '', '');

drop table if exists `reminders`;
CREATE TABLE `reminders` (
  `id` int(11) NOT NULL auto_increment,
  `sender` int(11) default NULL,
  `recipient` int(11) default NULL,
  `subject` varchar(255) collate utf8_unicode_ci default NULL,
  `body` text collate utf8_unicode_ci,
  `is_read` tinyint(1) default '0',
  `is_deleted_by_sender` tinyint(1) default '0',
  `is_deleted_by_recipient` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `groupid` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `index_reminders_on_recipient` (`recipient`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `reminders` (`id`, `sender`, `recipient`, `subject`, `body`, `is_read`, `is_deleted_by_sender`, `is_deleted_by_recipient`, `created_at`, `updated_at`, `groupid`) values ('1', '1', '2', 'aaa aa aa', 'bb bb bb bbb bbb bb', '1', '0', '0', '2011-11-11 15:46:04', '2011-11-11 15:46:08', '0');
insert into `reminders` (`id`, `sender`, `recipient`, `subject`, `body`, `is_read`, `is_deleted_by_sender`, `is_deleted_by_recipient`, `created_at`, `updated_at`, `groupid`) values ('2', '1', '2', 'rtr rrt rrw wwe', 'dfg ff gdd ss sddf sss', '1', '0', '0', '2011-11-11 15:28:02', '2011-11-11 15:28:06', '0');
insert into `reminders` (`id`, `sender`, `recipient`, `subject`, `body`, `is_read`, `is_deleted_by_sender`, `is_deleted_by_recipient`, `created_at`, `updated_at`, `groupid`) values ('3', '2', '5', ' test sdf we r f', 'sd sdf sdff ssdf sdfsdf sdff', '0', '1', '0', '2011-11-11 15:29:02', '2011-11-11 15:29:07', '0');
insert into `reminders` (`id`, `sender`, `recipient`, `subject`, `body`, `is_read`, `is_deleted_by_sender`, `is_deleted_by_recipient`, `created_at`, `updated_at`, `groupid`) values ('4', '2', '1', 'sdf s', 'sd fsdf', '1', '1', '0', '2011-12-10 07:25:00', '2011-12-10 07:25:00', '0');
insert into `reminders` (`id`, `sender`, `recipient`, `subject`, `body`, `is_read`, `is_deleted_by_sender`, `is_deleted_by_recipient`, `created_at`, `updated_at`, `groupid`) values ('5', '2', '3', 'sdf s', 'sd fsdf', '0', '0', '0', '2011-12-10 07:25:00', '2011-12-10 07:25:00', '0');
insert into `reminders` (`id`, `sender`, `recipient`, `subject`, `body`, `is_read`, `is_deleted_by_sender`, `is_deleted_by_recipient`, `created_at`, `updated_at`, `groupid`) values ('6', '2', '6', 'sdf s', 'sd fsdf', '0', '0', '0', '2011-12-10 07:25:00', '2011-12-10 07:25:00', '0');
insert into `reminders` (`id`, `sender`, `recipient`, `subject`, `body`, `is_read`, `is_deleted_by_sender`, `is_deleted_by_recipient`, `created_at`, `updated_at`, `groupid`) values ('7', '6', '2', 'gdf ', 'df gdfg', '1', '0', '0', '2011-12-10 13:05:32', '2011-12-10 13:05:32', '1');
insert into `reminders` (`id`, `sender`, `recipient`, `subject`, `body`, `is_read`, `is_deleted_by_sender`, `is_deleted_by_recipient`, `created_at`, `updated_at`, `groupid`) values ('8', '16', '12', NULL, 'sgeeth', '0', '0', '0', '2012-02-28 13:10:29', '2012-02-28 13:10:29', '0');

drop table if exists `request_student`;
CREATE TABLE `request_student` (
  `id` int(11) NOT NULL auto_increment,
  `curr_school_id` int(50) NOT NULL,
  `to_school` int(100) NOT NULL,
  `student_id` varchar(100) NOT NULL,
  `message` varchar(200) NOT NULL,
  `sec_id` int(50) NOT NULL,
  `status` int(1) NOT NULL default '1',
  `act_status` int(1) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1; 
insert into `request_student` (`id`, `curr_school_id`, `to_school`, `student_id`, `message`, `sec_id`, `status`, `act_status`) values ('7', '1', '4', '22', 'we want this student info', '20', '1', '2');

drop table if exists `school`;
CREATE TABLE `school` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(500) NOT NULL,
  `address` text NOT NULL,
  `phno` varchar(40) NOT NULL,
  `mhno` varchar(40) NOT NULL,
  `logo` varchar(200) NOT NULL,
  `status` int(1) NOT NULL default '1',
  `emplogin` int(1) NOT NULL default '1',
  `parentlogin` int(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1; 
insert into `school` (`id`, `name`, `address`, `phno`, `mhno`, `logo`, `status`, `emplogin`, `parentlogin`) values ('1', 'LBS School', 'Paota Jodhpur', '0219425786', '0291236547', '1381.png', '1', '1', '1');
insert into `school` (`id`, `name`, `address`, `phno`, `mhno`, `logo`, `status`, `emplogin`, `parentlogin`) values ('2', 'St. Xavier Secondary School', 'Ratanada, Jodhpur', '02912646856', '255649532', '', '1', '1', '1');
insert into `school` (`id`, `name`, `address`, `phno`, `mhno`, `logo`, `status`, `emplogin`, `parentlogin`) values ('4', 'Vidhya Bhawan', 'Pal link main, Jodhppur', '0291-2646859', '', '4229.jpg', '1', '1', '1');
insert into `school` (`id`, `name`, `address`, `phno`, `mhno`, `logo`, `status`, `emplogin`, `parentlogin`) values ('6', 'New LBS School', 'Mohan Nagar', '029178542', '', '6495.jpg', '1', '1', '1');

drop table if exists `student_note`;
CREATE TABLE `student_note` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) NOT NULL,
  `schoolid` int(11) NOT NULL,
  `write_by` int(11) NOT NULL,
  `note` text NOT NULL,
  `write_dt` datetime NOT NULL,
  `status` int(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1; 
insert into `student_note` (`id`, `student_id`, `schoolid`, `write_by`, `note`, `write_dt`, `status`) values ('1', '3', '1', '6', 'test test test test ', '2011-12-04 23:04:51', '1');
insert into `student_note` (`id`, `student_id`, `schoolid`, `write_by`, `note`, `write_dt`, `status`) values ('2', '3', '1', '2', 'wrgqerwg asfg', '2011-12-05 03:30:48', '1');
insert into `student_note` (`id`, `student_id`, `schoolid`, `write_by`, `note`, `write_dt`, `status`) values ('3', '3', '1', '2', 'adfgd adfgh', '2011-12-05 03:32:51', '1');
insert into `student_note` (`id`, `student_id`, `schoolid`, `write_by`, `note`, `write_dt`, `status`) values ('4', '16', '1', '25', 'this student is good on english
', '2011-12-09 12:36:58', '1');
insert into `student_note` (`id`, `student_id`, `schoolid`, `write_by`, `note`, `write_dt`, `status`) values ('5', '16', '1', '8', 'should maintain proper attendance in class', '2011-12-09 12:41:43', '1');
insert into `student_note` (`id`, `student_id`, `schoolid`, `write_by`, `note`, `write_dt`, `status`) values ('6', '33', '1', '2', 'aa', '2012-03-12 01:25:41', '1');

drop table if exists `student_previous_datas`;
CREATE TABLE `student_previous_datas` (
  `id` int(11) NOT NULL auto_increment,
  `student_id` int(11) default NULL,
  `institution` varchar(255) collate utf8_unicode_ci default NULL,
  `year` varchar(255) collate utf8_unicode_ci default NULL,
  `course` varchar(255) collate utf8_unicode_ci default NULL,
  `total_mark` varchar(255) collate utf8_unicode_ci default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 

drop table if exists `students`;
CREATE TABLE `students` (
  `id` int(11) NOT NULL auto_increment,
  `schoolid` int(11) NOT NULL,
  `admission_no` varchar(255) collate utf8_unicode_ci default NULL,
  `passport_or_id` int(11) NOT NULL,
  `student_passport_no` varchar(200) collate utf8_unicode_ci NOT NULL,
  `class_roll_no` varchar(255) collate utf8_unicode_ci default NULL,
  `guardian_id` int(11) default '0',
  `admission_date` date default NULL,
  `title` varchar(20) collate utf8_unicode_ci NOT NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `middle_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `batch_id` int(11) default NULL,
  `date_of_birth` date default NULL,
  `gender` varchar(255) collate utf8_unicode_ci default NULL,
  `blood_group` varchar(255) collate utf8_unicode_ci default NULL,
  `birth_place` varchar(255) collate utf8_unicode_ci default NULL,
  `nationality_id` int(11) default NULL,
  `language` varchar(255) collate utf8_unicode_ci default NULL,
  `religion` varchar(255) collate utf8_unicode_ci default NULL,
  `student_category_id` int(11) default NULL,
  `address_line1` varchar(255) collate utf8_unicode_ci default NULL,
  `address_line2` varchar(255) collate utf8_unicode_ci default NULL,
  `city` varchar(255) collate utf8_unicode_ci default NULL,
  `state` varchar(255) collate utf8_unicode_ci default NULL,
  `pin_code` varchar(255) collate utf8_unicode_ci default NULL,
  `country_id` int(11) default NULL,
  `phone1` varchar(255) collate utf8_unicode_ci default NULL,
  `phone2` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `immediate_contact_id` int(11) default NULL,
  `is_sms_enabled` tinyint(1) default '1',
  `photo_file_name` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_content_type` varchar(255) collate utf8_unicode_ci default NULL,
  `photo_data` mediumblob,
  `birth_certificate` varchar(300) collate utf8_unicode_ci NOT NULL,
  `status_description` varchar(255) collate utf8_unicode_ci default NULL,
  `is_active` tinyint(1) default '1',
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `has_paid_fees` tinyint(1) default '0',
  `photo_file_size` int(11) default NULL,
  `user_id` int(11) default NULL,
  `student_illness` text collate utf8_unicode_ci,
  PRIMARY KEY  (`id`),
  KEY `index_students_on_admission_no` (`admission_no`(10)),
  KEY `index_students_on_first_name_and_middle_name_and_last_name` (`first_name`(10),`middle_name`(10),`last_name`(10))
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('3', '1', '11041', '2', '0', '', '0', '2011-11-10', 'Mr', 'Amit', '', 'Singh', '4', '1994-08-12', NULL, NULL, NULL, '1', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '3306.JPG', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('5', '1', '11042', '2', '0', '', '0', '2011-11-11', 'Mr', 'Suresh', '', 'Kumar', '4', '1996-11-30', NULL, NULL, NULL, '1', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('6', '1', '11043', '1', '0', '', '0', '2011-11-16', 'Mr', 'Shyam', '', 'Arora', '5', '1996-07-09', NULL, NULL, NULL, '1', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '6422.png', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('7', '1', '65', '1', '4', '', '0', '2011-11-16', 'Mr', 'Shyam', '', 'Kumar', '2', '2011-11-16', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '7547.jpg', NULL, NULL, '7232.jpg', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('8', '1', '1035', '1', '0', '', '0', '2011-11-16', 'Mr', 'Rahul', '', 'Singh', '4', '2011-12-20', NULL, NULL, NULL, '1', NULL, '1', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '8583.jpg', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('10', '2', '1038', '1', '0', '', '0', '2011-11-17', 'Mr', 'Mayank', '', 'Sen', '6', '1998-11-04', NULL, NULL, NULL, '1', NULL, '1', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '10330.png', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('11', '2', '11046', '1', '0', '', '0', '2011-11-19', 'Mr', 'Jay', '', 'Singh', '6', '1998-07-14', NULL, NULL, NULL, '1', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '11202.jpg', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('15', '1', '114106', '1', '0', '', '0', '2011-11-28', 'Mr', 'Kamlesh', '', 'Singh', '5', '1995-12-11', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, 'sfdaf', NULL, NULL, NULL, NULL, NULL, '2351222', NULL, NULL, NULL, '1', NULL, NULL, NULL, '15633.jpg', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('16', '1', '114107', '2', 'A2443', '', '18', '2011-12-09', 'Mr', 'Farookh', '', 'Seikh', '7', '2011-12-09', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, '1st phase, main road', NULL, NULL, NULL, NULL, NULL, '356545954', NULL, NULL, NULL, '1', '16651.png', NULL, NULL, '16684.png', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('18', '1', '114103', '1', '0', NULL, '0', '2011-11-23', 'Mr', 'Pradeep', '', 'Gupta', '2', '1994-12-27', NULL, NULL, NULL, '1', NULL, 'Hindu', NULL, 'abc', NULL, NULL, NULL, NULL, NULL, '3121232', NULL, NULL, NULL, '1', '13537.jpg', NULL, NULL, '13116.png', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('20', '1', '123', '2', 'A722', '', '0', '2011-12-14', 'Mr', 'mahipal', 'singh', 'chouhan', '7', '2011-12-14', NULL, NULL, NULL, '10', NULL, 'Hindu', NULL, 'chouhano ki dhani', NULL, NULL, NULL, NULL, NULL, '9782619395', NULL, NULL, NULL, '1', '20651.jpg', NULL, NULL, '20211.jpg', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('21', '1', '454', '2', '5', '', '1', '2011-12-14', 'Mr', 'Shakti', '', 'Singh', '4', '1993-05-13', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('23', '6', '1000201', '1', '10243845', '', '17', '2012-00-23', 'Mr', 'Rajendra', '', 'chouhan', '10', '2012-00-23', NULL, NULL, NULL, '76', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('24', '1', 'LBS401', '2', 'AGP1023', '', '19', '2012-02-29', 'Mr', 'Dinesh', '', 'Joshi', '4', '1995-12-19', NULL, NULL, NULL, '184', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('25', '1', '5435', '1', 'ddgdd', NULL, '21', '2011-12-14', 'Miss', 'Jeniffer', '', 'Scott', '11', '2011-12-14', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('26', '1', 'LB1212', '2', 'A2443', '', '0', '2012-02-29', 'Mr', 'Tarun', '', 'Singh', '11', '1995-01-17', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('28', '4', 'V12001', '2', 'S6062', NULL, '16', '2012-00-15', 'Mr', 'Satish', '', 'Kumar', '13', '1996-08-14', NULL, NULL, NULL, '76', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('29', '4', 'V12004', '2', 'DF45S5', '', '16', '2012-02-29', 'Mr', 'Nilesh', '', 'Rathi', '13', '1996-07-09', NULL, NULL, NULL, '1', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('32', '4', 'vb512', '1', 'FL133', NULL, '20', '2012-03-03', 'Mr', 'Yash', '', 'Paul', '13', '1996-07-09', NULL, NULL, NULL, '31', NULL, '1', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('33', '1', 'V12001', '1', '0', NULL, '1', '2011-11-04', 'Mr', 'Kamlesh', '', 'Singh', '11', '2011-11-04', NULL, NULL, NULL, '1', NULL, '1', NULL, 'chouhano ki dhani', NULL, NULL, NULL, NULL, NULL, 'ger', NULL, NULL, NULL, '1', '2250.jpg', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('34', '1', '1000201', '1', '0', NULL, '0', '2011-11-25', 'Mr', 'Parvez', '', 'Khan', '11', '1999-08-24', NULL, NULL, NULL, '1', NULL, 'Islam', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '14806.png', NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('35', '1', '114101', '2', '0', NULL, '0', '2011-11-19', 'Mr', 'Vikram', '', 'Parekh', '11', '1995-06-23', NULL, NULL, NULL, '1', NULL, '1', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', '12191.png', NULL, NULL, '12675.png', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('36', '4', 'VB0912', '2', 'S34F01', '', '22', '2012-03-09', 'Mr', 'Swaroop', '', 'Singh', '9', '1996-07-09', NULL, NULL, NULL, '76', NULL, 'Hindu', NULL, 'ashok nagar', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);
insert into `students` (`id`, `schoolid`, `admission_no`, `passport_or_id`, `student_passport_no`, `class_roll_no`, `guardian_id`, `admission_date`, `title`, `first_name`, `middle_name`, `last_name`, `batch_id`, `date_of_birth`, `gender`, `blood_group`, `birth_place`, `nationality_id`, `language`, `religion`, `student_category_id`, `address_line1`, `address_line2`, `city`, `state`, `pin_code`, `country_id`, `phone1`, `phone2`, `email`, `immediate_contact_id`, `is_sms_enabled`, `photo_file_name`, `photo_content_type`, `photo_data`, `birth_certificate`, `status_description`, `is_active`, `is_deleted`, `created_at`, `updated_at`, `has_paid_fees`, `photo_file_size`, `user_id`, `student_illness`) values ('37', '4', '54121', '1', 'G12J1', '', '16', '2012-03-09', 'Mr', 'Sushil', '', 'Vyas', '14', '1995-02-13', NULL, NULL, NULL, '7', NULL, 'Hindu', NULL, '', NULL, NULL, NULL, NULL, NULL, '', NULL, NULL, NULL, '1', NULL, NULL, NULL, '', NULL, '1', '0', NULL, NULL, '0', NULL, NULL, NULL);

drop table if exists `subjects`;
CREATE TABLE `subjects` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `code` varchar(255) collate utf8_unicode_ci default NULL,
  `grade_id` int(11) NOT NULL default '0',
  `schoolid` int(11) NOT NULL,
  `colorcode` varchar(7) collate utf8_unicode_ci NOT NULL default '#ffffff',
  `no_exams` tinyint(1) default '0',
  `max_weekly_classes` int(11) default NULL,
  `elective_group_id` int(11) default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_subjects_on_batch_id_and_elective_group_id_and_is_deleted` (`elective_group_id`,`is_deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('1', 'English', '001', '1', '0', '#F6D524', '0', NULL, NULL, '0', '2011-11-03 05:04:52', '2011-11-03 05:04:52');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('2', 'Arabic', '002', '1', '0', '#225D09', '0', NULL, NULL, '0', '2011-11-03 05:08:15', '2011-11-03 05:24:16');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('5', 'Mathematics', '013', '1', '0', '#FA8E2B', '0', NULL, NULL, '0', '2011-11-11 11:11:19', '2011-11-11 11:11:19');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('7', 'Maths', '801', '3', '0', '#FA8E2B', '0', NULL, NULL, '0', '2011-11-17 12:52:56', '2011-11-17 12:52:56');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('8', 'General Science', '802', '3', '0', '#BC1713', '0', NULL, NULL, '0', '2011-11-18 12:08:06', '2011-11-18 12:08:06');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('9', 'Social Science', '803', '3', '0', '#8705A7', '0', NULL, NULL, '0', '2011-11-18 12:08:17', '2011-11-18 12:08:17');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('10', 'English', '804', '3', '0', '#F6D524', '0', NULL, NULL, '0', '2011-11-18 12:08:27', '2011-11-18 12:08:33');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('11', 'Grammer', '805', '3', '0', '#085CF0', '0', NULL, NULL, '0', '2011-11-18 12:08:46', '2011-11-18 12:08:46');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('13', 'Hindi', '104', '1', '0', '#97D603', '0', NULL, NULL, '0', '2011-11-23 03:57:58', '2011-11-23 03:57:58');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('24', 'sociology', '151', '1', '0', '#FF1406', '0', NULL, NULL, '0', '2011-12-03 09:22:58', '2011-12-03 09:22:58');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('28', 'English', '112', '4', '1', '#F6D524', '0', NULL, NULL, '0', '2011-12-08 11:55:12', '2011-12-08 11:55:12');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('29', 'economics', '141', '4', '1', '#F6ACE9', '0', NULL, NULL, '0', '2011-12-08 11:55:26', '2011-12-08 11:55:26');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('30', 'sociology', '151', '4', '1', '#FF1406', '0', NULL, NULL, '0', '2011-12-08 11:55:26', '2011-12-08 11:55:26');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('31', 'English', '1441', '2', '1', '#F6D524', '0', NULL, NULL, '0', '2011-12-09 12:11:36', '2011-12-09 12:11:36');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('32', 'economics', '141', '2', '1', '#F6ACE9', '0', NULL, NULL, '0', '2011-12-09 12:11:46', '2011-12-09 12:11:46');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('33', 'General Law', '1442', '2', '1', '#F360CB', '0', NULL, NULL, '0', '2011-12-09 12:12:06', '2011-12-09 12:12:06');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('34', 'Social Science', '1423', '2', '1', '#8705A7', '0', NULL, NULL, '0', '2011-12-09 12:12:35', '2011-12-09 12:12:35');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('35', 'tt2', '67', '4', '1', '#225D09', '0', NULL, NULL, '0', '2011-12-29 02:38:20', '2011-12-29 02:38:20');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('36', 'English', '1441', '6', '6', '#F6D524', '0', NULL, NULL, '0', '2012-02-23 09:02:14', '2012-02-23 09:02:14');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('37', 'Hindi', '02315', '6', '6', '#225D09', '0', NULL, NULL, '0', '2012-02-23 09:02:25', '2012-02-23 09:02:25');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('38', 'Science', '024', '6', '6', '#FA8E2B', '0', NULL, NULL, '0', '2012-02-23 09:02:43', '2012-02-23 09:02:43');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('39', 'economics', '141', '5', '4', '#F6D524', '0', NULL, NULL, '0', '2012-02-29 02:03:06', '2012-02-29 02:03:06');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('40', 'sociology', '151', '5', '4', '#225D09', '0', NULL, NULL, '0', '2012-02-29 02:03:07', '2012-02-29 02:03:07');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('41', 'economics', '141', '8', '4', '#F6D524', '0', NULL, NULL, '0', '2012-02-29 02:18:36', '2012-02-29 02:18:36');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('42', 'sociology', '151', '8', '4', '#225D09', '0', NULL, NULL, '0', '2012-02-29 02:18:36', '2012-02-29 02:18:36');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('43', 'English', '1441', '9', '4', '#F6D524', '0', NULL, NULL, '0', '2012-02-29 02:31:59', '2012-02-29 02:31:59');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('44', 'Physics', '1443', '9', '4', '#225D09', '0', NULL, NULL, '0', '2012-02-29 02:31:59', '2012-02-29 02:31:59');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('45', 'economics', '141', '7', '1', '#F6ACE9', '0', NULL, NULL, '0', '2012-03-07 10:50:12', '2012-03-07 10:50:12');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('46', 'sociology', '151', '7', '1', '#FF1406', '0', NULL, NULL, '0', '2012-03-07 10:50:12', '2012-03-07 10:50:12');
insert into `subjects` (`id`, `name`, `code`, `grade_id`, `schoolid`, `colorcode`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('47', 'English', '1441', '7', '1', '#F6D524', '0', NULL, NULL, '0', '2012-03-07 10:50:22', '2012-03-07 10:50:22');

drop table if exists `subjects_template`;
CREATE TABLE `subjects_template` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) collate utf8_unicode_ci default NULL,
  `code` varchar(100) collate utf8_unicode_ci NOT NULL,
  `grade_id` int(11) default NULL,
  `no_exams` tinyint(1) default '0',
  `max_weekly_classes` int(11) default NULL,
  `elective_group_id` int(11) default NULL,
  `is_deleted` tinyint(1) default '0',
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `index_subjects_on_batch_id_and_elective_group_id_and_is_deleted` (`grade_id`,`elective_group_id`,`is_deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `subjects_template` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('2', 'English', '1441', '1', '0', NULL, NULL, '0', '2011-11-23 07:24:31', '2011-12-08 12:27:05');
insert into `subjects_template` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('5', 'economics', '141', '2', '0', NULL, NULL, '0', '2011-12-02 01:51:46', '2011-12-03 09:22:35');
insert into `subjects_template` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('6', 'sociology', '151', '2', '0', NULL, NULL, '0', '2011-12-03 09:21:28', '2011-12-03 09:21:28');
insert into `subjects_template` (`id`, `name`, `code`, `grade_id`, `no_exams`, `max_weekly_classes`, `elective_group_id`, `is_deleted`, `created_at`, `updated_at`) values ('7', 'Physics', '1443', '1', '0', NULL, NULL, '0', '2012-02-29 02:31:36', '2012-02-29 02:31:36');

drop table if exists `teacher_to_grade`;
CREATE TABLE `teacher_to_grade` (
  `id` int(11) NOT NULL auto_increment,
  `schoolid` int(11) NOT NULL,
  `batch_id` int(11) NOT NULL,
  `empid` int(11) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=latin1; 
insert into `teacher_to_grade` (`id`, `schoolid`, `batch_id`, `empid`, `status`) values ('1', '1', '2', '1', '1');

drop table if exists `ticket`;
CREATE TABLE `ticket` (
  `id` int(11) NOT NULL auto_increment,
  `title` varchar(250) NOT NULL,
  `description` varchar(250) NOT NULL,
  `is_read` tinyint(1) default NULL,
  `created_by` int(11) NOT NULL,
  `createon` datetime NOT NULL,
  `notifydate` date NOT NULL,
  `status` varchar(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1; 
insert into `ticket` (`id`, `title`, `description`, `is_read`, `created_by`, `createon`, `notifydate`, `status`) values ('1', 'annual meet', 'we are organizing annual meet 2011 ', NULL, '0', '2011-11-12 14:29:42', '2011-11-14', '1');
insert into `ticket` (`id`, `title`, `description`, `is_read`, `created_by`, `createon`, `notifydate`, `status`) values ('2', 'as', 'afadf', NULL, '1', '2011-11-23 10:20:32', '0000-00-00', '1');
insert into `ticket` (`id`, `title`, `description`, `is_read`, `created_by`, `createon`, `notifydate`, `status`) values ('3', 'cvcvb', 'cvbcvb', NULL, '2', '2011-11-23 15:12:54', '0000-00-00', '1');
insert into `ticket` (`id`, `title`, `description`, `is_read`, `created_by`, `createon`, `notifydate`, `status`) values ('4', 'ad', 'dgasdg', NULL, '2', '2011-12-03 13:04:20', '0000-00-00', '1');

drop table if exists `ticket_assigned`;
CREATE TABLE `ticket_assigned` (
  `id` int(11) NOT NULL auto_increment,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `status` varchar(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=latin1; 
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('1', '1', '3', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('2', '3', '3', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('3', '3', '8', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('4', '3', '5', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('5', '3', '2', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('6', '3', '1', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('7', '3', '9', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('8', '3', '7', '1');
insert into `ticket_assigned` (`id`, `ticketid`, `userid`, `status`) values ('9', '3', '4', '1');

drop table if exists `ticket_commented`;
CREATE TABLE `ticket_commented` (
  `id` int(11) NOT NULL auto_increment,
  `ticketid` int(11) NOT NULL,
  `userid` int(11) NOT NULL,
  `usercomment` varchar(250) NOT NULL,
  `date` datetime NOT NULL,
  `status` varchar(1) NOT NULL default '1',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1; 
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('1', '3', '12', 'Distribution of substantively modified versions of this document is prohibited without the explicit permission of the copyright holder', '2011-11-24 14:40:18', '1');
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('2', '3', '16', 'In case you are interested in redistribution or republishing of this document in whole or in part, either modified or unmodified, and you have questions, please contact the copyright holders at � doc-license@lists.php.net.', '2011-11-23 00:00:00', '1');
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('3', '0', '0', 'afa', '2011-12-01 12:48:10', '1');
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('4', '0', '0', 'afaf', '2011-12-01 12:48:30', '1');
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('5', '3', '2', 'afafa', '2011-12-01 12:50:44', '1');
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('6', '3', '2', 'rrrADFa', '2011-12-01 12:51:56', '1');
insert into `ticket_commented` (`id`, `ticketid`, `userid`, `usercomment`, `date`, `status`) values ('7', '3', '1', 'hello..........', '2011-12-01 12:53:33', '1');

drop table if exists `timetable_entries`;
CREATE TABLE `timetable_entries` (
  `id` int(11) NOT NULL auto_increment,
  `batch_id` int(11) default NULL,
  `weekday_id` int(11) default NULL,
  `class_timing_id` int(11) default NULL,
  `schoolid` int(11) NOT NULL,
  `subject_id` int(11) default NULL,
  `employee_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `by_timetable` (`weekday_id`,`batch_id`,`class_timing_id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('1', '7', '1', '17', '1', '29', '6');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('3', '7', '3', '17', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('4', '7', '4', '17', '1', '29', '2');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('5', '7', '5', '17', '1', '28', '7');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('6', '7', '1', '18', '1', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('7', '7', '1', '19', '1', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('8', '7', '2', '18', '1', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('9', '7', '2', '19', '1', '28', '7');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('10', '7', '3', '18', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('12', '7', '4', '18', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('13', '7', '4', '19', '1', '29', '6');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('14', '7', '5', '18', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('26', '4', '6', '20', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('27', '4', '7', '20', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('28', '4', '8', '20', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('29', '7', '3', '19', '1', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('30', '7', '5', '19', '1', '28', '7');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('33', '4', '6', '22', '1', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('34', '4', '7', '22', '1', '31', '7');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('35', '4', '8', '22', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('36', '4', '9', '22', '1', '33', '3');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('37', '4', '10', '22', '1', '31', '7');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('38', '4', '6', '23', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('39', '4', '7', '23', '1', '33', '3');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('40', '4', '8', '23', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('41', '4', '9', '23', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('42', '4', '10', '23', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('43', '9', '11', '24', '4', '40', '12');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('44', '9', '12', '24', '4', '39', '13');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('45', '9', '13', '24', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('46', '9', '14', '24', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('47', '9', '11', '25', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('48', '9', '12', '25', '4', '40', '12');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('49', '9', '13', '25', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('50', '9', '14', '25', '4', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('51', '9', '11', '26', '4', '0', '0');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('52', '9', '12', '26', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('53', '9', '13', '26', '4', '39', '13');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('54', '9', '14', '26', '4', '40', '12');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('55', '2', '15', '27', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('56', '2', '16', '27', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('57', '2', '17', '27', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('58', '2', '18', '27', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('59', '2', '19', '27', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('60', '2', '15', '28', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('61', '2', '16', '28', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('62', '2', '17', '28', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('63', '2', '18', '28', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('64', '2', '19', '28', '1', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('65', '10', '20', '29', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('66', '10', '21', '29', '6', '36', '10');
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('67', '10', '22', '29', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('68', '10', '23', '29', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('69', '10', '24', '29', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('70', '10', '20', '30', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('71', '10', '21', '30', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('72', '10', '22', '30', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('73', '10', '23', '30', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('74', '10', '24', '30', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('75', '10', '20', '31', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('76', '10', '21', '31', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('77', '10', '22', '31', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('78', '10', '23', '31', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('79', '10', '24', '31', '6', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('80', '12', '31', '32', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('81', '12', '32', '32', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('82', '12', '33', '32', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('83', '12', '34', '32', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('84', '12', '35', '32', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('85', '12', '31', '33', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('86', '12', '32', '33', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('87', '12', '33', '33', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('88', '12', '34', '33', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('89', '12', '35', '33', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('90', '12', '31', '34', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('91', '12', '32', '34', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('92', '12', '33', '34', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('93', '12', '34', '34', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('94', '12', '35', '34', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('95', '12', '31', '35', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('96', '12', '32', '35', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('97', '12', '33', '35', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('98', '12', '34', '35', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('99', '12', '35', '35', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('100', '13', '25', '36', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('101', '13', '26', '36', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('102', '13', '27', '36', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('103', '13', '28', '36', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('104', '13', '29', '36', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('105', '13', '30', '36', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('106', '13', '25', '37', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('107', '13', '26', '37', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('108', '13', '27', '37', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('109', '13', '28', '37', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('110', '13', '29', '37', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('111', '13', '30', '37', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('112', '13', '25', '38', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('113', '13', '26', '38', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('114', '13', '27', '38', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('115', '13', '28', '38', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('116', '13', '29', '38', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('117', '13', '30', '38', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('118', '13', '25', '39', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('119', '13', '26', '39', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('120', '13', '27', '39', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('121', '13', '28', '39', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('122', '13', '29', '39', '4', NULL, NULL);
insert into `timetable_entries` (`id`, `batch_id`, `weekday_id`, `class_timing_id`, `schoolid`, `subject_id`, `employee_id`) values ('123', '13', '30', '39', '4', NULL, NULL);

drop table if exists `timezone`;
CREATE TABLE `timezone` (
  `id` int(100) NOT NULL auto_increment,
  `name` varchar(250) NOT NULL,
  `code` varchar(250) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=546 DEFAULT CHARSET=latin1; 
insert into `timezone` (`id`, `name`, `code`) values ('1', 'Africa/Abidjan', 'Africa/Abidjan');
insert into `timezone` (`id`, `name`, `code`) values ('2', 'Africa/Accra', 'Africa/Accra');
insert into `timezone` (`id`, `name`, `code`) values ('3', 'Africa/Addis_Ababa', 'Africa/Addis_Ababa');
insert into `timezone` (`id`, `name`, `code`) values ('4', 'Africa/Algiers', 'Africa/Algiers');
insert into `timezone` (`id`, `name`, `code`) values ('5', 'Africa/Asmara', 'Africa/Asmara');
insert into `timezone` (`id`, `name`, `code`) values ('6', 'Africa/Asmera', 'Africa/Asmera');
insert into `timezone` (`id`, `name`, `code`) values ('7', 'Africa/Bamako', 'Africa/Bamako');
insert into `timezone` (`id`, `name`, `code`) values ('8', 'Africa/Bangui', 'Africa/Bangui');
insert into `timezone` (`id`, `name`, `code`) values ('9', 'Africa/Banjul', 'Africa/Banjul');
insert into `timezone` (`id`, `name`, `code`) values ('10', 'Africa/Bissau', 'Africa/Bissau');
insert into `timezone` (`id`, `name`, `code`) values ('11', 'Africa/Blantyre', 'Africa/Blantyre');
insert into `timezone` (`id`, `name`, `code`) values ('12', 'Africa/Brazzaville', 'Africa/Brazzaville');
insert into `timezone` (`id`, `name`, `code`) values ('13', 'Africa/Bujumbura', 'Africa/Bujumbura');
insert into `timezone` (`id`, `name`, `code`) values ('14', 'Africa/Cairo', 'Africa/Cairo');
insert into `timezone` (`id`, `name`, `code`) values ('15', 'Africa/Casablanca', 'Africa/Casablanca');
insert into `timezone` (`id`, `name`, `code`) values ('16', 'Africa/Ceuta', 'Africa/Ceuta');
insert into `timezone` (`id`, `name`, `code`) values ('17', 'Africa/Conakry', 'Africa/Conakry');
insert into `timezone` (`id`, `name`, `code`) values ('18', 'Africa/Dakar', 'Africa/Dakar');
insert into `timezone` (`id`, `name`, `code`) values ('19', 'Africa/Dar_es_Salaam', 'Africa/Dar_es_Salaam');
insert into `timezone` (`id`, `name`, `code`) values ('20', 'Africa/Djibouti', 'Africa/Djibouti');
insert into `timezone` (`id`, `name`, `code`) values ('21', 'Africa/Douala', 'Africa/Douala');
insert into `timezone` (`id`, `name`, `code`) values ('22', 'Africa/El_Aaiun', 'Africa/El_Aaiun');
insert into `timezone` (`id`, `name`, `code`) values ('23', 'Africa/Freetown', 'Africa/Freetown');
insert into `timezone` (`id`, `name`, `code`) values ('24', 'Africa/Gaborone', 'Africa/Gaborone');
insert into `timezone` (`id`, `name`, `code`) values ('25', 'Africa/Harare', 'Africa/Harare');
insert into `timezone` (`id`, `name`, `code`) values ('26', 'Africa/Johannesburg', 'Africa/Johannesburg');
insert into `timezone` (`id`, `name`, `code`) values ('27', 'Africa/Kampala', 'Africa/Kampala');
insert into `timezone` (`id`, `name`, `code`) values ('28', 'Africa/Khartoum', 'Africa/Khartoum');
insert into `timezone` (`id`, `name`, `code`) values ('29', 'Africa/Kigali', 'Africa/Kigali');
insert into `timezone` (`id`, `name`, `code`) values ('30', 'Africa/Kinshasa', 'Africa/Kinshasa');
insert into `timezone` (`id`, `name`, `code`) values ('31', 'Africa/Lagos', 'Africa/Lagos');
insert into `timezone` (`id`, `name`, `code`) values ('32', 'Africa/Libreville', 'Africa/Libreville');
insert into `timezone` (`id`, `name`, `code`) values ('33', 'Africa/Lome', 'Africa/Lome');
insert into `timezone` (`id`, `name`, `code`) values ('34', 'Africa/Luanda', 'Africa/Luanda');
insert into `timezone` (`id`, `name`, `code`) values ('35', 'Africa/Lubumbashi', 'Africa/Lubumbashi');
insert into `timezone` (`id`, `name`, `code`) values ('36', 'Africa/Lusaka', 'Africa/Lusaka');
insert into `timezone` (`id`, `name`, `code`) values ('37', 'Africa/Malabo', 'Africa/Malabo');
insert into `timezone` (`id`, `name`, `code`) values ('38', 'Africa/Maputo', 'Africa/Maputo');
insert into `timezone` (`id`, `name`, `code`) values ('39', 'Africa/Maseru', 'Africa/Maseru');
insert into `timezone` (`id`, `name`, `code`) values ('40', 'Africa/Mbabane', 'Africa/Mbabane');
insert into `timezone` (`id`, `name`, `code`) values ('41', 'Africa/Mogadishu', 'Africa/Mogadishu');
insert into `timezone` (`id`, `name`, `code`) values ('42', 'Africa/Monrovia', 'Africa/Monrovia');
insert into `timezone` (`id`, `name`, `code`) values ('43', 'Africa/Nairobi', 'Africa/Nairobi');
insert into `timezone` (`id`, `name`, `code`) values ('44', 'Africa/Ndjamena', 'Africa/Ndjamena');
insert into `timezone` (`id`, `name`, `code`) values ('45', 'Africa/Niamey', 'Africa/Niamey');
insert into `timezone` (`id`, `name`, `code`) values ('46', 'Africa/Nouakchott', 'Africa/Nouakchott');
insert into `timezone` (`id`, `name`, `code`) values ('47', 'Africa/Ouagadougou', 'Africa/Ouagadougou');
insert into `timezone` (`id`, `name`, `code`) values ('48', 'Africa/Porto-Novo', 'Africa/Porto-Novo');
insert into `timezone` (`id`, `name`, `code`) values ('49', 'Africa/Sao_Tome', 'Africa/Sao_Tome');
insert into `timezone` (`id`, `name`, `code`) values ('50', 'Africa/Timbuktu', 'Africa/Timbuktu');
insert into `timezone` (`id`, `name`, `code`) values ('51', 'Africa/Tripoli', 'Africa/Tripoli');
insert into `timezone` (`id`, `name`, `code`) values ('52', 'Africa/Tunis', 'Africa/Tunis');
insert into `timezone` (`id`, `name`, `code`) values ('53', 'Africa/Windhoek', 'Africa/Windhoek');
insert into `timezone` (`id`, `name`, `code`) values ('54', 'America/Adak', 'America/Adak');
insert into `timezone` (`id`, `name`, `code`) values ('55', 'America/Anchorage', 'America/Anchorage');
insert into `timezone` (`id`, `name`, `code`) values ('56', 'America/Anguilla', 'America/Anguilla');
insert into `timezone` (`id`, `name`, `code`) values ('57', 'America/Antigua', 'America/Antigua');
insert into `timezone` (`id`, `name`, `code`) values ('58', 'America/Araguaina', 'America/Araguaina');
insert into `timezone` (`id`, `name`, `code`) values ('59', 'America/Argentina', 'America/Argentina');
insert into `timezone` (`id`, `name`, `code`) values ('60', 'America/Aruba', 'America/Aruba');
insert into `timezone` (`id`, `name`, `code`) values ('61', 'America/Asuncion', 'America/Asuncion');
insert into `timezone` (`id`, `name`, `code`) values ('62', 'America/Atikokan', 'America/Atikokan');
insert into `timezone` (`id`, `name`, `code`) values ('63', 'America/Atka', 'America/Atka');
insert into `timezone` (`id`, `name`, `code`) values ('64', 'America/Bahia', 'America/Bahia');
insert into `timezone` (`id`, `name`, `code`) values ('65', 'America/Bahia_Banderas', 'America/Bahia_Banderas');
insert into `timezone` (`id`, `name`, `code`) values ('66', 'America/Barbados', 'America/Barbados');
insert into `timezone` (`id`, `name`, `code`) values ('67', 'America/Belem', 'America/Belem');
insert into `timezone` (`id`, `name`, `code`) values ('68', 'America/Belize', 'America/Belize');
insert into `timezone` (`id`, `name`, `code`) values ('69', 'America/Blanc-Sablon', 'America/Blanc-Sablon');
insert into `timezone` (`id`, `name`, `code`) values ('70', 'America/Boa_Vista', 'America/Boa_Vista');
insert into `timezone` (`id`, `name`, `code`) values ('71', 'America/Bogota', 'America/Bogota');
insert into `timezone` (`id`, `name`, `code`) values ('72', 'America/Boise', 'America/Boise');
insert into `timezone` (`id`, `name`, `code`) values ('73', 'America/Buenos_Aires', 'America/Buenos_Aires');
insert into `timezone` (`id`, `name`, `code`) values ('74', 'America/Cambridge_Bay', 'America/Cambridge_Bay');
insert into `timezone` (`id`, `name`, `code`) values ('75', 'America/Campo_Grande', 'America/Campo_Grande');
insert into `timezone` (`id`, `name`, `code`) values ('76', 'America/Cancun', 'America/Cancun');
insert into `timezone` (`id`, `name`, `code`) values ('77', 'America/Caracas', 'America/Caracas');
insert into `timezone` (`id`, `name`, `code`) values ('78', 'America/Catamarca', 'America/Catamarca');
insert into `timezone` (`id`, `name`, `code`) values ('79', 'America/Cayenne', 'America/Cayenne');
insert into `timezone` (`id`, `name`, `code`) values ('80', 'America/Cayman', 'America/Cayman');
insert into `timezone` (`id`, `name`, `code`) values ('81', 'America/Chicago', 'America/Chicago');
insert into `timezone` (`id`, `name`, `code`) values ('82', 'America/Chihuahua', 'America/Chihuahua');
insert into `timezone` (`id`, `name`, `code`) values ('83', 'America/Coral_Harbour', 'America/Coral_Harbour');
insert into `timezone` (`id`, `name`, `code`) values ('84', 'America/Cordoba', 'America/Cordoba');
insert into `timezone` (`id`, `name`, `code`) values ('85', 'America/Costa_Rica', 'America/Costa_Rica');
insert into `timezone` (`id`, `name`, `code`) values ('86', 'America/Cuiaba', 'America/Cuiaba');
insert into `timezone` (`id`, `name`, `code`) values ('87', 'America/Curacao', 'America/Curacao');
insert into `timezone` (`id`, `name`, `code`) values ('88', 'America/Danmarkshavn', 'America/Danmarkshavn');
insert into `timezone` (`id`, `name`, `code`) values ('89', 'America/Dawson', 'America/Dawson');
insert into `timezone` (`id`, `name`, `code`) values ('90', 'America/Dawson_Creek', 'America/Dawson_Creek');
insert into `timezone` (`id`, `name`, `code`) values ('91', 'America/Denver', 'America/Denver');
insert into `timezone` (`id`, `name`, `code`) values ('92', 'America/Detroit', 'America/Detroit');
insert into `timezone` (`id`, `name`, `code`) values ('93', 'America/Dominica', 'America/Dominica');
insert into `timezone` (`id`, `name`, `code`) values ('94', 'America/Edmonton', 'America/Edmonton');
insert into `timezone` (`id`, `name`, `code`) values ('95', 'America/Eirunepe', 'America/Eirunepe');
insert into `timezone` (`id`, `name`, `code`) values ('96', 'America/El_Salvador', 'America/El_Salvador');
insert into `timezone` (`id`, `name`, `code`) values ('97', 'America/Ensenada', 'America/Ensenada');
insert into `timezone` (`id`, `name`, `code`) values ('98', 'America/Fort_Wayne', 'America/Fort_Wayne');
insert into `timezone` (`id`, `name`, `code`) values ('99', 'America/Fortaleza', 'America/Fortaleza');
insert into `timezone` (`id`, `name`, `code`) values ('100', 'America/Glace_Bay', 'America/Glace_Bay');
insert into `timezone` (`id`, `name`, `code`) values ('101', 'America/Godthab', 'America/Godthab');
insert into `timezone` (`id`, `name`, `code`) values ('102', 'America/Goose_Bay', 'America/Goose_Bay');
insert into `timezone` (`id`, `name`, `code`) values ('103', 'America/Grand_Turk', 'America/Grand_Turk');
insert into `timezone` (`id`, `name`, `code`) values ('104', 'America/Grenada', 'America/Grenada');
insert into `timezone` (`id`, `name`, `code`) values ('105', 'America/Guadeloupe', 'America/Guadeloupe');
insert into `timezone` (`id`, `name`, `code`) values ('106', 'America/Guatemala', 'America/Guatemala');
insert into `timezone` (`id`, `name`, `code`) values ('107', 'America/Guayaquil', 'America/Guayaquil');
insert into `timezone` (`id`, `name`, `code`) values ('108', 'America/Guyana', 'America/Guyana');
insert into `timezone` (`id`, `name`, `code`) values ('109', 'America/Halifax', 'America/Halifax');
insert into `timezone` (`id`, `name`, `code`) values ('110', 'America/Havana', 'America/Havana');
insert into `timezone` (`id`, `name`, `code`) values ('111', 'America/Hermosillo', 'America/Hermosillo');
insert into `timezone` (`id`, `name`, `code`) values ('112', 'America/Indiana', 'America/Indiana');
insert into `timezone` (`id`, `name`, `code`) values ('113', 'America/Indianapolis', 'America/Indianapolis');
insert into `timezone` (`id`, `name`, `code`) values ('114', 'America/Inuvik', 'America/Inuvik');
insert into `timezone` (`id`, `name`, `code`) values ('115', 'America/Iqaluit', 'America/Iqaluit');
insert into `timezone` (`id`, `name`, `code`) values ('116', 'America/Jamaica', 'America/Jamaica');
insert into `timezone` (`id`, `name`, `code`) values ('117', 'America/Jujuy', 'America/Jujuy');
insert into `timezone` (`id`, `name`, `code`) values ('118', 'America/Juneau', 'America/Juneau');
insert into `timezone` (`id`, `name`, `code`) values ('119', 'America/Kentucky', 'America/Kentucky');
insert into `timezone` (`id`, `name`, `code`) values ('120', 'America/Knox_IN', 'America/Knox_IN');
insert into `timezone` (`id`, `name`, `code`) values ('121', 'America/La_Paz', 'America/La_Paz');
insert into `timezone` (`id`, `name`, `code`) values ('122', 'America/Lima', 'America/Lima');
insert into `timezone` (`id`, `name`, `code`) values ('123', 'America/Los_Angeles', 'America/Los_Angeles');
insert into `timezone` (`id`, `name`, `code`) values ('124', 'America/Louisville', 'America/Louisville');
insert into `timezone` (`id`, `name`, `code`) values ('125', 'America/Maceio', 'America/Maceio');
insert into `timezone` (`id`, `name`, `code`) values ('126', 'America/Managua', 'America/Managua');
insert into `timezone` (`id`, `name`, `code`) values ('127', 'America/Manaus', 'America/Manaus');
insert into `timezone` (`id`, `name`, `code`) values ('128', 'America/Marigot', 'America/Marigot');
insert into `timezone` (`id`, `name`, `code`) values ('129', 'America/Martinique', 'America/Martinique');
insert into `timezone` (`id`, `name`, `code`) values ('130', 'America/Matamoros', 'America/Matamoros');
insert into `timezone` (`id`, `name`, `code`) values ('131', 'America/Mazatlan', 'America/Mazatlan');
insert into `timezone` (`id`, `name`, `code`) values ('132', 'America/Mendoza', 'America/Mendoza');
insert into `timezone` (`id`, `name`, `code`) values ('133', 'America/Menominee', 'America/Menominee');
insert into `timezone` (`id`, `name`, `code`) values ('134', 'America/Merida', 'America/Merida');
insert into `timezone` (`id`, `name`, `code`) values ('135', 'America/Mexico_City', 'America/Mexico_City');
insert into `timezone` (`id`, `name`, `code`) values ('136', 'America/Miquelon', 'America/Miquelon');
insert into `timezone` (`id`, `name`, `code`) values ('137', 'America/Moncton', 'America/Moncton');
insert into `timezone` (`id`, `name`, `code`) values ('138', 'America/Monterrey', 'America/Monterrey');
insert into `timezone` (`id`, `name`, `code`) values ('139', 'America/Montevideo', 'America/Montevideo');
insert into `timezone` (`id`, `name`, `code`) values ('140', 'America/Montreal', 'America/Montreal');
insert into `timezone` (`id`, `name`, `code`) values ('141', 'America/Montserrat', 'America/Montserrat');
insert into `timezone` (`id`, `name`, `code`) values ('142', 'America/Nassau', 'America/Nassau');
insert into `timezone` (`id`, `name`, `code`) values ('143', 'America/New_York', 'America/New_York');
insert into `timezone` (`id`, `name`, `code`) values ('144', 'America/Nipigon', 'America/Nipigon');
insert into `timezone` (`id`, `name`, `code`) values ('145', 'America/Nome', 'America/Nome');
insert into `timezone` (`id`, `name`, `code`) values ('146', 'America/Noronha', 'America/Noronha');
insert into `timezone` (`id`, `name`, `code`) values ('147', 'America/North_Dakota', 'America/North_Dakota');
insert into `timezone` (`id`, `name`, `code`) values ('148', 'America/Ojinaga', 'America/Ojinaga');
insert into `timezone` (`id`, `name`, `code`) values ('149', 'America/Panama', 'America/Panama');
insert into `timezone` (`id`, `name`, `code`) values ('150', 'America/Pangnirtung', 'America/Pangnirtung');
insert into `timezone` (`id`, `name`, `code`) values ('151', 'America/Paramaribo', 'America/Paramaribo');
insert into `timezone` (`id`, `name`, `code`) values ('152', 'America/Phoenix', 'America/Phoenix');
insert into `timezone` (`id`, `name`, `code`) values ('153', 'America/Port-au-Prince', 'America/Port-au-Prince');
insert into `timezone` (`id`, `name`, `code`) values ('154', 'America/Port_of_Spain', 'America/Port_of_Spain');
insert into `timezone` (`id`, `name`, `code`) values ('155', 'America/Porto_Acre', 'America/Porto_Acre');
insert into `timezone` (`id`, `name`, `code`) values ('156', 'America/Porto_Velho', 'America/Porto_Velho');
insert into `timezone` (`id`, `name`, `code`) values ('157', 'America/Puerto_Rico', 'America/Puerto_Rico');
insert into `timezone` (`id`, `name`, `code`) values ('158', 'America/Rainy_River', 'America/Rainy_River');
insert into `timezone` (`id`, `name`, `code`) values ('159', 'America/Rankin_Inlet', 'America/Rankin_Inlet');
insert into `timezone` (`id`, `name`, `code`) values ('160', 'America/Recife', 'America/Recife');
insert into `timezone` (`id`, `name`, `code`) values ('161', 'America/Regina', 'America/Regina');
insert into `timezone` (`id`, `name`, `code`) values ('162', 'America/Resolute', 'America/Resolute');
insert into `timezone` (`id`, `name`, `code`) values ('163', 'America/Rio_Branco', 'America/Rio_Branco');
insert into `timezone` (`id`, `name`, `code`) values ('164', 'America/Rosario', 'America/Rosario');
insert into `timezone` (`id`, `name`, `code`) values ('165', 'America/Santa_Isabel', 'America/Santa_Isabel');
insert into `timezone` (`id`, `name`, `code`) values ('166', 'America/Santarem', 'America/Santarem');
insert into `timezone` (`id`, `name`, `code`) values ('167', 'America/Santiago', 'America/Santiago');
insert into `timezone` (`id`, `name`, `code`) values ('168', 'America/Santo_Domingo', 'America/Santo_Domingo');
insert into `timezone` (`id`, `name`, `code`) values ('169', 'America/Sao_Paulo', 'America/Sao_Paulo');
insert into `timezone` (`id`, `name`, `code`) values ('170', 'America/Scoresbysund', 'America/Scoresbysund');
insert into `timezone` (`id`, `name`, `code`) values ('171', 'America/Shiprock', 'America/Shiprock');
insert into `timezone` (`id`, `name`, `code`) values ('172', 'America/St_Barthelemy', 'America/St_Barthelemy');
insert into `timezone` (`id`, `name`, `code`) values ('173', 'America/St_Johns', 'America/St_Johns');
insert into `timezone` (`id`, `name`, `code`) values ('174', 'America/St_Kitts', 'America/St_Kitts');
insert into `timezone` (`id`, `name`, `code`) values ('175', 'America/St_Lucia', 'America/St_Lucia');
insert into `timezone` (`id`, `name`, `code`) values ('176', 'America/St_Thomas', 'America/St_Thomas');
insert into `timezone` (`id`, `name`, `code`) values ('177', 'America/St_Vincent', 'America/St_Vincent');
insert into `timezone` (`id`, `name`, `code`) values ('178', 'America/Swift_Current', 'America/Swift_Current');
insert into `timezone` (`id`, `name`, `code`) values ('179', 'America/Tegucigalpa', 'America/Tegucigalpa');
insert into `timezone` (`id`, `name`, `code`) values ('180', 'America/Thule', 'America/Thule');
insert into `timezone` (`id`, `name`, `code`) values ('181', 'America/Thunder_Bay', 'America/Thunder_Bay');
insert into `timezone` (`id`, `name`, `code`) values ('182', 'America/Tijuana', 'America/Tijuana');
insert into `timezone` (`id`, `name`, `code`) values ('183', 'America/Toronto', 'America/Toronto');
insert into `timezone` (`id`, `name`, `code`) values ('184', 'America/Tortola', 'America/Tortola');
insert into `timezone` (`id`, `name`, `code`) values ('185', 'America/Vancouver', 'America/Vancouver');
insert into `timezone` (`id`, `name`, `code`) values ('186', 'America/Virgin', 'America/Virgin');
insert into `timezone` (`id`, `name`, `code`) values ('187', 'America/Whitehorse', 'America/Whitehorse');
insert into `timezone` (`id`, `name`, `code`) values ('188', 'America/Winnipeg', 'America/Winnipeg');
insert into `timezone` (`id`, `name`, `code`) values ('189', 'America/Yakutat', 'America/Yakutat');
insert into `timezone` (`id`, `name`, `code`) values ('190', 'America/Yellowknife', 'America/Yellowknife');
insert into `timezone` (`id`, `name`, `code`) values ('191', 'Antarctica/Casey', 'Antarctica/Casey');
insert into `timezone` (`id`, `name`, `code`) values ('192', 'Antarctica/Davis', 'Antarctica/Davis');
insert into `timezone` (`id`, `name`, `code`) values ('193', 'Antarctica/DumontDUrville', 'Antarctica/DumontDUrville');
insert into `timezone` (`id`, `name`, `code`) values ('194', 'Antarctica/Macquarie', 'Antarctica/Macquarie');
insert into `timezone` (`id`, `name`, `code`) values ('195', 'Antarctica/Mawson', 'Antarctica/Mawson');
insert into `timezone` (`id`, `name`, `code`) values ('196', 'Antarctica/McMurdo', 'Antarctica/McMurdo');
insert into `timezone` (`id`, `name`, `code`) values ('197', 'Antarctica/Palmer', 'Antarctica/Palmer');
insert into `timezone` (`id`, `name`, `code`) values ('198', 'Antarctica/Rothera', 'Antarctica/Rothera');
insert into `timezone` (`id`, `name`, `code`) values ('199', 'Antarctica/South_Pole', 'Antarctica/South_Pole');
insert into `timezone` (`id`, `name`, `code`) values ('200', 'Antarctica/Syowa', 'Antarctica/Syowa');
insert into `timezone` (`id`, `name`, `code`) values ('201', 'Antarctica/Vostok', 'Antarctica/Vostok');
insert into `timezone` (`id`, `name`, `code`) values ('202', 'Arctic/Longyearbyen', 'Arctic/Longyearbyen');
insert into `timezone` (`id`, `name`, `code`) values ('203', 'Asia/Aden', 'Asia/Aden');
insert into `timezone` (`id`, `name`, `code`) values ('204', 'Asia/Almaty', 'Asia/Almaty');
insert into `timezone` (`id`, `name`, `code`) values ('205', 'Asia/Amman', 'Asia/Amman');
insert into `timezone` (`id`, `name`, `code`) values ('206', 'Asia/Anadyr', 'Asia/Anadyr');
insert into `timezone` (`id`, `name`, `code`) values ('207', 'Asia/Aqtau', 'Asia/Aqtau');
insert into `timezone` (`id`, `name`, `code`) values ('208', 'Asia/Aqtobe', 'Asia/Aqtobe');
insert into `timezone` (`id`, `name`, `code`) values ('209', 'Asia/Ashgabat', 'Asia/Ashgabat');
insert into `timezone` (`id`, `name`, `code`) values ('210', 'Asia/Ashkhabad', 'Asia/Ashkhabad');
insert into `timezone` (`id`, `name`, `code`) values ('211', 'Asia/Baghdad', 'Asia/Baghdad');
insert into `timezone` (`id`, `name`, `code`) values ('212', 'Asia/Bahrain', 'Asia/Bahrain');
insert into `timezone` (`id`, `name`, `code`) values ('213', 'Asia/Baku', 'Asia/Baku');
insert into `timezone` (`id`, `name`, `code`) values ('214', 'Asia/Bangkok', 'Asia/Bangkok');
insert into `timezone` (`id`, `name`, `code`) values ('215', 'Asia/Beirut', 'Asia/Beirut');
insert into `timezone` (`id`, `name`, `code`) values ('216', 'Asia/Bishkek', 'Asia/Bishkek');
insert into `timezone` (`id`, `name`, `code`) values ('217', 'Asia/Brunei', 'Asia/Brunei');
insert into `timezone` (`id`, `name`, `code`) values ('218', 'Asia/Calcutta', 'Asia/Calcutta');
insert into `timezone` (`id`, `name`, `code`) values ('219', 'Asia/Choibalsan', 'Asia/Choibalsan');
insert into `timezone` (`id`, `name`, `code`) values ('220', 'Asia/Chongqing', 'Asia/Chongqing');
insert into `timezone` (`id`, `name`, `code`) values ('221', 'Asia/Chungking', 'Asia/Chungking');
insert into `timezone` (`id`, `name`, `code`) values ('222', 'Asia/Colombo', 'Asia/Colombo');
insert into `timezone` (`id`, `name`, `code`) values ('223', 'Asia/Dacca', 'Asia/Dacca');
insert into `timezone` (`id`, `name`, `code`) values ('224', 'Asia/Damascus', 'Asia/Damascus');
insert into `timezone` (`id`, `name`, `code`) values ('225', 'Asia/Dhaka', 'Asia/Dhaka');
insert into `timezone` (`id`, `name`, `code`) values ('226', 'Asia/Dili', 'Asia/Dili');
insert into `timezone` (`id`, `name`, `code`) values ('227', 'Asia/Dubai', 'Asia/Dubai');
insert into `timezone` (`id`, `name`, `code`) values ('228', 'Asia/Dushanbe', 'Asia/Dushanbe');
insert into `timezone` (`id`, `name`, `code`) values ('229', 'Asia/Gaza', 'Asia/Gaza');
insert into `timezone` (`id`, `name`, `code`) values ('230', 'Asia/Harbin', 'Asia/Harbin');
insert into `timezone` (`id`, `name`, `code`) values ('231', 'Asia/Ho_Chi_Minh', 'Asia/Ho_Chi_Minh');
insert into `timezone` (`id`, `name`, `code`) values ('232', 'Asia/Hong_Kong', 'Asia/Hong_Kong');
insert into `timezone` (`id`, `name`, `code`) values ('233', 'Asia/Hovd', 'Asia/Hovd');
insert into `timezone` (`id`, `name`, `code`) values ('234', 'Asia/Irkutsk', 'Asia/Irkutsk');
insert into `timezone` (`id`, `name`, `code`) values ('235', 'Asia/Istanbul', 'Asia/Istanbul');
insert into `timezone` (`id`, `name`, `code`) values ('236', 'Asia/Jakarta', 'Asia/Jakarta');
insert into `timezone` (`id`, `name`, `code`) values ('237', 'Asia/Jayapura', 'Asia/Jayapura');
insert into `timezone` (`id`, `name`, `code`) values ('238', 'Asia/Jerusalem', 'Asia/Jerusalem');
insert into `timezone` (`id`, `name`, `code`) values ('239', 'Asia/Kabul', 'Asia/Kabul');
insert into `timezone` (`id`, `name`, `code`) values ('240', 'Asia/Kamchatka', 'Asia/Kamchatka');
insert into `timezone` (`id`, `name`, `code`) values ('241', 'Asia/Karachi', 'Asia/Karachi');
insert into `timezone` (`id`, `name`, `code`) values ('242', 'Asia/Kashgar', 'Asia/Kashgar');
insert into `timezone` (`id`, `name`, `code`) values ('243', 'Asia/Kathmandu', 'Asia/Kathmandu');
insert into `timezone` (`id`, `name`, `code`) values ('244', 'Asia/Katmandu', 'Asia/Katmandu');
insert into `timezone` (`id`, `name`, `code`) values ('245', 'Asia/Kolkata', 'Asia/Kolkata');
insert into `timezone` (`id`, `name`, `code`) values ('246', 'Asia/Krasnoyarsk', 'Asia/Krasnoyarsk');
insert into `timezone` (`id`, `name`, `code`) values ('247', 'Asia/Kuala_Lumpur', 'Asia/Kuala_Lumpur');
insert into `timezone` (`id`, `name`, `code`) values ('248', 'Asia/Kuching', 'Asia/Kuching');
insert into `timezone` (`id`, `name`, `code`) values ('249', 'Asia/Kuwait', 'Asia/Kuwait');
insert into `timezone` (`id`, `name`, `code`) values ('250', 'Asia/Macao', 'Asia/Macao');
insert into `timezone` (`id`, `name`, `code`) values ('251', 'Asia/Macau', 'Asia/Macau');
insert into `timezone` (`id`, `name`, `code`) values ('252', 'Asia/Magadan', 'Asia/Magadan');
insert into `timezone` (`id`, `name`, `code`) values ('253', 'Asia/Makassar', 'Asia/Makassar');
insert into `timezone` (`id`, `name`, `code`) values ('254', 'Asia/Manila', 'Asia/Manila');
insert into `timezone` (`id`, `name`, `code`) values ('255', 'Asia/Muscat', 'Asia/Muscat');
insert into `timezone` (`id`, `name`, `code`) values ('256', 'Asia/Nicosia', 'Asia/Nicosia');
insert into `timezone` (`id`, `name`, `code`) values ('257', 'Asia/Novokuznetsk', 'Asia/Novokuznetsk');
insert into `timezone` (`id`, `name`, `code`) values ('258', 'Asia/Novosibirsk', 'Asia/Novosibirsk');
insert into `timezone` (`id`, `name`, `code`) values ('259', 'Asia/Omsk', 'Asia/Omsk');
insert into `timezone` (`id`, `name`, `code`) values ('260', 'Asia/Oral', 'Asia/Oral');
insert into `timezone` (`id`, `name`, `code`) values ('261', 'Asia/Phnom_Penh', 'Asia/Phnom_Penh');
insert into `timezone` (`id`, `name`, `code`) values ('262', 'Asia/Pontianak', 'Asia/Pontianak');
insert into `timezone` (`id`, `name`, `code`) values ('263', 'Asia/Pyongyang', 'Asia/Pyongyang');
insert into `timezone` (`id`, `name`, `code`) values ('264', 'Asia/Qatar', 'Asia/Qatar');
insert into `timezone` (`id`, `name`, `code`) values ('265', 'Asia/Qyzylorda', 'Asia/Qyzylorda');
insert into `timezone` (`id`, `name`, `code`) values ('266', 'Asia/Rangoon', 'Asia/Rangoon');
insert into `timezone` (`id`, `name`, `code`) values ('267', 'Asia/Riyadh', 'Asia/Riyadh');
insert into `timezone` (`id`, `name`, `code`) values ('268', 'Asia/Saigon', 'Asia/Saigon');
insert into `timezone` (`id`, `name`, `code`) values ('269', 'Asia/Sakhalin', 'Asia/Sakhalin');
insert into `timezone` (`id`, `name`, `code`) values ('270', 'Asia/Samarkand', 'Asia/Samarkand');
insert into `timezone` (`id`, `name`, `code`) values ('271', 'Asia/Seoul', 'Asia/Seoul');
insert into `timezone` (`id`, `name`, `code`) values ('272', 'Asia/Shanghai', 'Asia/Shanghai');
insert into `timezone` (`id`, `name`, `code`) values ('273', 'Asia/Singapore', 'Asia/Singapore');
insert into `timezone` (`id`, `name`, `code`) values ('274', 'Asia/Taipei', 'Asia/Taipei');
insert into `timezone` (`id`, `name`, `code`) values ('275', 'Asia/Tashkent', 'Asia/Tashkent');
insert into `timezone` (`id`, `name`, `code`) values ('276', 'Asia/Tbilisi', 'Asia/Tbilisi');
insert into `timezone` (`id`, `name`, `code`) values ('277', 'Asia/Tehran', 'Asia/Tehran');
insert into `timezone` (`id`, `name`, `code`) values ('278', 'Asia/Tel_Aviv', 'Asia/Tel_Aviv');
insert into `timezone` (`id`, `name`, `code`) values ('279', 'Asia/Thimbu', 'Asia/Thimbu');
insert into `timezone` (`id`, `name`, `code`) values ('280', 'Asia/Thimphu', 'Asia/Thimphu');
insert into `timezone` (`id`, `name`, `code`) values ('281', 'Asia/Tokyo', 'Asia/Tokyo');
insert into `timezone` (`id`, `name`, `code`) values ('282', 'Asia/Ujung_Pandang', 'Asia/Ujung_Pandang');
insert into `timezone` (`id`, `name`, `code`) values ('283', 'Asia/Ulaanbaatar', 'Asia/Ulaanbaatar');
insert into `timezone` (`id`, `name`, `code`) values ('284', 'Asia/Ulan_Bator', 'Asia/Ulan_Bator');
insert into `timezone` (`id`, `name`, `code`) values ('285', 'Asia/Urumqi', 'Asia/Urumqi');
insert into `timezone` (`id`, `name`, `code`) values ('286', 'Asia/Vientiane', 'Asia/Vientiane');
insert into `timezone` (`id`, `name`, `code`) values ('287', 'Asia/Vladivostok', 'Asia/Vladivostok');
insert into `timezone` (`id`, `name`, `code`) values ('288', 'Asia/Yakutsk', 'Asia/Yakutsk');
insert into `timezone` (`id`, `name`, `code`) values ('289', 'Asia/Yekaterinburg', 'Asia/Yekaterinburg');
insert into `timezone` (`id`, `name`, `code`) values ('290', 'Asia/Yerevan', 'Asia/Yerevan');
insert into `timezone` (`id`, `name`, `code`) values ('291', 'Atlantic/Azores', 'Atlantic/Azores');
insert into `timezone` (`id`, `name`, `code`) values ('292', 'Atlantic/Bermuda', 'Atlantic/Bermuda');
insert into `timezone` (`id`, `name`, `code`) values ('293', 'Atlantic/Canary', 'Atlantic/Canary');
insert into `timezone` (`id`, `name`, `code`) values ('294', 'Atlantic/Cape_Verde', 'Atlantic/Cape_Verde');
insert into `timezone` (`id`, `name`, `code`) values ('295', 'Atlantic/Faeroe', 'Atlantic/Faeroe');
insert into `timezone` (`id`, `name`, `code`) values ('296', 'Atlantic/Faroe', 'Atlantic/Faroe');
insert into `timezone` (`id`, `name`, `code`) values ('297', 'Atlantic/Jan_Mayen', 'Atlantic/Jan_Mayen');
insert into `timezone` (`id`, `name`, `code`) values ('298', 'Atlantic/Madeira', 'Atlantic/Madeira');
insert into `timezone` (`id`, `name`, `code`) values ('299', 'Atlantic/Reykjavik', 'Atlantic/Reykjavik');
insert into `timezone` (`id`, `name`, `code`) values ('300', 'Atlantic/South_Georgia', 'Atlantic/South_Georgia');
insert into `timezone` (`id`, `name`, `code`) values ('301', 'Atlantic/St_Helena', 'Atlantic/St_Helena');
insert into `timezone` (`id`, `name`, `code`) values ('302', 'Atlantic/Stanley', 'Atlantic/Stanley');
insert into `timezone` (`id`, `name`, `code`) values ('303', 'Australia/ACT', 'Australia/ACT');
insert into `timezone` (`id`, `name`, `code`) values ('304', 'Australia/Adelaide', 'Australia/Adelaide');
insert into `timezone` (`id`, `name`, `code`) values ('305', 'Australia/Brisbane', 'Australia/Brisbane');
insert into `timezone` (`id`, `name`, `code`) values ('306', 'Australia/Broken_Hill', 'Australia/Broken_Hill');
insert into `timezone` (`id`, `name`, `code`) values ('307', 'Australia/Canberra', 'Australia/Canberra');
insert into `timezone` (`id`, `name`, `code`) values ('308', 'Australia/Currie', 'Australia/Currie');
insert into `timezone` (`id`, `name`, `code`) values ('309', 'Australia/Darwin', 'Australia/Darwin');
insert into `timezone` (`id`, `name`, `code`) values ('310', 'Australia/Eucla', 'Australia/Eucla');
insert into `timezone` (`id`, `name`, `code`) values ('311', 'Australia/Hobart', 'Australia/Hobart');
insert into `timezone` (`id`, `name`, `code`) values ('312', 'Australia/LHI', 'Australia/LHI');
insert into `timezone` (`id`, `name`, `code`) values ('313', 'Australia/Lindeman', 'Australia/Lindeman');
insert into `timezone` (`id`, `name`, `code`) values ('314', 'Australia/Lord_Howe', 'Australia/Lord_Howe');
insert into `timezone` (`id`, `name`, `code`) values ('315', 'Australia/Melbourne', 'Australia/Melbourne');
insert into `timezone` (`id`, `name`, `code`) values ('316', 'Australia/NSW', 'Australia/NSW');
insert into `timezone` (`id`, `name`, `code`) values ('317', 'Australia/North', 'Australia/North');
insert into `timezone` (`id`, `name`, `code`) values ('318', 'Australia/Perth', 'Australia/Perth');
insert into `timezone` (`id`, `name`, `code`) values ('319', 'Australia/Queensland', 'Australia/Queensland');
insert into `timezone` (`id`, `name`, `code`) values ('320', 'Australia/South', 'Australia/South');
insert into `timezone` (`id`, `name`, `code`) values ('321', 'Australia/Sydney', 'Australia/Sydney');
insert into `timezone` (`id`, `name`, `code`) values ('322', 'Australia/Tasmania', 'Australia/Tasmania');
insert into `timezone` (`id`, `name`, `code`) values ('323', 'Australia/Victoria', 'Australia/Victoria');
insert into `timezone` (`id`, `name`, `code`) values ('324', 'Australia/West', 'Australia/West');
insert into `timezone` (`id`, `name`, `code`) values ('325', 'Australia/Yancowinna', 'Australia/Yancowinna');
insert into `timezone` (`id`, `name`, `code`) values ('326', 'Brazil/Acre', 'Brazil/Acre');
insert into `timezone` (`id`, `name`, `code`) values ('327', 'Brazil/DeNoronha', 'Brazil/DeNoronha');
insert into `timezone` (`id`, `name`, `code`) values ('328', 'Brazil/East', 'Brazil/East');
insert into `timezone` (`id`, `name`, `code`) values ('329', 'Brazil/West', 'Brazil/West');
insert into `timezone` (`id`, `name`, `code`) values ('330', 'CET', 'CET');
insert into `timezone` (`id`, `name`, `code`) values ('331', 'CST6CDT', 'CST6CDT');
insert into `timezone` (`id`, `name`, `code`) values ('332', 'Canada/Atlantic', 'Canada/Atlantic');
insert into `timezone` (`id`, `name`, `code`) values ('333', 'Canada/Central', 'Canada/Central');
insert into `timezone` (`id`, `name`, `code`) values ('334', 'Canada/East-Saskatchewan', 'Canada/East-Saskatchewan');
insert into `timezone` (`id`, `name`, `code`) values ('335', 'Canada/Eastern', 'Canada/Eastern');
insert into `timezone` (`id`, `name`, `code`) values ('336', 'Canada/Mountain', 'Canada/Mountain');
insert into `timezone` (`id`, `name`, `code`) values ('337', 'Canada/Newfoundland', 'Canada/Newfoundland');
insert into `timezone` (`id`, `name`, `code`) values ('338', 'Canada/Pacific', 'Canada/Pacific');
insert into `timezone` (`id`, `name`, `code`) values ('339', 'Canada/Saskatchewan', 'Canada/Saskatchewan');
insert into `timezone` (`id`, `name`, `code`) values ('340', 'Canada/Yukon', 'Canada/Yukon');
insert into `timezone` (`id`, `name`, `code`) values ('341', 'Chile/Continental', 'Chile/Continental');
insert into `timezone` (`id`, `name`, `code`) values ('342', 'Chile/EasterIsland', 'Chile/EasterIsland');
insert into `timezone` (`id`, `name`, `code`) values ('343', 'Cuba', 'Cuba');
insert into `timezone` (`id`, `name`, `code`) values ('344', 'EET', 'EET');
insert into `timezone` (`id`, `name`, `code`) values ('345', 'EST', 'EST');
insert into `timezone` (`id`, `name`, `code`) values ('346', 'EST5EDT', 'EST5EDT');
insert into `timezone` (`id`, `name`, `code`) values ('347', 'Egypt', 'Egypt');
insert into `timezone` (`id`, `name`, `code`) values ('348', 'Eire', 'Eire');
insert into `timezone` (`id`, `name`, `code`) values ('349', 'Etc/GMT+0', 'Etc/GMT+0');
insert into `timezone` (`id`, `name`, `code`) values ('350', 'Etc/GMT+1', 'Etc/GMT+1');
insert into `timezone` (`id`, `name`, `code`) values ('351', 'Etc/GMT+10', 'Etc/GMT+10');
insert into `timezone` (`id`, `name`, `code`) values ('352', 'Etc/GMT+11', 'Etc/GMT+11');
insert into `timezone` (`id`, `name`, `code`) values ('353', 'Etc/GMT+12', 'Etc/GMT+12');
insert into `timezone` (`id`, `name`, `code`) values ('354', 'Etc/GMT+2', 'Etc/GMT+2');
insert into `timezone` (`id`, `name`, `code`) values ('355', 'Etc/GMT+3', 'Etc/GMT+3');
insert into `timezone` (`id`, `name`, `code`) values ('356', 'Etc/GMT+4', 'Etc/GMT+4');
insert into `timezone` (`id`, `name`, `code`) values ('357', 'Etc/GMT+5', 'Etc/GMT+5');
insert into `timezone` (`id`, `name`, `code`) values ('358', 'Etc/GMT+6', 'Etc/GMT+6');
insert into `timezone` (`id`, `name`, `code`) values ('359', 'Etc/GMT+7', 'Etc/GMT+7');
insert into `timezone` (`id`, `name`, `code`) values ('360', 'Etc/GMT+8', 'Etc/GMT+8');
insert into `timezone` (`id`, `name`, `code`) values ('361', 'Etc/GMT+9', 'Etc/GMT+9');
insert into `timezone` (`id`, `name`, `code`) values ('362', 'Etc/GMT-0', 'Etc/GMT-0');
insert into `timezone` (`id`, `name`, `code`) values ('363', 'Etc/GMT-1', 'Etc/GMT-1');
insert into `timezone` (`id`, `name`, `code`) values ('364', 'Etc/GMT-10', 'Etc/GMT-10');
insert into `timezone` (`id`, `name`, `code`) values ('365', 'Etc/GMT-11', 'Etc/GMT-11');
insert into `timezone` (`id`, `name`, `code`) values ('366', 'Etc/GMT-12', 'Etc/GMT-12');
insert into `timezone` (`id`, `name`, `code`) values ('367', 'Etc/GMT-13', 'Etc/GMT-13');
insert into `timezone` (`id`, `name`, `code`) values ('368', 'Etc/GMT-14', 'Etc/GMT-14');
insert into `timezone` (`id`, `name`, `code`) values ('369', 'Etc/GMT-2', 'Etc/GMT-2');
insert into `timezone` (`id`, `name`, `code`) values ('370', 'Etc/GMT-3', 'Etc/GMT-3');
insert into `timezone` (`id`, `name`, `code`) values ('371', 'Etc/GMT-4', 'Etc/GMT-4');
insert into `timezone` (`id`, `name`, `code`) values ('372', 'Etc/GMT-5', 'Etc/GMT-5');
insert into `timezone` (`id`, `name`, `code`) values ('373', 'Etc/GMT-6', 'Etc/GMT-6');
insert into `timezone` (`id`, `name`, `code`) values ('374', 'Etc/GMT-7', 'Etc/GMT-7');
insert into `timezone` (`id`, `name`, `code`) values ('375', 'Etc/GMT-8', 'Etc/GMT-8');
insert into `timezone` (`id`, `name`, `code`) values ('376', 'Etc/GMT-9', 'Etc/GMT-9');
insert into `timezone` (`id`, `name`, `code`) values ('377', 'Etc/GMT', 'Etc/GMT');
insert into `timezone` (`id`, `name`, `code`) values ('378', 'Etc/GMT0', 'Etc/GMT0');
insert into `timezone` (`id`, `name`, `code`) values ('379', 'Etc/Greenwich', 'Etc/Greenwich');
insert into `timezone` (`id`, `name`, `code`) values ('380', 'Etc/UCT', 'Etc/UCT');
insert into `timezone` (`id`, `name`, `code`) values ('381', 'Etc/UTC', 'Etc/UTC');
insert into `timezone` (`id`, `name`, `code`) values ('382', 'Etc/Universal', 'Etc/Universal');
insert into `timezone` (`id`, `name`, `code`) values ('383', 'Etc/Zulu', 'Etc/Zulu');
insert into `timezone` (`id`, `name`, `code`) values ('384', 'Europe/Amsterdam', 'Europe/Amsterdam');
insert into `timezone` (`id`, `name`, `code`) values ('385', 'Europe/Andorra', 'Europe/Andorra');
insert into `timezone` (`id`, `name`, `code`) values ('386', 'Europe/Athens', 'Europe/Athens');
insert into `timezone` (`id`, `name`, `code`) values ('387', 'Europe/Belfast', 'Europe/Belfast');
insert into `timezone` (`id`, `name`, `code`) values ('388', 'Europe/Belgrade', 'Europe/Belgrade');
insert into `timezone` (`id`, `name`, `code`) values ('389', 'Europe/Berlin', 'Europe/Berlin');
insert into `timezone` (`id`, `name`, `code`) values ('390', 'Europe/Bratislava', 'Europe/Bratislava');
insert into `timezone` (`id`, `name`, `code`) values ('391', 'Europe/Brussels', 'Europe/Brussels');
insert into `timezone` (`id`, `name`, `code`) values ('392', 'Europe/Bucharest', 'Europe/Bucharest');
insert into `timezone` (`id`, `name`, `code`) values ('393', 'Europe/Budapest', 'Europe/Budapest');
insert into `timezone` (`id`, `name`, `code`) values ('394', 'Europe/Chisinau', 'Europe/Chisinau');
insert into `timezone` (`id`, `name`, `code`) values ('395', 'Europe/Copenhagen', 'Europe/Copenhagen');
insert into `timezone` (`id`, `name`, `code`) values ('396', 'Europe/Dublin', 'Europe/Dublin');
insert into `timezone` (`id`, `name`, `code`) values ('397', 'Europe/Gibraltar', 'Europe/Gibraltar');
insert into `timezone` (`id`, `name`, `code`) values ('398', 'Europe/Guernsey', 'Europe/Guernsey');
insert into `timezone` (`id`, `name`, `code`) values ('399', 'Europe/Helsinki', 'Europe/Helsinki');
insert into `timezone` (`id`, `name`, `code`) values ('400', 'Europe/Isle_of_Man', 'Europe/Isle_of_Man');
insert into `timezone` (`id`, `name`, `code`) values ('401', 'Europe/Istanbul', 'Europe/Istanbul');
insert into `timezone` (`id`, `name`, `code`) values ('402', 'Europe/Jersey', 'Europe/Jersey');
insert into `timezone` (`id`, `name`, `code`) values ('403', 'Europe/Kaliningrad', 'Europe/Kaliningrad');
insert into `timezone` (`id`, `name`, `code`) values ('404', 'Europe/Kiev', 'Europe/Kiev');
insert into `timezone` (`id`, `name`, `code`) values ('405', 'Europe/Lisbon', 'Europe/Lisbon');
insert into `timezone` (`id`, `name`, `code`) values ('406', 'Europe/Ljubljana', 'Europe/Ljubljana');
insert into `timezone` (`id`, `name`, `code`) values ('407', 'Europe/London', 'Europe/London');
insert into `timezone` (`id`, `name`, `code`) values ('408', 'Europe/Luxembourg', 'Europe/Luxembourg');
insert into `timezone` (`id`, `name`, `code`) values ('409', 'Europe/Madrid', 'Europe/Madrid');
insert into `timezone` (`id`, `name`, `code`) values ('410', 'Europe/Malta', 'Europe/Malta');
insert into `timezone` (`id`, `name`, `code`) values ('411', 'Europe/Mariehamn', 'Europe/Mariehamn');
insert into `timezone` (`id`, `name`, `code`) values ('412', 'Europe/Minsk', 'Europe/Minsk');
insert into `timezone` (`id`, `name`, `code`) values ('413', 'Europe/Monaco', 'Europe/Monaco');
insert into `timezone` (`id`, `name`, `code`) values ('414', 'Europe/Moscow', 'Europe/Moscow');
insert into `timezone` (`id`, `name`, `code`) values ('415', 'Europe/Nicosia', 'Europe/Nicosia');
insert into `timezone` (`id`, `name`, `code`) values ('416', 'Europe/Oslo', 'Europe/Oslo');
insert into `timezone` (`id`, `name`, `code`) values ('417', 'Europe/Paris', 'Europe/Paris');
insert into `timezone` (`id`, `name`, `code`) values ('418', 'Europe/Podgorica', 'Europe/Podgorica');
insert into `timezone` (`id`, `name`, `code`) values ('419', 'Europe/Prague', 'Europe/Prague');
insert into `timezone` (`id`, `name`, `code`) values ('420', 'Europe/Riga', 'Europe/Riga');
insert into `timezone` (`id`, `name`, `code`) values ('421', 'Europe/Rome', 'Europe/Rome');
insert into `timezone` (`id`, `name`, `code`) values ('422', 'Europe/Samara', 'Europe/Samara');
insert into `timezone` (`id`, `name`, `code`) values ('423', 'Europe/San_Marino', 'Europe/San_Marino');
insert into `timezone` (`id`, `name`, `code`) values ('424', 'Europe/Sarajevo', 'Europe/Sarajevo');
insert into `timezone` (`id`, `name`, `code`) values ('425', 'Europe/Simferopol', 'Europe/Simferopol');
insert into `timezone` (`id`, `name`, `code`) values ('426', 'Europe/Skopje', 'Europe/Skopje');
insert into `timezone` (`id`, `name`, `code`) values ('427', 'Europe/Sofia', 'Europe/Sofia');
insert into `timezone` (`id`, `name`, `code`) values ('428', 'Europe/Stockholm', 'Europe/Stockholm');
insert into `timezone` (`id`, `name`, `code`) values ('429', 'Europe/Tallinn', 'Europe/Tallinn');
insert into `timezone` (`id`, `name`, `code`) values ('430', 'Europe/Tirane', 'Europe/Tirane');
insert into `timezone` (`id`, `name`, `code`) values ('431', 'Europe/Tiraspol', 'Europe/Tiraspol');
insert into `timezone` (`id`, `name`, `code`) values ('432', 'Europe/Uzhgorod', 'Europe/Uzhgorod');
insert into `timezone` (`id`, `name`, `code`) values ('433', 'Europe/Vaduz', 'Europe/Vaduz');
insert into `timezone` (`id`, `name`, `code`) values ('434', 'Europe/Vatican', 'Europe/Vatican');
insert into `timezone` (`id`, `name`, `code`) values ('435', 'Europe/Vienna', 'Europe/Vienna');
insert into `timezone` (`id`, `name`, `code`) values ('436', 'Europe/Vilnius', 'Europe/Vilnius');
insert into `timezone` (`id`, `name`, `code`) values ('437', 'Europe/Volgograd', 'Europe/Volgograd');
insert into `timezone` (`id`, `name`, `code`) values ('438', 'Europe/Warsaw', 'Europe/Warsaw');
insert into `timezone` (`id`, `name`, `code`) values ('439', 'Europe/Zagreb', 'Europe/Zagreb');
insert into `timezone` (`id`, `name`, `code`) values ('440', 'Europe/Zaporozhye', 'Europe/Zaporozhye');
insert into `timezone` (`id`, `name`, `code`) values ('441', 'Europe/Zurich', 'Europe/Zurich');
insert into `timezone` (`id`, `name`, `code`) values ('442', 'GB-Eire', 'GB-Eire');
insert into `timezone` (`id`, `name`, `code`) values ('443', 'GB', 'GB');
insert into `timezone` (`id`, `name`, `code`) values ('444', 'GMT+0', 'GMT+0');
insert into `timezone` (`id`, `name`, `code`) values ('445', 'GMT-0', 'GMT-0');
insert into `timezone` (`id`, `name`, `code`) values ('446', 'GMT', 'GMT');
insert into `timezone` (`id`, `name`, `code`) values ('447', 'GMT0', 'GMT0');
insert into `timezone` (`id`, `name`, `code`) values ('448', 'Greenwich', 'Greenwich');
insert into `timezone` (`id`, `name`, `code`) values ('449', 'HST', 'HST');
insert into `timezone` (`id`, `name`, `code`) values ('450', 'Hongkong', 'Hongkong');
insert into `timezone` (`id`, `name`, `code`) values ('451', 'Iceland', 'Iceland');
insert into `timezone` (`id`, `name`, `code`) values ('452', 'Indian/Antananarivo', 'Indian/Antananarivo');
insert into `timezone` (`id`, `name`, `code`) values ('453', 'Indian/Chagos', 'Indian/Chagos');
insert into `timezone` (`id`, `name`, `code`) values ('454', 'Indian/Christmas', 'Indian/Christmas');
insert into `timezone` (`id`, `name`, `code`) values ('455', 'Indian/Cocos', 'Indian/Cocos');
insert into `timezone` (`id`, `name`, `code`) values ('456', 'Indian/Comoro', 'Indian/Comoro');
insert into `timezone` (`id`, `name`, `code`) values ('457', 'Indian/Kerguelen', 'Indian/Kerguelen');
insert into `timezone` (`id`, `name`, `code`) values ('458', 'Indian/Mahe', 'Indian/Mahe');
insert into `timezone` (`id`, `name`, `code`) values ('459', 'Indian/Maldives', 'Indian/Maldives');
insert into `timezone` (`id`, `name`, `code`) values ('460', 'Indian/Mauritius', 'Indian/Mauritius');
insert into `timezone` (`id`, `name`, `code`) values ('461', 'Indian/Mayotte', 'Indian/Mayotte');
insert into `timezone` (`id`, `name`, `code`) values ('462', 'Indian/Reunion', 'Indian/Reunion');
insert into `timezone` (`id`, `name`, `code`) values ('463', 'Iran', 'Iran');
insert into `timezone` (`id`, `name`, `code`) values ('464', 'Israel', 'Israel');
insert into `timezone` (`id`, `name`, `code`) values ('465', 'Jamaica', 'Jamaica');
insert into `timezone` (`id`, `name`, `code`) values ('466', 'Japan', 'Japan');
insert into `timezone` (`id`, `name`, `code`) values ('467', 'Kwajalein', 'Kwajalein');
insert into `timezone` (`id`, `name`, `code`) values ('468', 'Libya', 'Libya');
insert into `timezone` (`id`, `name`, `code`) values ('469', 'MET', 'MET');
insert into `timezone` (`id`, `name`, `code`) values ('470', 'MST', 'MST');
insert into `timezone` (`id`, `name`, `code`) values ('471', 'MST7MDT', 'MST7MDT');
insert into `timezone` (`id`, `name`, `code`) values ('472', 'Mexico/BajaNorte', 'Mexico/BajaNorte');
insert into `timezone` (`id`, `name`, `code`) values ('473', 'Mexico/BajaSur', 'Mexico/BajaSur');
insert into `timezone` (`id`, `name`, `code`) values ('474', 'Mexico/General', 'Mexico/General');
insert into `timezone` (`id`, `name`, `code`) values ('475', 'NZ-CHAT', 'NZ-CHAT');
insert into `timezone` (`id`, `name`, `code`) values ('476', 'NZ', 'NZ');
insert into `timezone` (`id`, `name`, `code`) values ('477', 'Navajo', 'Navajo');
insert into `timezone` (`id`, `name`, `code`) values ('478', 'PRC', 'PRC');
insert into `timezone` (`id`, `name`, `code`) values ('479', 'PST8PDT', 'PST8PDT');
insert into `timezone` (`id`, `name`, `code`) values ('480', 'Pacific/Apia', 'Pacific/Apia');
insert into `timezone` (`id`, `name`, `code`) values ('481', 'Pacific/Auckland', 'Pacific/Auckland');
insert into `timezone` (`id`, `name`, `code`) values ('482', 'Pacific/Chatham', 'Pacific/Chatham');
insert into `timezone` (`id`, `name`, `code`) values ('483', 'Pacific/Chuuk', 'Pacific/Chuuk');
insert into `timezone` (`id`, `name`, `code`) values ('484', 'Pacific/Easter', 'Pacific/Easter');
insert into `timezone` (`id`, `name`, `code`) values ('485', 'Pacific/Efate', 'Pacific/Efate');
insert into `timezone` (`id`, `name`, `code`) values ('486', 'Pacific/Enderbury', 'Pacific/Enderbury');
insert into `timezone` (`id`, `name`, `code`) values ('487', 'Pacific/Fakaofo', 'Pacific/Fakaofo');
insert into `timezone` (`id`, `name`, `code`) values ('488', 'Pacific/Fiji', 'Pacific/Fiji');
insert into `timezone` (`id`, `name`, `code`) values ('489', 'Pacific/Funafuti', 'Pacific/Funafuti');
insert into `timezone` (`id`, `name`, `code`) values ('490', 'Pacific/Galapagos', 'Pacific/Galapagos');
insert into `timezone` (`id`, `name`, `code`) values ('491', 'Pacific/Gambier', 'Pacific/Gambier');
insert into `timezone` (`id`, `name`, `code`) values ('492', 'Pacific/Guadalcanal', 'Pacific/Guadalcanal');
insert into `timezone` (`id`, `name`, `code`) values ('493', 'Pacific/Guam', 'Pacific/Guam');
insert into `timezone` (`id`, `name`, `code`) values ('494', 'Pacific/Honolulu', 'Pacific/Honolulu');
insert into `timezone` (`id`, `name`, `code`) values ('495', 'Pacific/Johnston', 'Pacific/Johnston');
insert into `timezone` (`id`, `name`, `code`) values ('496', 'Pacific/Kiritimati', 'Pacific/Kiritimati');
insert into `timezone` (`id`, `name`, `code`) values ('497', 'Pacific/Kosrae', 'Pacific/Kosrae');
insert into `timezone` (`id`, `name`, `code`) values ('498', 'Pacific/Kwajalein', 'Pacific/Kwajalein');
insert into `timezone` (`id`, `name`, `code`) values ('499', 'Pacific/Majuro', 'Pacific/Majuro');
insert into `timezone` (`id`, `name`, `code`) values ('500', 'Pacific/Marquesas', 'Pacific/Marquesas');
insert into `timezone` (`id`, `name`, `code`) values ('501', 'Pacific/Midway', 'Pacific/Midway');
insert into `timezone` (`id`, `name`, `code`) values ('502', 'Pacific/Nauru', 'Pacific/Nauru');
insert into `timezone` (`id`, `name`, `code`) values ('503', 'Pacific/Niue', 'Pacific/Niue');
insert into `timezone` (`id`, `name`, `code`) values ('504', 'Pacific/Norfolk', 'Pacific/Norfolk');
insert into `timezone` (`id`, `name`, `code`) values ('505', 'Pacific/Noumea', 'Pacific/Noumea');
insert into `timezone` (`id`, `name`, `code`) values ('506', 'Pacific/Pago_Pago', 'Pacific/Pago_Pago');
insert into `timezone` (`id`, `name`, `code`) values ('507', 'Pacific/Palau', 'Pacific/Palau');
insert into `timezone` (`id`, `name`, `code`) values ('508', 'Pacific/Pitcairn', 'Pacific/Pitcairn');
insert into `timezone` (`id`, `name`, `code`) values ('509', 'Pacific/Pohnpei', 'Pacific/Pohnpei');
insert into `timezone` (`id`, `name`, `code`) values ('510', 'Pacific/Ponape', 'Pacific/Ponape');
insert into `timezone` (`id`, `name`, `code`) values ('511', 'Pacific/Port_Moresby', 'Pacific/Port_Moresby');
insert into `timezone` (`id`, `name`, `code`) values ('512', 'Pacific/Rarotonga', 'Pacific/Rarotonga');
insert into `timezone` (`id`, `name`, `code`) values ('513', 'Pacific/Saipan', 'Pacific/Saipan');
insert into `timezone` (`id`, `name`, `code`) values ('514', 'Pacific/Samoa', 'Pacific/Samoa');
insert into `timezone` (`id`, `name`, `code`) values ('515', 'Pacific/Tahiti', 'Pacific/Tahiti');
insert into `timezone` (`id`, `name`, `code`) values ('516', 'Pacific/Tarawa', 'Pacific/Tarawa');
insert into `timezone` (`id`, `name`, `code`) values ('517', 'Pacific/Tongatapu', 'Pacific/Tongatapu');
insert into `timezone` (`id`, `name`, `code`) values ('518', 'Pacific/Truk', 'Pacific/Truk');
insert into `timezone` (`id`, `name`, `code`) values ('519', 'Pacific/Wake', 'Pacific/Wake');
insert into `timezone` (`id`, `name`, `code`) values ('520', 'Pacific/Wallis', 'Pacific/Wallis');
insert into `timezone` (`id`, `name`, `code`) values ('521', 'Pacific/Yap', 'Pacific/Yap');
insert into `timezone` (`id`, `name`, `code`) values ('522', 'Poland', 'Poland');
insert into `timezone` (`id`, `name`, `code`) values ('523', 'Portugal', 'Portugal');
insert into `timezone` (`id`, `name`, `code`) values ('524', 'ROC', 'ROC');
insert into `timezone` (`id`, `name`, `code`) values ('525', 'ROK', 'ROK');
insert into `timezone` (`id`, `name`, `code`) values ('526', 'Singapore', 'Singapore');
insert into `timezone` (`id`, `name`, `code`) values ('527', 'Turkey', 'Turkey');
insert into `timezone` (`id`, `name`, `code`) values ('528', 'UCT', 'UCT');
insert into `timezone` (`id`, `name`, `code`) values ('529', 'US/Alaska', 'US/Alaska');
insert into `timezone` (`id`, `name`, `code`) values ('530', 'US/Aleutian', 'US/Aleutian');
insert into `timezone` (`id`, `name`, `code`) values ('531', 'US/Arizona', 'US/Arizona');
insert into `timezone` (`id`, `name`, `code`) values ('532', 'US/Central', 'US/Central');
insert into `timezone` (`id`, `name`, `code`) values ('533', 'US/East-Indiana', 'US/East-Indiana');
insert into `timezone` (`id`, `name`, `code`) values ('534', 'US/Eastern', 'US/Eastern');
insert into `timezone` (`id`, `name`, `code`) values ('535', 'US/Hawaii', 'US/Hawaii');
insert into `timezone` (`id`, `name`, `code`) values ('536', 'US/Indiana-Starke', 'US/Indiana-Starke');
insert into `timezone` (`id`, `name`, `code`) values ('537', 'US/Michigan', 'US/Michigan');
insert into `timezone` (`id`, `name`, `code`) values ('538', 'US/Mountain', 'US/Mountain');
insert into `timezone` (`id`, `name`, `code`) values ('539', 'US/Pacific', 'US/Pacific');
insert into `timezone` (`id`, `name`, `code`) values ('540', 'US/Samoa', 'US/Samoa');
insert into `timezone` (`id`, `name`, `code`) values ('541', 'UTC', 'UTC');
insert into `timezone` (`id`, `name`, `code`) values ('542', 'Universal', 'Universal');
insert into `timezone` (`id`, `name`, `code`) values ('543', 'W-SU', 'W-SU');
insert into `timezone` (`id`, `name`, `code`) values ('544', 'WET', 'WET');
insert into `timezone` (`id`, `name`, `code`) values ('545', 'Zulu', 'Zulu');

drop table if exists `users`;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `username` varchar(255) collate utf8_unicode_ci default NULL,
  `first_name` varchar(255) collate utf8_unicode_ci default NULL,
  `last_name` varchar(255) collate utf8_unicode_ci default NULL,
  `email` varchar(255) collate utf8_unicode_ci default NULL,
  `usertype` enum('A','S','T','P') collate utf8_unicode_ci NOT NULL,
  `schoolid` int(11) NOT NULL,
  `hashed_password` varchar(255) collate utf8_unicode_ci default NULL,
  `salt` varchar(255) collate utf8_unicode_ci default NULL,
  `reset_password_code` varchar(255) collate utf8_unicode_ci default NULL,
  `reset_password_code_until` datetime default NULL,
  `created_at` datetime default NULL,
  `updated_at` datetime default NULL,
  `status` tinyint(1) NOT NULL default '1',
  PRIMARY KEY  (`id`),
  KEY `index_users_on_username` (`username`(10))
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('1', 'admin', 'Administrator', NULL, 'mscosian@gmail.com', 'A', '0', '21232f297a57a5a743894a0e4a801fc3 ', NULL, NULL, NULL, '2011-10-18 14:11:22', '2011-10-18 14:11:26', '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('2', 'sec1', 'Rohit', 'Kumar', 'sec1@gmail.com', 'S', '1', '35f7bba0a937a63ed13dae2232ee4b51', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('3', 'emp1', 'Rajesh', '', 'abc@ymail.com', 'S', '1', 'b2157e7b2ae716a747597717f1efb7a0', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('5', 'teacher1', NULL, NULL, NULL, 'T', '1', '8d788385431273d11e8b43bb78f3aa41', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('6', 'emp3', NULL, NULL, NULL, 'T', '1', 'd4de43be683c4a47b9e5b52b2f191cb0', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('7', 'pr1', NULL, NULL, NULL, 'P', '1', 'a6c85163d954c307a1d552fb61054bb8', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('8', 't1', NULL, NULL, NULL, 'T', '1', '83f1535f99ab0bf4e9d02dfd85d3e3f7', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('9', 'teacher4', NULL, NULL, NULL, 'T', '1', '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('10', 'teacher5', NULL, NULL, NULL, 'T', '1', '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('12', 'pr11', 'Suresh', NULL, NULL, 'P', '1', 'a6c85163d954c307a1d552fb61054bb8', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('13', 'pr3', NULL, NULL, NULL, 'P', '1', 'f5fa6d847e7c75cf5a2d09d5598c3919', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('14', 'pr4', NULL, NULL, NULL, 'P', '1', '900150983cd24fb0d6963f7d28e17f72', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('15', 'sec3', 'Vikas', '', 'xyz@gmail.com', 'S', '2', '21232f297a57a5a743894a0e4a801fc3', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('16', 't21', 'Ajay', NULL, NULL, 'T', '2', '9c1b6f896457f01432dd4e3f3f48851d', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('17', 'pr5', NULL, NULL, NULL, 'P', '2', 'bbd995f68703c80c22e8864dd4983682', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('18', 'pr6', NULL, NULL, NULL, 'P', '2', 'a33703c87cca53aa16998617bde71873', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('19', 'pr7', NULL, NULL, NULL, 'P', '1', 'fa814d01ed04095d007f6d3e4685d19d', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('20', 'sec5', 'Mahesh', 'Kumar', 'xyz@ymail.com', 'S', '4', '5c76745167db82c78ce2647a6ea7b425', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('21', 'pr8', NULL, NULL, NULL, 'P', '1', '6cc051dd270924a68edcddae9009845d', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('22', 'jai', NULL, NULL, NULL, 'P', '1', '421493fa48fc8df84d1f5f3478cf247a', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('23', 'pr10', NULL, NULL, NULL, 'P', '1', '5f6b2a23aa03240e01914ff83be86f19', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('24', 'pr12', NULL, NULL, NULL, 'P', '1', '4b45b618444f7f90fc84d5f7c5326dce', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('25', 't2', NULL, NULL, NULL, 'T', '1', 'd41d8cd98f00b204e9800998ecf8427e', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('26', 'dd', NULL, NULL, NULL, 'T', '1', '1aabac6d068eef6a7bad3fdf50a05cc8', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('27', 'ssdf', NULL, NULL, NULL, 'T', '1', '9f6e6800cfae7749eb6c486619254b9c', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('28', 'pr13', NULL, NULL, NULL, 'P', '1', '6640bc3809012188e3d445d431b6b333', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('29', 'pr14', NULL, NULL, NULL, 'P', '1', '7f5494677dd88f18362db9eae8f40734', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('30', 'laxmi1', NULL, NULL, NULL, 'P', '0', '130b051bd696b634f85830f53f520332', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('31', 'pr101', NULL, NULL, NULL, 'P', '4', '163f069ec04957250fbe1c0e3ec26ac2', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('32', 'sec2', 'NL S', '', 'sec2@gmail.com', 'S', '6', '7eccbd2210aba54cf05bcb800b028fb2', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('33', 'nt1', NULL, NULL, NULL, 'T', '6', 'd0c1d8f22a05acfdd7f660a58ebee235', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('34', 'nt2', NULL, NULL, NULL, 'T', '6', 'fa4efbe1e3e3c842078674074020ed43', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('35', 'np1', NULL, NULL, NULL, 'P', '6', '9e649202e9c51e47ce573063d6f73e29', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('36', 'vt1', NULL, NULL, NULL, 'T', '4', '024d6ec8758a1aaef69c71d555d17367', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('37', 'lp1', NULL, NULL, NULL, 'P', '0', '73c99ccbbdad0ab009f5981584198289', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('38', 'lp11', NULL, NULL, NULL, 'P', '1', '518d988a669ee2f2ddaec0435b122a18', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('39', 'vp2', NULL, NULL, NULL, 'P', '4', 'ee2f71ea303750543c37eb8261b8be4b', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('40', 'lp3', NULL, NULL, NULL, 'P', '0', 'adef112fea10e73ed85a0b1645a7704e', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('41', 'vp3', NULL, NULL, NULL, 'P', '4', 'bd0c3f8186b70273efab970c0eec647d', NULL, NULL, NULL, NULL, NULL, '1');
insert into `users` (`id`, `username`, `first_name`, `last_name`, `email`, `usertype`, `schoolid`, `hashed_password`, `salt`, `reset_password_code`, `reset_password_code_until`, `created_at`, `updated_at`, `status`) values ('42', 'vt2', NULL, NULL, NULL, 'T', '4', 'da81a2f0770f0fbbed7704d1920e0ff4', NULL, NULL, NULL, NULL, NULL, '1');

drop table if exists `weekdays`;
CREATE TABLE `weekdays` (
  `id` int(11) NOT NULL auto_increment,
  `batch_id` int(11) default NULL,
  `weekday` varchar(255) collate utf8_unicode_ci default NULL,
  `schoolid` int(11) NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `index_weekdays_on_batch_id` (`batch_id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci; 
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('1', '7', '1', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('2', '7', '2', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('3', '7', '3', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('4', '7', '4', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('5', '7', '5', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('6', '4', '1', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('7', '4', '2', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('8', '4', '3', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('9', '4', '4', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('10', '4', '5', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('11', '9', '0', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('12', '9', '2', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('13', '9', '4', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('14', '9', '6', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('15', '2', '1', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('16', '2', '2', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('17', '2', '3', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('18', '2', '4', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('19', '2', '5', '1');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('20', '10', '1', '6');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('21', '10', '2', '6');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('22', '10', '3', '6');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('23', '10', '4', '6');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('24', '10', '5', '6');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('25', '13', '1', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('26', '13', '2', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('27', '13', '3', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('28', '13', '4', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('29', '13', '5', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('30', '13', '6', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('31', '12', '1', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('32', '12', '2', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('33', '12', '3', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('34', '12', '4', '4');
insert into `weekdays` (`id`, `batch_id`, `weekday`, `schoolid`) values ('35', '12', '5', '4');
